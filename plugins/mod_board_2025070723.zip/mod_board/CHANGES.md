# Release Notes

_NOTE - This release will work on Moodle 4.5, 5.0, 5.1, & 5.2_

##### 1.405.08 (Build 2025070723)

Bug fixes:

* Removing unnecessary package files.
* Fixing scss and css mismatch and rebuilding.

##### 1.405.07 (Build 2025070722)

Bug fixes:

* Fixed bug with draft files impacting creating notes.
* Fixing bug with single mode (private) display with no enrolments.

##### 1.405.06 (Build 2025070721)

Improvements:

* Adding new 'managenotes' capability
* Adding board links to notification messages.

Bug fixes:

* Privacy API deleting files fix.
* Fixing completion tracking for Timeline, Calendar, and Events.
* Fixing malformed SQL.
* Escape untrusted output to prevent XSS in edge-case content.

##### 1.405.05 (Build 2025070719)

Improvements:

* README and CSS changes.

##### 1.405.04 (Build 2025070718)

Bug fixes:

* Privacy API fix.

##### 1.405.03 (Build 2025070717)

Bug fixes:

* CI fix.

##### 1.405.02 (Build 2025070716)

New features / improvements:

* Receive notifications about new comments on posts written.
* New comments icon with counter.
* Course activity overview support.

Bug fixes:

* CSS fix for board edit menu in Tiles.
* CCS fix for post title wrapping.

##### 1.405.01 (Build 2025xxxxx)

New features / improvements:

* New option to attach general files to posts.
* Post content can be formatted using limited Markdown syntax.
* All group modes are now supported in single user modes. 
* Board templates can be created in admin settings.

Bug fixes:

* Security fixes.
* Multiple backup/restore related issues fixed.

Technical changes:

* Major code refactoring was completed.
* PHPUnit and Behat tests were added for most areas.
* Coding style was updated to match latest recommendations from Moodle HQ.
* New CLI Grunt script was added to simplify compilation of SCSS into CSS.
* Added support for displaying of ajax forms in modal dialogs.

##### 1.404.03 (Build 2024102003)

New features / improvements:

* Adding support for 500.
* Adding improved monologo icon for 404, and 405.

Bug fixes:

* Fix deprecated JS calls for 404.
* Fix for MSSQL support.

##### 1.404.01 (Build 2024102001)

New features / improvements:

* Adding support for 404, and 405.
* Adding improved activity icon for 404, and 405.

Bug fixes:

* Fix deprecated JS calls for 404.

_NOTE - This release will work on Moodle 4.00, 4.01, 4.02 & 4.03_

##### 1.401.03 (Build 2022040112)

New features / improvements:

* Adding 4.03 support.

Bug fixes:

* Fix 4.03 default activity completion.
* Fix 4.03 embed display.

_NOTE - This release will work on Moodle 4.00, 4.01 & 4.02. (4.3 has not been released yet)_

##### 1.401.02 (Build 2022040111)

New features / improvements:

* Adding 4.01, 4.02, and PHP8.1 support.
* New board icon.
* Allow undo rate post option.
* Support svg image format.
* New Admin setting to control usage of singleuser board types.
* Keep board comments in the database for auditing / reporting.

Bug fixes:

* Fix invalid external service parameter type.
* Backup / restore info for images and link replacements.
* Fix board error on single activity course format.
* Set correct aria label to column lock icon.
* Fix board error on single activity course format.
* Get board configuration using webservice.
* Show board title and link to board in page when embedded.
* Fix board column sorting in non-single user mode and prevent text overflowing the post container.
* Fix / reverse button order for post cancel in add post modal.
* Fix delete/post comment duplication.
* Remove the requirement to set grouping.

_NOTE - This release will work on Moodle 4.00._

##### 1.400.01 (Build 2022101201)'

* Added a single user mode.
* In single user mode a teacher can post on your board.
* Teachers can move columns.
* Per board control of opening links in a new window.
* Added activity completion settings.
* CSV export includes number of "likes".
* Added setting to allow each student to have their own board.
* Added a setting to allow/prevent YouTube videos.
* Better UI for moving and editing.
* Allow columns to be locked.
* Enable commenting functionality on each post when opened in overlay.
* Change loglevel for actions to be 'participating'.
* Add ability to embed board on the course page.
* Add ability to embed board on the course page.
* Ensure move icon has proper aria labelling.
* Ensure all keyboard controls work in the View Post popup.

##### 1.39.06 (Build 2021101501)
New features / improvements:

* Added privacy API.
* Orphaned ratings are removed.

Big fixes:

* Fixed error with group context.
* Fixed manager role default access to view and manage board instances.

***Please note, if upgrading, that site administrators will need to RESET or update their manager role capabilities, ensuring that all Board plugin related capabilities are now allowed.***

The [Moodle Docs page for resetting roles is here](http://docs.moodle.org/en/Manage_roles#Reset_role_to_defaults).

##### 1.39.05 (Build 2021092101)
New features / improvements:

* New look and layout for the board.
* Allow users to move their own note placements.
* Sorting options now include "none".

##### 1.39.04 (Build 2021090801)
New features / improvements:

* Create and edit note now in a modal.
* Tooltips added

Bug fixes:

* Ensure HTML/scripts cannot be added to media additions.
