// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Layout initialisation for Edwiser Page Builder.
 *
 * @module     local_edwiserpagebuilder/layout_init
 * @copyright  (c) 2024 WisdmLabs (https://wisdmlabs.com/) <support@wisdmlabs.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'local_edwiserpagebuilder/slick'], function($) {
    var init = function() {
        // School layout - Google Fonts (Plus Jakarta Sans, Ubuntu, DM Serif Display).
        $('body').append($(document.createElement('link')).attr('rel', 'preconnect').attr('href', 'https://fonts.googleapis.com'));
        $('body').append($(document.createElement('link')).attr('rel', 'preconnect').attr('href', 'https://fonts.gstatic.com').prop('crossorigin', true));
        $('body').append($(document.createElement('link')).attr('rel', 'stylesheet').attr('href', 'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,200;1,300;1,400;1,500;1,600;1,700;1,800&family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&family=DM+Serif+Display:ital@0;1&display=swap'));

        // School layout - Bootstrap carousel initialization.
        if ($('.custom-slider-section').length) {
            $('.custom-slider-section').carousel({
                interval: 5000,
                pause: false,
                ride: 'carousel'
            });
        }

        // School layout - Teacher section slick slider.
        $('.custom-teacher-section .slicker .teacher-item').removeClass('col-12 col-md-6 col-lg-3');
        $('.custom-teacher-section .slicker').slick({
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 4,
            arrows: false,
            autoplay: true,
            dots: true,
            autoplaySpeed: 5000,
            centerMode: true,
            responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true
                }
            }, {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }, {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }]
        });

        // School layout - Testimonial section slick slider.
        $('.custom-testimonial-section .slicker .col-12.col-lg-4.px-4').removeClass('col-12 col-lg-4 px-4');
        var slick = $('.custom-testimonial-section .slicker').slick({
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 3,
            arrows: true,
            prevArrow: $('.custom-testimonial-section .slicker-actions .testimonial-prev'),
            nextArrow: $('.custom-testimonial-section .slicker-actions .testimonial-next'),
            autoplay: true,
            dots: false,
            autoplaySpeed: 5000,
            responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            }]
        });
        $('body').on('click', '.custom-testimonial-section .slicker-actions .testimonial-prev', function() {
            slick.get(0).slick.prev();
        });
        $('body').on('click', '.custom-testimonial-section .slicker-actions .testimonial-next', function() {
            slick.get(0).slick.next();
        });

        // University layout - Campus life slick slider.
        $('.custom-teacher-section .slicker .teacher-item').removeClass('col-12 col-md-6 col-lg-3');
        $('.campus-life-section .content-cards').slick({
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 3,
            arrows: false,
            autoplay: true,
            dots: true,
            autoplaySpeed: 5000,
            centerMode: true,
            responsive: [{
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }, {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }]
        });

        // University layout - Google Fonts (Poppins, Rubik, Sora).
        $('body').append($(document.createElement('link')).attr('rel', 'preconnect').attr('href', 'https://fonts.googleapis.com'));
        $('body').append($(document.createElement('link')).attr('rel', 'preconnect').attr('href', 'https://fonts.gstatic.com').prop('crossorigin', true));
        $('body').append($(document.createElement('link')).attr('rel', 'stylesheet').attr('href', 'https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;1,600;1,700&family=Rubik:ital,wght@0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Sora&display=swap'));

        // University layout - Google Fonts (Almarai, Poppins, Rubik, Sora).
        $('body').append($(document.createElement('link')).attr('rel', 'preconnect').attr('href', 'https://fonts.googleapis.com'));
        $('body').append($(document.createElement('link')).attr('rel', 'preconnect').attr('href', 'https://fonts.gstatic.com').prop('crossorigin', true));
        $('body').append($(document.createElement('link')).attr('rel', 'stylesheet').attr('href', 'https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;1,600;1,700&family=Rubik:ital,wght@0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Sora&display=swap'));
    };

    return {
        init: init
    };
});
