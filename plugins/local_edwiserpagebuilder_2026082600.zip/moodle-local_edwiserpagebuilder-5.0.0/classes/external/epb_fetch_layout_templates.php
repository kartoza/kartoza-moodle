<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Trait for edwiser_fetch_layout_list service
 * @package   local_edwiserpagebuilder
 * @copyright (c) 2022 WisdmLabs (https://wisdmlabs.com/) <support@wisdmlabs.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @author    Gourav Govande
 */

namespace local_edwiserpagebuilder\external;

use external_single_structure;
use external_function_parameters;
use external_value;
use context_system;
use stdClass;

/**
 * Service definition for create new form
 * @copyright (c) 2022 WisdmLabs (https://wisdmlabs.com/) <support@wisdmlabs.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
trait epb_fetch_layout_templates {
    /**
     * Returns the functional parameter for fetching the blocks list.
     * @return external_function_parameters  Functional parameters
     */
    public static function epb_fetch_layout_templates_parameters() {
        return new external_function_parameters(
            ['templatename' => new external_value(PARAM_RAW, 'Generated HTML for blocks list')]
        );
    }

    /**
     * Return the response structure Fetch the blocks list service.
     * @return external_single_structure return structure
     */
    public static function epb_fetch_layout_templates_returns() {
        return new \external_single_structure(
            [
                'pagelayoutjson' => new external_value(PARAM_RAW, 'Generated HTML for blocks list'),
            ]
        );
    }

    /**
     * List down the blocks data.
     * @return array  [limitto, blocks[]]
     */
    public static function epb_fetch_layout_templates($templatename = "") {
        global $CFG, $OUTPUT, $PAGE;

        $context = \context_system::instance();
        $PAGE->set_context($context);
        self::validate_context($context);

        require_once($CFG->dirroot . '/local/edwiserpagebuilder/lib.php');
        local_edwiserpagebuilder_update_block_content();

        $bm = new \local_edwiserpagebuilder\block_handler();
        $pagelayoutblock = $bm->fetch_blocks_list(["type" => "blocklayout"]);

        // Map blocks to objects using array_map instead of foreach loop.
        $blockslist = array_map(function ($block) {
            $obj = new stdClass();
            $obj->id = $block->id;
            $obj->name = "edwiseradvancedblock";
            $obj->additionalclass = "islayout";
            $obj->section = $block->title;
            $obj->title = $block->label;
            $obj->thumbnail = str_replace("{{>cdnurl}}", LOCAL_EDWISERPAGEBUILDER_CDN_IMAGES, $block->thumbnail);
            $obj->updateavailable = $block->updateavailable;
            $obj->visible = $block->visible;
            $obj->locked = local_edwiserpagebuilder_is_epb_pro_allowed_for_block($block);
            if ($block->updateavailable || !$block->visible) {
                $obj->hasextrabutton = true;
            }
            return $obj;
        }, $pagelayoutblock);

        // Sort blocks so free blocks (locked = 0) come first.
        usort($blockslist, function ($a, $b) {
            $lockeda = (int)($a->locked ?? 0);
            $lockedb = (int)($b->locked ?? 0);
            return $lockeda - $lockedb;
        });

        if ($templatename !== "") {
            // Prepare template context with license info.
            $templatecontext = [
                "blocklist" => $blockslist,
                "isepbproallowed" => local_edwiserpagebuilder_is_epb_pro_allowed(),
                "haslockedblocks" => false,
            ];

            // Add SQL-driven flag indicating if any locked blocks exist.
            try {
                global $DB;
                $reftable = $bm->get_block_table_name();
                $templatecontext["haslockedblocks"] = (bool)$DB->record_exists($reftable, ['locked' => 1]);
            } catch (\Throwable $e) {
                // Fail-safe: default to false if table not available or any error occurs.
                $templatecontext["haslockedblocks"] = false;
            }

            // Return files_list.
            return [
                'pagelayoutjson' => $OUTPUT->render_from_template(
                    $templatename,
                    $templatecontext
                ),
            ];
        }

        // Prepare response object with license info.
        $response = new stdClass();
        $response->blockslist = array_values($blockslist);
        $response->isepbproallowed = local_edwiserpagebuilder_is_epb_pro_allowed();

        // Add SQL-driven flag indicating if any locked blocks exist.
        try {
            global $DB;
            $reftable = $bm->get_block_table_name();
            $response->haslockedblocks = (bool)$DB->record_exists($reftable, ['locked' => 1]);
        } catch (\Throwable $e) {
            // Fail-safe: default to false if table not available or any error occurs.
            $response->haslockedblocks = false;
        }

        // Return files_list.
        return [
            'pagelayoutjson' => json_encode($response),
        ];
    }
}
