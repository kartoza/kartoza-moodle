<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * User forums handler class.
 *
 * @package   local_edwiserpagebuilder
 * @copyright (c) 2022 WisdmLabs (https://wisdmlabs.com/) <support@wisdmlabs.com>
 * @author    2022 WisdmLabs
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace local_edwiserpagebuilder\remuiblck;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/forum/lib.php');

/**
 * This class handles user forum data retrieval.
 */
class user_forums {
    /**
     * @var stdclass
     */
    protected $user;

    /**
     * @var array
     */
    protected $courses = [];

    /**
     * @var array
     */
    protected $forums = [];

    /**
     * @var array
     */
    protected $forumids = [];

    /**
     * @var array
     */
    protected $hsuforums = [];

    /**
     * @var array
     */
    protected $hsuforumids = [];

    /**
     * @var array
     */
    protected $forumidsallgroups = [];

    /**
     * @var array
     */
    protected $hsuforumidsallgroups = [];

    /**
     * @var int
     */
    public static $forumlimit = 100;

    /**
     * Constructor for user_forums.
     *
     * @param bool|stdClass|int $userorid User object or id.
     * @param bool|int $forumlimit Forum limit.
     */
    public function __construct($userorid = false, $forumlimit = false) {
        $this->user = \local_edwiserpagebuilder\remuiblck\userhandler::get_user($userorid);
        if (empty($this->user) || empty($this->user->id)) {
            throw new coding_exception('Failed to get user from ' . var_export($userorid, true));
        }
        if (!empty($forumlimit)) {
            self::$forumlimit = $forumlimit;
        }
        $this->populate_forums();
    }

    /**
     * Get forums array.
     *
     * @return array Forums.
     */
    public function forums() {
        return $this->forums;
    }

    /**
     * Get forum ids array.
     *
     * @return array Forum ids.
     */
    public function forumids() {
        return $this->forumids;
    }

    /**
     * Get hsuforum array.
     *
     * @return array Hsu forums.
     */
    public function hsuforums() {
        return $this->hsuforums;
    }

    /**
     * Get hsuforum ids array.
     *
     * @return array Hsuforum ids.
     */
    public function hsuforumids() {
        return $this->hsuforumids;
    }

    /**
     * Get forum ids where user has access to all groups.
     *
     * @return array Forum ids with all groups access.
     */
    public function forumidsallgroups() {
        return $this->forumidsallgroups;
    }

    /**
     * Get hsuforum ids where user has access to all groups.
     *
     * @return array Hsuforum ids with all groups access.
     */
    public function hsuforumidsallgroups() {
        return $this->hsuforumidsallgroups;
    }

    /**
     * Remove qanda forums from forums array.
     * @param array $forums
     * @return array
     */
    private function purge_qa_forums(array $forums) {
        if (empty($forums)) {
            return $forums;
        }
        return array_filter($forums, function ($forum) {
            return $forum->type !== 'qanda';
        });
    }

    /**
     * Get forumids where current user has accessallgroups capability
     *
     * @param array $forums
     * @param string $type
     * @return array
     */
    private function forumids_accessallgroups(array $forums, $type = 'forum') {
        $forumidsallgroups = [];

        if (empty($forums)) {
            return $forums;
        }

        foreach ($forums as $forum) {
            $cm = get_coursemodule_from_instance($type, $forum->id);
            if (intval($cm->groupmode) === SEPARATEGROUPS) {
                $cmcontext = \context_module::instance($cm->id);
                $allgroups = has_capability('moodle/site:accessallgroups', $cmcontext);
                if ($allgroups) {
                    $forumidsallgroups[] = $forum->id;
                }
            }
        }
        return $forumidsallgroups;
    }

    /**
     * Forums by lastpost with most recently posted at the top.
     *
     * @param int $limit
     * @return array
     */
    protected function forumids_by_lastpost($limit) {
        global $DB;

        $params = [$this->user->id];

        $sql = 'SELECT fd.forum, MAX(fp.modified) lastpost
                  FROM {forum_posts} fp
                  JOIN {forum_discussions} fd
                    ON fd.id = fp.discussion
                  JOIN {enrol} e
                    ON e.courseid = fd.course
                  JOIN {user_enrolments} ue ON ue.enrolid = e.id
                 WHERE ue.userid = ?
              GROUP BY fd.forum
              ORDER BY lastpost desc';

        return $DB->get_records_sql($sql, $params, 0, $limit);
    }

    /**
     * Forums by lastpost with most recently posted at the top.
     *
     * @param int $limit
     * @return array
     */
    protected function hsuforumids_by_lastpost($limit) {
        global $DB;

        $params = [$this->user->id];

        $sql = 'SELECT fd.forum, MAX(fp.modified) lastpost
                  FROM {hsuforum_posts} fp
                  JOIN {hsuforum_discussions} fd
                    ON fd.id = fp.discussion
                  JOIN {hsuforum} f
                    ON f.id = fd.forum
                  JOIN {enrol} e
                    ON e.courseid = f.course
                  JOIN {user_enrolments} ue ON ue.enrolid = e.id
                 WHERE ue.userid = ?
              GROUP BY fd.forum
              ORDER BY lastpost desc';

        return $DB->get_records_sql($sql, $params, 0, $limit);
    }

    /**
     * Identify and remove stale forums.
     * This is necessary when there are a large number of forums to query - for performance reasons and also because
     * there are query parameter limits in mssql and oracle.
     *
     * @param array $forums
     * @param bool $hsufourm - is this a collection of advanced forums?
     * @return mixed
     */
    protected function process_stale_forums(array $forums, $hsuforum = false) {

        if (count($forums) > self::$forumlimit) {
            // Get forum ids by postid (ordered by most recently posted).
            if (!$hsuforum) {
                $forumidsbypost = $this->forumids_by_lastpost(self::$forumlimit);
            } else {
                $forumidsbypost = $this->hsuforumids_by_lastpost(self::$forumlimit);
            }

            $tmpforums = [];

            // Re-order forums by most recently posted.
            if (!empty($forumidsbypost)) {
                foreach ($forumidsbypost as $id => $postdate) {
                    $postdate = $postdate;
                    if (isset($forums[$id])) {
                        $tmpforums[$id] = $forums[$id];
                    }
                }
                $forums = $tmpforums;
            }

            // Cut off the less recently active forums (most stale).
            $forums = array_slice($forums, 0, self::$forumlimit, true);
        }

        return $forums;
    }


    /**
     * Populate forum id arrays.
     * @throws \coding_exception
     */
    protected function populate_forums() {
        \local_edwiserpagebuilder\remuiblck\userhandler::swap_global_user($this->user->id);

        // Note - we don't include the site in the list of courses. This is intentional - we want student engagement to
        // be increased in courses where learning takes place and the front page is unlikely to fit that model.
        // Currently we are using \theme_remui\utility::swap_global_user as a hack for the following function (MDL-51353).
        $this->courses = enrol_get_my_courses();

        $forums = [];
        $hsuforums = [];

        foreach ($this->courses as $course) {
            $forums = $forums + forum_get_readable_forums($this->user->id, $course->id);
            if (function_exists('hsuforum_get_readable_forums')) {
                $hsuforums = $hsuforums + hsuforum_get_readable_forums($this->user->id, $course->id, true);
            }
        }

        // Remove Q&A forums from array.
        $forums = $this->purge_qa_forums($forums);
        $hsuforums = $this->purge_qa_forums($hsuforums);

        // Rmove forums in courses not accessed for a long time.
        $forums = $this->process_stale_forums($forums);
        $hsuforums = $this->process_stale_forums($hsuforums, true);

        $this->forums = $forums;
        $this->hsuforums = $hsuforums;
        $this->forumids = array_keys($forums);
        $this->forumidsallgroups = $this->forumids_accessallgroups($forums);
        $this->hsuforumids = array_keys($hsuforums);
        $this->hsuforumidsallgroups = $this->forumids_accessallgroups($hsuforums, 'hsuforum');

        \local_edwiserpagebuilder\remuiblck\userhandler::swap_global_user(false);
    }
}
