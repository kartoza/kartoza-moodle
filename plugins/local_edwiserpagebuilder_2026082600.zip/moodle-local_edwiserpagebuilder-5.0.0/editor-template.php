<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Editor template for Edwiser Page Builder.
 *
 * @package   local_edwiserpagebuilder
 * @copyright (c) 2023 WisdmLabs (https://wisdmlabs.com/) <support@wisdmlabs.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$isproallowed = local_edwiserpagebuilder_is_epb_pro_allowed();
$blockcontenturl = local_edwiserpagebuilder_get_block_content_url();
$blockid = local_edwiserpagebuilder_get_block_id();
$blockreturnurl = local_edwiserpagebuilder_get_block_content_return_url();
$isproallowedjson = json_encode($isproallowed);
$mediapath = (new moodle_url(
    '/pluginfile.php/' . context_system::instance()->id . '/local_edwiserpagebuilder/media/0/'
))->out();
$strmobiletaboverlay = get_string('mobile_tab_overlay_text', 'local_edwiserpagebuilder');
$strupgradetopro = get_string('upgrade_to_pro', 'local_edwiserpagebuilder');
$stravailableinpro = get_string('availableinpro', 'local_edwiserpagebuilder');
$strupgradebannertext = get_string('upgrade_to_pro_banner_text', 'local_edwiserpagebuilder');
$strmediaselpopuptite = get_string('mediaselpopuptite', 'local_edwiserpagebuilder');
$strmediaselpopuptab1 = get_string('mediaselpopuptab1tite', 'local_edwiserpagebuilder');
$strmediaselpopuptab2 = get_string('mediaselpopuptab2tite', 'local_edwiserpagebuilder');
$strnomediafile = get_string('nomediafile', 'local_edwiserpagebuilder');
$strmediadetails = get_string('mediaselpopuplbldetials', 'local_edwiserpagebuilder');
$strmediadeletebtn = get_string('mediadeletebtn', 'local_edwiserpagebuilder');
$strmediasavebtn = get_string('mediasavebtn', 'local_edwiserpagebuilder');
$strmediaselectbtn = get_string('mediaselectbtn', 'local_edwiserpagebuilder');

$proleftpaneloverlay = '';
$probottompanelbanner = '';
if (!$isproallowed) {
    $proleftpaneloverlay = '
        <div class="disable-overlay">
            <div class="disable-warning para-regular-2">
                <span>' . $strmobiletaboverlay . '</span>
                <a href="https://edwiser.org/page-builder-for-moodle/"
                    target="_blank" class="upgrade-to-pro-btn"
                    title="' . $strupgradetopro . '">
                <span>' . $strupgradetopro . '</span>
                </a>
            </div>
        </div>';
    $probottompanelbanner = '
        <div style="position: absolute; top: -51px;
            width: 100%; left: 0; z-index: 3;">
            <div class="upgrade-to-pro-banner-wrapper">
                <span class="upgrade-to-pro-banner-text">
                    ' . $strupgradebannertext . '
                </span>
                <a href="https://edwiser.org/page-builder-for-moodle/"
                    target="_blank" class="upgrade-to-pro-btn"
                    title="' . $strupgradetopro . '">
                <span>' . $strupgradetopro . '</span>
                </a>
            </div>
        </div>';
}
?>

<div id="vvveb-builder">
    <input type="hidden" name="epb_get_blk_url" id="epb_get_blk_url" value="<?= $blockcontenturl ?>" />
    <input type="hidden" name="epb_get_blk_id" id="epb_get_blk_id" value="<?= $blockid ?>" />
    <div id="top-panel">

        <div class="btn-group float-start" role="group">

            <button class="btn btn-light" title="Toggle left column" id="toggle-left-column-btn"
                data-vvveb-action="toggleLeftColumn" data-toggle="button" data-bs-toggle="button" aria-pressed="false">
                <img src="libs/builder/icons/left-column-layout.svg" width="18" height="18" alt="" role="presentation">
            </button>

            <button class="btn btn-light" id="toggle-right-column-btn"
                data-vvveb-action="toggleRightColumn" data-toggle="button" data-bs-toggle="button" aria-pressed="false">
                <img src="libs/builder/icons/right-column-layout.svg" width="18" height="18" alt="" role="presentation">
            </button>
        </div>

        <div class="btn-group me-3" role="group">
            <button class="btn btn-light" title="Undo (Ctrl/Cmd + Z)" id="undo-btn" data-vvveb-action="undo"
                data-vvveb-shortcut="ctrl+z">
                <i class="la la-undo"></i>
            </button>

            <button class="btn btn-light" title="Redo (Ctrl/Cmd + Shift + Y)" id="redo-btn" data-vvveb-action="redo"
                data-vvveb-shortcut="ctrl+shift+z">
                <i class="la la-undo la-flip-horizontal"></i>
            </button>
        </div>


        <div class="btn-group me-3" role="group">

            <button class="btn btn-light" title="Preview" id="preview-btn"
                type="button" data-toggle="button" data-bs-toggle="button"
                aria-pressed="false" data-vvveb-action="preview">
                <i class="icon-eye-outline"></i>
            </button>

            <button class="btn btn-light" title="Fullscreen (F11)" id="fullscreen-btn" data-toggle="button" data-bs-toggle="button"
                aria-pressed="false" data-vvveb-action="fullscreen">
                <i class="icon-expand-outline"></i>
            </button>

            <button class="btn btn-light active" title="Toggle navigator (Ctrl + Shift + L)" id="toggle-tree-list"
                data-toggle="button" data-bs-toggle="button" data-vvveb-action="toggleTreeList" aria-pressed="true">
                <i class="icon-layers-outline"></i>
            </button>


        </div>


        <div class="btn-group me-2 float-end" role="group">
            <button class="btn btn-primary btn-sm btn-icon save-btn" title="Save (Ctrl + S)" id="save-btn"
                data-v-vvveb-shortcut="ctrl+e">

                <span class="loading d-none">
                    <i class="icon-save-outline"></i>
                    <span class="spinner-border spinner-border-sm align-middle" role="status" aria-hidden="true">
                    </span>
                    <span>Saving </span> ... </span>

                <span class="button-text">
                    <i class="icon-save-outline"></i> <span>Save changes</span>
                </span>

            </button>

            <a class="closeeditor"
                href="<?= $blockreturnurl ?>"
                aria-label="Close" data-vvveb-action="close">
                <img class="edw-icon" src="../edwiserpagebuilder/libs/builder/edw_icons/Close.svg" />
            </a>
        </div>

        <div class="float-end me-3">


            <div class="btn-group responsive-btns" role="group">


                <button id="mobile-view"
                    data-view="mobile"
                    class="btn btn-light"
                    title="Mobile view"
                    data-vvveb-action="viewport"
                >
                    <i class="la la-mobile"></i>
                </button>

                <button id="tablet-view"
                    data-view="tablet"
                    class="btn btn-light"
                    title="Tablet view"
                    data-vvveb-action="viewport"
                >
                    <i class="la la-tablet"></i>
                </button>

                <button id="desktop-view" data-view="" class="btn btn-light" title="Desktop view"
                    data-vvveb-action="viewport">
                    <i class="la la-laptop"></i>
                </button>

                <div class="percent">
                    <input type="number" id="zoom" value="100" step="10" min="10" max="100" class="form-control"
                        data-vvveb-action="zoomChange" data-vvveb-on="change">

                </div>
            </div>

        </div>

    </div>


    <div id="left-panel">
        <?= $proleftpaneloverlay ?>
        <div>

            <div id="filemanager" >
                <div class="header" >
                    <span class="text-secondary"><i class="la la-file la-lg"></i> Pages</span>

                    <div class="btn-group responsive-btns float-end" role="group">
                        <button class="btn btn-outline-primary btn-sm btn-add" title="New page (Ctrl + Shift + P)"
                            id="new-file-btn" data-vvveb-action="newPage" data-vvveb-shortcut="">
                            <i class="icon-add"></i>
                        </button>

                    </div>

                </div>

                <div class="tree" >
                    <ol>
                    </ol>
                </div>
            </div>


            <div class="drag-elements">

                <div class="header">
                    <ul class="nav nav-tabs  nav-fill" id="elements-tabs" role="tablist">
                        <li class="nav-item sections-tab">
                            <a class="nav-link" id="sections-tab" data-bs-toggle="tab" href="#sections"
                                role="tab" aria-controls="sections" aria-selected="true" title="Sections">
                                <i class="icon-layers-outline"></i>
                            </a>
                        </li>
                        <li class="nav-item component-tab">
                            <a class="nav-link active" id="components-tab" data-bs-toggle="tab" href="#components-tabs"
                                role="tab" aria-controls="components" aria-selected="false" title="Components">
                                <i class="icon-cube-outline"></i>
                            </a>
                        </li>
                        <li class="nav-item component-properties-tab d-none">
                            <a class="nav-link" id="properties-tab" data-bs-toggle="tab" href="#properties" role="tab"
                                aria-controls="properties" aria-selected="false" title="Properties">
                                <i class="icon-settings-outline"></i>
                                <!-- img src="../../../js/vvvebjs/icons/filters.svg" height="23"-->
                                <!-- div><small>Properties</small></div -->
                            </a>
                        </li>
                        <li class="nav-item component-configuration-tab">
                            <a class="nav-link" id="configuration-tab" data-bs-toggle="tab" href="#configuration"
                                role="tab" aria-controls="configuration" aria-selected="false" title="Styles">
                                <i class="icon-color-wand-outline"></i>
                            </a>
                        </li>
                    </ul>

                    <div class="tab-content">


                        <div class="tab-pane sections" id="sections" role="tabpanel"
                            aria-labelledby="sections-tab">


                            <ul class="nav nav-tabs nav-fill nav-underline  sections-tabs" id="sections-tabs"
                                role="tablist">
                                <li class="nav-item content-tab">
                                    <a class="nav-link active" data-bs-toggle="tab" href="#sections-new-tab" role="tab"
                                        aria-controls="components" aria-selected="false">
                                        <i class="icon-albums-outline"></i>
                                        <div><span>Sections</span></div>
                                    </a>
                                </li>
                                <li class="nav-item style-tab">
                                    <a class="nav-link" data-bs-toggle="tab" href="#sections-list" role="tab"
                                        aria-controls="sections" aria-selected="true">
                                        <i class="icon-document-text-outline"></i>
                                        <div><span>Page Sections</span></div>
                                    </a>
                                </li>
                            </ul>

                            <div class="tab-content">

                                <div class="tab-pane" id="sections-list" data-section="style" role="tabpanel"
                                    aria-labelledby="style-tab">
                                    <div class="drag-elements-sidepane sidepane">
                                        <div>
                                            <div class="sections-container p-4">

                                                <div class="section-item" draggable="true">
                                                    <div class="controls">
                                                        <div class="handle"></div>
                                                        <div class="info">
                                                            <div class="name">&nbsp;
                                                                <div class="type">&nbsp;</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="section-item" draggable="true">
                                                    <div class="controls">
                                                        <div class="handle"></div>
                                                        <div class="info">
                                                            <div class="name">&nbsp;
                                                                <div class="type">&nbsp;</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="section-item" draggable="true">
                                                    <div class="controls">
                                                        <div class="handle"></div>
                                                        <div class="info">
                                                            <div class="name">&nbsp;
                                                                <div class="type">&nbsp;</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane show active" id="sections-new-tab" data-section="content"
                                    role="tabpanel" aria-labelledby="content-tab">


                                    <div class="search">
                                        <div class="expand">
                                            <button class="text-sm" title="Expand All" data-vvveb-action="expand"><i
                                                    class="la la-plus"></i></button>
                                            <button title="Collapse all" data-vvveb-action="collapse"><i
                                                    class="la la-minus"></i></button>
                                        </div>

                                        <input class="form-control section-search" placeholder="Search sections"
                                            type="text" data-vvveb-action="search" data-vvveb-on="keyup">
                                        <button class="clear-backspace" data-vvveb-action="clearSearch"
                                            title="Clear search">
                                            <i class="la la-times"></i>
                                        </button>
                                    </div>


                                    <div class="drag-elements-sidepane sidepane">
                                        <div class="block-preview"><img src="" style="display:none"></div>
                                        <div>

                                            <ul class="sections-list clearfix" data-type="leftpanel">
                                            </ul>

                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="tab-pane show active" id="components-tabs" role="tabpanel"
                            aria-labelledby="components-tab">


                            <ul class="nav nav-tabs nav-fill nav-underline  sections-tabs" role="tablist">
                                <li class="nav-item components-tab">
                                    <a class="nav-link active" data-bs-toggle="tab" href="#components" role="tab"
                                        aria-controls="components" aria-selected="true">
                                        <i class="icon-cube-outline"></i>
                                        <div><span>Components</span></div>
                                    </a>
                                </li>
                                <li class="nav-item blocks-tab">
                                    <a class="nav-link" data-bs-toggle="tab" href="#blocks" role="tab"
                                        aria-controls="components" aria-selected="false">
                                        <i class="icon-copy-outline"></i>
                                        <div><span>Blocks</span></div>
                                        <?= !$isproallowed
                                            ? '<i class="fa fa-lock font-size-14 epb-pro-locked-primary-color"
                                            style="height: 18px;"></i>'
                                            : '' ?>
                                    </a>
                                </li>
                            </ul>

                            <div class="tab-content">

                                <div class="tab-pane show active components" id="components" data-section="components"
                                    role="tabpanel" aria-labelledby="components-tab">

                                    <div class="edw-custom-search search">
                                        <div class="expand">
                                            <button class="text-sm" title="Expand All" data-vvveb-action="expand"><i
                                                    class="la la-plus"></i></button>
                                            <button title="Collapse all" data-vvveb-action="collapse"><i
                                                    class="la la-minus"></i></button>
                                        </div>

                                        <input class="form-control component-search" placeholder="Search components"
                                            type="text" data-vvveb-action="search" data-vvveb-on="keyup">
                                        <button class="clear-backspace" data-vvveb-action="clearSearch">
                                            <i class="la la-times"></i>
                                        </button>
                                    </div>

                                    <div class="drag-elements-sidepane sidepane">
                                        <div>

                                            <ul class="components-list clearfix" data-type="leftpanel">
                                            </ul>

                                        </div>
                                    </div>
                                </div>



                                <div class="tab-pane blocks" id="blocks" data-section="content"
                                    role="tabpanel" aria-labelledby="content-tab">

                                    <div class="search">
                                        <div class="expand">
                                            <button class="text-sm" title="Expand All" data-vvveb-action="expand"><i
                                                    class="la la-plus"></i></button>
                                            <button title="Collapse all" data-vvveb-action="collapse"><i
                                                    class="la la-minus"></i></button>
                                        </div>

                                        <input class="form-control block-search" placeholder="Search blocks" type="text"
                                            data-vvveb-action="search" data-vvveb-on="keyup">
                                        <button class="clear-backspace" data-vvveb-action="clearSearch">
                                            <i class="la la-times"></i>
                                        </button>
                                    </div>


                                    <div class="drag-elements-sidepane sidepane">
                                        <div class="block-preview"><img src=""></div>
                                        <div>
                                            <ul class="blocks-list clearfix" data-type="leftpanel">
                                            </ul>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane" id="properties" role="tabpanel" aria-labelledby="properties-tab">
                            <div class="component-properties-sidepane">
                                <div>
                                    <div class="component-properties">
                                        <ul class="nav nav-tabs nav-fill nav-underline" id="properties-tabs"
                                            role="tablist">
                                            <li class="nav-item content-tab">
                                                <a class="nav-link content-tab active" data-bs-toggle="tab"
                                                    href="#content-left-panel-tab" role="tab" aria-controls="components"
                                                    aria-selected="true">
                                                    <i class="icon-albums-outline"></i> <span>Content</span>
                                                </a>
                                            </li>
                                            <li class="nav-item style-tab">
                                                <a class="nav-link" data-bs-toggle="tab" href="#style-left-panel-tab"
                                                    role="tab" aria-controls="style" aria-selected="false">
                                                    <i class="icon-color-fill-outline"></i> <span>Style</span></a>
                                            </li>
                                            <li class="nav-item advanced-tab">
                                                <a class="nav-link" data-bs-toggle="tab" href="#advanced-left-panel-tab"
                                                    role="tab" aria-controls="advanced" aria-selected="false">
                                                    <i class="icon-settings-outline"></i> <span>Advanced</span>
                                                    <?= !$isproallowed
                                                        ? '<i class="fa fa-lock font-size-14
                                                        epb-pro-locked-primary-color"></i>'
                                                        : '' ?>
                                                </a>
                                            </li>
                                        </ul>

                                        <div class="tab-content" data-offset="20">
                                            <div class="tab-pane show active" id="content-left-panel-tab"
                                                data-section="content" role="tabpanel" aria-labelledby="content-tab">
                                                <div class="alert alert-dismissible fade show alert-light m-3"
                                                    role="alert" style="">
                                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                        aria-label="Close"></button>
                                                    <strong>No selected element!</strong><br> Click on an element to
                                                    edit.
                                                </div>
                                            </div>

                                            <div class="tab-pane show" id="style-left-panel-tab" data-section="style"
                                                role="tabpanel" aria-labelledby="style-tab">
                                                <div class="border-bottom pb-2 px-2">
                                                    <div class="justify-content-end d-flex">
                                                        <select class="form-select w-50" data-vvveb-action="setState"
                                                            data-vvveb-on="change">
                                                            <option value=""> - State - </option>
                                                            <option value="hover">hover</option>
                                                            <option value="active">active</option>
                                                            <option value="nth-of-type(2n)">nth-of-type(2n)</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="tab-pane show" id="advanced-left-panel-tab"
                                                data-section="advanced" role="tabpanel" aria-labelledby="advanced-tab">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane" id="configuration" role="tabpanel" aria-labelledby="configuration-tab">

                            <ul class="nav nav-tabs nav-fill nav-underline sections-tabs" id="vars-tabs" role="tablist">
                                <li class="nav-item edw-css-tab">
                                    <a class="nav-link active" data-bs-toggle="tab" href="#edw-css-tab" role="tab"
                                        aria-controls="edw-css-tab" aria-selected="true">
                                        <img class="edw-icon" src="../edwiserpagebuilder/libs/builder/edw_icons/CSS.svg" />
                                        <div><span>Css</span></div>
                                    </a>
                                </li>
                                <li class="nav-item js-tab">
                                    <a class="nav-link" data-bs-toggle="tab" href="#js-tab" role="tab"
                                        aria-controls="js" aria-selected="true">
                                        <i class="icon-code-slash-outline"></i>
                                        <div><span>JS</span></div>
                                    </a>
                                </li>
                            </ul>

                            <div class="tab-content">

                                <div class="tab-pane " id="vars-tab" data-section="vars" role="tabpanel"
                                    aria-labelledby="vars-tab">

                                    <div class="drag-elements-sidepane sidepane">
                                        <div data-offset="80">
                                            <div class="component-properties">
                                                <!-- color palette -->
                                                <input class="header_check" type="checkbox" checked
                                                    id="header_pallette">
                                                <div class="tab-pane section px-0" data-section="content">

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane" id="css-tab" data-section="css" role="tabpanel"
                                    aria-labelledby="css-tab">
                                    <div class="drag-elements-sidepane sidepane">
                                        <div data-offset="80">
                                            <textarea id="css-editor" class="form-control" rows="24"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane show active" id="edw-css-tab" data-section="edw-css" role="tabpanel"
                                    aria-labelledby="edw-css-tab">
                                    <div class="drag-elements-sidepane sidepane">

                                            <textarea id="edwiser-block-style-editor" class="form-control" rows="24"></textarea>

                                    </div>
                                </div>

                                <div class="tab-pane" id="js-tab" data-section="js" role="tabpanel"
                                    aria-labelledby="js-tab">
                                    <div class="drag-elements-sidepane sidepane">

                                            <textarea id="edwiser-block-script-editor"
                                                class="form-control" rows="24"
                                                placeholder='Start adding Block script here.'></textarea>

                                    </div>
                                </div>

                            </div>


                        </div><!-- end configuration tab -->

                    </div>
                </div>

            </div>
        </div>
    </div>


    <div id="canvas">
        <div id="iframe-wrapper">
            <div id="iframe-layer">

                <div class="loading-message active">
                    <div class="animation-container">
                        <div class="dot dot-1"></div>
                        <div class="dot dot-2"></div>
                        <div class="dot dot-3"></div>
                    </div>

                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1">
                        <defs>
                            <filter id="goo">
                                <feGaussianBlur in="SourceGraphic" stdDeviation="10" result="blur" />
                                <feColorMatrix in="blur" mode="matrix"
                                    values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 21 -7" />
                            </filter>
                        </defs>
                    </svg>
                    <!-- https://codepen.io/Izumenko/pen/MpWyXK -->
                </div>

                <div id="highlight-box">
                    <div id="highlight-name">
                        <span class="name"></span>
                        <span class="type"></span>
                    </div>

                    <div id="section-actions">
                        <a id="add-section-btn" href="" title="Add element"><i class="la la-plus"></i></a>
                    </div>
                </div>

                <div id="select-box">

                    <div id="wysiwyg-editor" class="default-editor">
                        <!--
                        <a id="bold-btn" href="" title="Bold">
                          <svg height="24" viewBox="0 0 256 256" width="24" xmlns="http://www.w3.org/2000/svg">
                            <path clip-rule="evenodd" fill-rule="evenodd" fill="#252525"
                              d="M56 40V216H148C176.719 216 200 192.719 200 164C200 147.849
                              192.637 133.418 181.084 123.88C187.926 115.076 192 104.014 192
                              92C192 63.2812 168.719 40 140 40H56ZM88 144V184H148C159.046 184
                              168 175.046 168 164C168 152.954 159.046 144 148 144H88ZM88
                              112V72H140C151.046 72 160 80.9543 160 92C160 103.046 151.046
                              112 140 112H88Z"/>
                          </svg>
                        </a>
                        <a id="italic-btn" href="" title="Italic">
                          <svg height="24" viewBox="0 0 256 256" width="24" xmlns="http://www.w3.org/2000/svg">
                            <path fill="#252525"
                              d="M202 40H84V64H126.182L89.8182 192H54V216H172V192H129.818L166.182
                              64H202V40Z"/>
                          </svg>
                        </a>
                        <a id="underline-btn" href="" title="Underline">
                          <svg height="24" viewBox="0 0 256 256" width="24" xmlns="http://www.w3.org/2000/svg">
                            <path clip-rule="evenodd" fill-rule="evenodd" fill="#252525"
                              d="M88 40H60V108.004C60 145.56 90.4446 176.004 128 176.004C165.555
                              176.004 196 145.56 196 108.004V40H168V108C168 130.091 150.091 148
                              128 148C105.909 148 88 130.091 88
                              108V40ZM204 216V192H52V216H204Z"/>
                          </svg>
                        </a>
                        -->

                        <a id="bold-btn" class="hint" href="" title="Bold" aria-label="Bold">
                            <svg height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6,4h8a4,4,0,0,1,4,4h0a4,4,0,0,1-4,4H6Z" fill="none" stroke="currentColor"
                                    stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                                <path d="M6,12h9a4,4,0,0,1,4,4h0a4,4,0,0,1-4,4H6Z" fill="none" stroke="currentColor"
                                    stroke-linecap="round" stroke-linejoin="round" stroke-width="3" />
                            </svg>
                        </a>
                        <a id="italic-btn" class="hint" href="" title="Italic" aria-label="Italic">
                            <svg height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg">
                                <line fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" x1="19" x2="10" y1="4" y2="4" />
                                <line fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" x1="14" x2="5" y1="20" y2="20" />
                                <line fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" x1="15" x2="9" y1="4" y2="20" />
                            </svg>
                        </a>
                        <a id="underline-btn" class="hint" href="" title="Underline" aria-label="Underline">
                            <svg height="18" viewBox="0 0 24 24" width="18" xmlns="http://www.w3.org/2000/svg">
                                <path d="M6,4v7a6,6,0,0,0,6,6h0a6,6,0,0,0,6-6V4" fill="none" stroke="currentColor"
                                    stroke-linecap="round" stroke-linejoin="round" stroke-width="2" y1="2" y2="2" />
                                <line fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" x1="4" x2="20" y1="22" y2="22" />
                            </svg>
                        </a>


                        <a id="strike-btn" class="hint" href="" title="Strikeout" aria-label="Strikeout">
                            <del>S</del>
                        </a>

                        <div class="dropdown">
                                          <button class="btn btn-link dropdown-toggle"
                                              type="button" id="dropdownMenuButton"
                                              data-bs-toggle="dropdown"
                                              aria-haspopup="true" aria-expanded="false">
                                            <span class="hint" aria-label="Text align"><i class="la la-align-left"></i></span>
                                          </button>

                                          <div id="justify-btn" class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#" data-value="Left">
                                                <i class="la la-lg la-align-left"></i> Align Left</a>
                                            <a class="dropdown-item" href="#" data-value="Center">
                                                <i class="la la-lg la-align-center"></i> Align Center</a>
                                            <a class="dropdown-item" href="#" data-value="Right">
                                                <i class="la la-lg la-align-right"></i> Align Right</a>
                                            <a class="dropdown-item" href="#" data-value="Full">
                                                <i class="la la-lg la-align-justify"></i> Align Justify</a>
                                          </div>
                                        </div>

                        <div class="separator"></div>

                        <a id="link-btn" class="hint" href="" title="Create link" aria-label="Create link">
                            <i class="la la-link">
                            </i></a>

                        <div class="separator"></div>

                        <input id="fore-color" name="color" type="color" aria-label="Text color" pattern="#[a-f0-9]{6}"
                            class="form-control form-control-color hint">
                        <input id="back-color" name="background-color" type="color" aria-label="Background color"
                            pattern="#[a-f0-9]{6}" class="form-control form-control-color hint">

                        <div class="separator"></div>

                        <select id="font-size" class="form-select" aria-label="Font size">
                            <option value="">- Font size -</option>
                            <option value="8px">8 px</option>
                            <option value="9px">9 px</option>
                            <option value="10px">10 px</option>
                            <option value="11px">11 px</option>
                            <option value="12px">12 px</option>
                            <option value="13px">13 px</option>
                            <option value="14px">14 px</option>
                            <option value="15px">15 px</option>
                            <option value="16px">16 px</option>
                            <option value="17px">17 px</option>
                            <option value="18px">18 px</option>
                            <option value="19px">19 px</option>
                            <option value="20px">20 px</option>
                            <option value="21px">21 px</option>
                            <option value="22px">22 px</option>
                            <option value="23px">23 px</option>
                            <option value="24px">24 px</option>
                            <option value="25px">25 px</option>
                            <option value="26px">26 px</option>
                            <option value="27px">27 px</option>
                            <option value="28px">28 px</option>
                        </select>

                        <div class="separator"></div>

                        <select id="font-family" class="form-select" title="Font family">
                            <option value=""> - Font family - </option>
                            <optgroup label="System default">
                                <option value="Arial, Helvetica, sans-serif">Arial</option>
                                <option value="'Lucida Sans Unicode', 'Lucida Grande', sans-serif">Lucida Grande
                                </option>
                                <option value="'Palatino Linotype', 'Book Antiqua', Palatino, serif">Palatino Linotype
                                </option>
                                <option value="'Times New Roman', Times, serif">Times New Roman</option>
                                <option value="Georgia, serif">Georgia, serif</option>
                                <option value="Tahoma, Geneva, sans-serif">Tahoma</option>
                                <option value="'Comic Sans MS', cursive, sans-serif">Comic Sans</option>
                                <option value="Verdana, Geneva, sans-serif">Verdana</option>
                                <option value="Impact, Charcoal, sans-serif">Impact</option>
                                <option value="'Arial Black', Gadget, sans-serif">Arial Black</option>
                                <option value="'Trebuchet MS', Helvetica, sans-serif">Trebuchet</option>
                                <option value="'Courier New', Courier, monospace">Courier New</option>
                                <option value="'Brush Script MT', sans-serif">Brush Script</option>
                            </optgroup>
                        </select>
                    </div>

                    <div id="select-actions">
                        <a id="drag-btn" href="" title="Drag element"><i class="la la-arrows-alt"></i></a>
                        <a id="parent-btn" href="" title="Select parent" class="la-rotate-180"><i
                                class="la la-level-up-alt"></i></a>

                        <a id="up-btn" href="" title="Move element up"><i class="la la-arrow-up"></i></a>
                        <a id="down-btn" href="" title="Move element down"><i class="la la-arrow-down"></i></a>
                        <a id="edit-code-btn" href="" title="Edit html code"><i class="icon-code-outline"></i></a>

                        <a id="save-reusable-btn" href="" title="Save as reusable" class="mx-2"><i
                                class="icon-save-outline"></i></a>
                        <a id="clone-btn" href="" title="Clone element"><i class="icon-copy-outline"></i></a>
                        <a id="delete-btn" href="" title="Remove element"><i class="icon-trash-outline"></i></a>
                    </div>

                    <div class="resize">
                        <!-- top -->
                        <div class="top-left">
                        </div>
                        <div class="top-center">
                        </div>
                        <div class="top-right">
                        </div>
                        <!-- center -->
                        <div class="center-left">
                        </div>
                        <div class="center-right">
                        </div>
                        <!-- bottom -->
                        <div class="bottom-left">
                        </div>
                        <div class="bottom-center">
                        </div>
                        <div class="bottom-right">
                        </div>
                    </div>

                </div>

                <!-- add section box -->
                <div id="add-section-box" class="drag-elements">

                    <div class="header">
                        <ul class="nav nav-tabs" id="box-elements-tabs" role="tablist">
                            <li class="nav-item component-tab">
                                <a class="nav-link px-3 active" id="box-components-tab" data-bs-toggle="tab"
                                    href="#box-components" role="tab" aria-controls="components" aria-selected="true"><i
                                        class="icon-cube-outline"></i><small>Components</small></a>
                            </li>
                            <li class="nav-item sections-tab">
                                <a class="nav-link px-3" id="box-sections-tab" data-bs-toggle="tab" href="#box-blocks"
                                    role="tab" aria-controls="blocks" aria-selected="false"><i
                                        class="icon-copy-outline"></i><small>Blocks</small>
                                        <?= !$isproallowed
                                            ? '<span class="epb-pro-locked-primary-bg"
                                            title="' . $stravailableinpro . '"
                                            style="font-size: 12px; height: 16px;
                                            padding: 4px 8px; border-radius: 4px;
                                            color: #fff;">PRO</span>'
                                            : '' ?>
                                </a>
                            </li>
                            <!--
                                          <li class="nav-item component-properties-tab" style="display:none">
                                            <a class="nav-link" id="box-properties-tab"
                                                data-bs-toggle="tab" href="#box-properties"
                                                role="tab" aria-controls="properties"
                                                aria-selected="false">
                                                <i class="la la-lg la-cog"></i>
                                                <div><small>Properties</small></div>
                                            </a>
                                          </li>
                          -->
                        </ul>

                        <div class="section-box-actions">

                            <div id="close-section-btn"
                                class="btn btn-outline-secondary btn-sm mt-1 border-0 float-end"><i
                                    class="la la-times la-lg"></i></div>

                            <div class="me-4 small mt-2 float-end">

                                <div class="form-check d-inline-block small me-1">
                                    <input type="radio" id="add-section-insert-mode-after" value="after"
                                         name="add-section-insert-mode" class="form-check-input">
                                    <label class="form-check-label" for="add-section-insert-mode-after">After</label>
                                </div>

                                <div class="form-check d-inline-block small">
                                    <input type="radio" id="add-section-insert-mode-inside" value="inside"
                                    checked="checked" name="add-section-insert-mode" class="form-check-input">
                                    <label class="form-check-label" for="add-section-insert-mode-inside">Inside</label>
                                </div>

                            </div>

                        </div>

                        <div class="tab-content">
                            <div class="tab-pane show active" id="box-components" role="tabpanel"
                                aria-labelledby="components-tab">

                                <div class="search">
                                    <div class="expand">
                                        <button class="text-sm" title="Expand All" data-vvveb-action="expand"><i
                                                class="la la-plus"></i></button>
                                        <button title="Collapse all" data-vvveb-action="collapse"><i
                                                class="la la-minus"></i></button>
                                    </div>

                                    <input class="form-control component-search" placeholder="Search components"
                                        type="text" data-vvveb-action="search" data-vvveb-on="keyup">
                                    <button class="clear-backspace" data-vvveb-action="clearSearch">
                                        <i class="la la-times"></i>
                                    </button>
                                </div>

                                <div class="overflow-y-auto mb-5">
                                    <div>

                                        <ul class="components-list clearfix" data-type="addbox">
                                        </ul>

                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane" id="box-blocks" role="tabpanel" aria-labelledby="blocks-tab">

                                <div class="search">
                                    <div class="expand">
                                        <button class="text-sm" title="Expand All" data-vvveb-action="expand"><i
                                                class="la la-plus"></i></button>
                                        <button title="Collapse all" data-vvveb-action="collapse"><i
                                                class="la la-minus"></i></button>
                                    </div>

                                    <input class="form-control block-search" placeholder="Search blocks" type="text"
                                        data-vvveb-action="search" data-vvveb-on="keyup">
                                    <button class="clear-backspace" data-vvveb-action="clearSearch">
                                        <i class="la la-times"></i>
                                    </button>
                                </div>

                                <div class="overflow-y-auto mb-5">
                                    <div>

                                        <ul class="blocks-list clearfix" data-type="addbox">
                                        </ul>

                                    </div>
                                </div>

                            </div>

                            <!-- div class="tab-pane" id="box-properties" role="tabpanel" aria-labelledby="blocks-tab">
                                                <div class="component-properties-sidepane">
                                                    <div>
                                                        <div class="component-properties">
                                                            <div class="mt-4 text-center">Click on an element to edit.</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div -->
                        </div>
                    </div>

                </div>
                <!-- //add section box -->

                <div id="drop-highlight-box">
                </div>
            </div>


            <iframe src="" id="iframe1" class="epb-editor-iframe">
            </iframe>
        </div>


    </div>

    <div id="right-panel">
        <div class="component-properties">

            <ul class="nav nav-tabs nav-fill nav-underline" id="properties-tabs" role="tablist">
                <li class="nav-item content-tab">
                    <a class="nav-link active" data-bs-toggle="tab" href="#content-tab" role="tab"
                        aria-controls="components" aria-selected="true">
                        <i class="icon-albums-outline"></i> <span>Content</span></a>
                </li>
                <li class="nav-item style-tab">
                    <a class="nav-link" data-bs-toggle="tab" href="#style-tab" role="tab" aria-controls="blocks"
                        aria-selected="false">
                        <i class="icon-color-fill-outline"></i> <span>Style</span></a>
                </li>
                <li class="nav-item advanced-tab">
                    <a class="nav-link" data-bs-toggle="tab" href="#advanced-tab" role="tab" aria-controls="blocks"
                        aria-selected="false">
                        <i class="icon-settings-outline"></i> <span>Advanced</span>
                        <?= !$isproallowed
                            ? '<i class="fa fa-lock font-size-14 epb-pro-locked-primary-color"
                            style="height: 18px;"></i>'
                            : '' ?>
                    </a>
                </li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane show active" id="content-tab" data-section="content" role="tabpanel"
                    aria-labelledby="content-tab">
                    <div class="alert alert-dismissible fade show alert-light m-3" role="alert">
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        <strong>No selected element!</strong><br> Click on an element to edit.
                    </div>
                </div>

                <div class="tab-pane show" id="style-tab" data-section="style" role="tabpanel"
                    aria-labelledby="style-tab">
                    <div class="border-bottom pb-2 px-2">
                        <div class="justify-content-end d-flex">
                            <select class="form-select w-50" data-vvveb-action="setState" data-vvveb-on="change">
                                <option value=""> - State - </option>
                                <option value="hover">hover</option>
                                <option value="active">active</option>
                                <option value="nth-of-type(2n)">nth-of-type(2n)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="tab-pane show" id="advanced-tab" data-section="advanced" role="tabpanel"
                    aria-labelledby="advanced-tab">
                </div>


            </div>



        </div>
    </div>

    <div id="bottom-panel">
        <?= $probottompanelbanner ?>
        <div>
            <div class="breadcrumb-navigator px-2" style="--bs-breadcrumb-divider: '>';">

                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">body</a></li>
                    <li class="breadcrumb-item"><a href="#">section</a></li>
                    <li class="breadcrumb-item"><a href="#">img</a></li>
                </ol>
            </div>


            <div class="btn-group" role="group">

                <div id="toggleEditorJsExecute" class="form-check mt-1" style="display:none">
                    <input type="checkbox" class="form-check-input" id="runjs" name="runjs"
                        data-vvveb-action="toggleEditorJsExecute">
                    <label class="form-check-label" for="runjs"><small>Run javascript code on edit</small></label>&ensp;
                </div>


                <button id="code-editor-btn" class="btn btn-sm btn-light btn-sm" title="Code editor"
                    data-vvveb-action="toggleEditor">
                    <i class="la la-code"></i> Code editor
                </button>


            </div>

        </div>

        <div id="vvveb-code-editor">
            <textarea class="form-control"></textarea>
            <div>
            </div>
        </div>
    </div>
</div>


<!-- templates -->

<script id="vvveb-input-textinput" type="text/html">

    <div>
        <input name="{%=key%}" type="text" class="form-control"/>
    </div>

</script>

<script id="vvveb-input-textareainput" type="text/html">

    <div>
        <textarea name="{%=key%}"
            {% if (typeof rows !== 'undefined') { %} rows="{%=rows%}"
            {% } else { %} rows="3" {% } %} class="form-control"/>
    </div>

</script>

<script id="vvveb-input-checkboxinput" type="text/html">

    <div class="form-check{% if (typeof className !== 'undefined') { %} {%=className%}{% } %}">
          <input name="{%=key%}" class="form-check-input" type="checkbox" id="{%=key%}_check">
          <label class="form-check-label" for="{%=key%}_check">{% if (typeof text !== 'undefined') { %} {%=text%} {% } %}</label>
    </div>

</script>

<script id="vvveb-input-radioinput" type="text/html">

    <div>

        {% for ( var i = 0; i < options.length; i++ ) { %}

        <label class="form-check-input
            {% if (typeof inline !== 'undefined' && inline == true) { %}custom-control-inline{% } %}"
            title="{%=options[i].title%}">
          <input name="{%=key%}" class="form-check-input" type="radio"
              value="{%=options[i].value%}" id="{%=key%}{%=i%}"
              {%if (options[i].checked) { %}checked="{%=options[i].checked%}"{% } %}>
          <label class="form-check-label" for="{%=key%}{%=i%}">{%=options[i].text%}</label>
        </label>

        {% } %}

    </div>

</script>

<script id="vvveb-input-radiobuttoninput" type="text/html">

    <div class="btn-group btn-group-sm {%if (extraclass) { %}{%=extraclass%}{% } %} clearfix" role="group">
        {% var namespace = 'rb-' + Math.floor(Math.random() * 100); %}

        {% for ( var i = 0; i < options.length; i++ ) { %}

        <input name="{%=key%}" class="btn-check" type="radio"
            value="{%=options[i].value%}" id="{%=namespace%}{%=key%}{%=i%}"
            {%if (options[i].checked) { %}checked="{%=options[i].checked%}"{% } %}
            autocomplete="off">
        <label class="btn btn-outline-primary
            {%if (options[i].extraclass) { %}{%=options[i].extraclass%}{% } %}"
            for="{%=namespace%}{%=key%}{%=i%}" title="{%=options[i].title%}">
          {%if (options[i].icon) { %}<i class="{%=options[i].icon%}"></i>{% } %}
          {%=options[i].text%}
        </label>

        {% } %}

    </div>

</script>


<script id="vvveb-input-toggle" type="text/html">

    <div class="form-check form-switch {% if (typeof className !== 'undefined') { %} {%=className%}{% } %}">
        <input
        type="checkbox"
        name="{%=key%}"
        value="{%=on%}"
        {%if (off !== null) { %} data-value-off="{%=off%}" {% } %}
        {%if (on !== null) { %} data-value-on="{%=on%}" {% } %}
        class="form-check-input" type="checkbox" role="switch"
        id="{%=key%}" {% if (typeof disabled !== 'undefined' && disabled == true) { %} disabled{% } %}>
        <label class="form-check-label"for="{%=key%}">
        </label>
    </div>

</script>

<script id="vvveb-input-header" type="text/html">

        <h6 class="header">{%=header%}</h6>

</script>

<script id="vvveb-input-edwheader" type="text/html">
    <{%=type%} class="header {%=extraclass%}" {% if (style != "") {  %}
                style="{%=style%}"
                {% } %} >{%=header%}</{%=type%}>
</script>

<script id="vvveb-input-select" type="text/html">

    <div>

        <select class="form-select" name="{%=key%}"
            {% if (typeof disabled !== 'undefined' && disabled == true) { %} disabled{% } %}>
            {% var optgroup = false; for ( var i = 0; i < options.length; i++ ) { %}
                {% if (options[i].optgroup) {  %}
                    {% if (optgroup) {  %}
                        </optgroup>
                    {% } %}
                    <optgroup label="{%=options[i].optgroup%}">
                {% optgroup = true; } else { %}
            <option value="{%=options[i].value%}"
                {%
                    for (attr in options[i]) {
                            if (attr != "value" && attr != "text") {
                         %}
                            {%=attr%}={%=options[i][attr]%}
                        {% }
                    } %}>
            {%=options[i].text%}</option>
            {% } } %}
        </select>

    </div>

</script>

<script id="vvveb-input-edwiserform" type="text/html">

    <div>

        <select class="form-select edwiserformselector" name="{%=key%}"
            {% if (typeof disabled !== 'undefined' && disabled == true) { %} disabled{% } %}>
            {% var optgroup = false; for ( var i = 0; i < options.length; i++ ) { %}
                {% if (options[i].optgroup) {  %}
                    {% if (optgroup) {  %}
                        </optgroup>
                    {% } %}
                    <optgroup label="{%=options[i].optgroup%}">
                {% optgroup = true; } else { %}
            <option value="{%=options[i].value%}"
                {%
                    for (attr in options[i]) {
                            if (attr != "value" && attr != "text") {
                         %}
                            {%=attr%}={%=options[i][attr]%}
                        {% }
                    } %}>
            {%=options[i].text%}</option>
            {% } } %}
        </select>

    </div>

</script>
<script id="vvveb-input-icon-select" type="text/html">

    <div class="input-list-select">

        <div class="elements">
            <div class="row">
                {% for ( var i = 0; i < options.length; i++ ) { %}
                <div class="col">
                    <div class="element">
                        {%=options[i].value%}
                        <label>{%=options[i].text%}</label>
                    </div>
                </div>
                {% } %}
            </div>
        </div>
    </div>

</script>

<script id="vvveb-input-html-list-select" type="text/html">

    <div class="input-html-list-select">

        <div class="current-element">
        </div>

        <div class="popup">
            <select class="form-select">
                {% var optgroup = false; for ( var i = 0; i < options.length; i++ ) { %}
                    {% if (options[i].optgroup) {  %}
                        {% if (optgroup) {  %}
                            </optgroup>
                        {% } %}
                        <optgroup label="{%=options[i].optgroup%}">
                    {% optgroup = true; } else { %}
                    <option value="{%=options[i].value%}">{%=options[i].text%}</option>
                {% } } %}
            </select>

              <div class="search">
                  <input class="form-control search" placeholder="Search elements" type="text">
                  <button class="clear-backspace">
                      <i class="la la-times"></i>
                  </button>
            </div>

            <div class="elements">
                    {%=elements%}
            </div>
        </div>
    </div>

</script>

<script id="vvveb-input-html-list-dropdown" type="text/html">

    <div class="input-html-list-select" {% if (typeof id !== "undefined") { %} id={%=id%} {% } %}>

        <div class="current-element">

        </div>

        <div class="popup">
            <select class="form-select">
                {% var optgroup = false; for ( var i = 0; i < options.length; i++ ) { %}
                    {% if (options[i].optgroup) {  %}
                        {% if (optgroup) {  %}
                            </optgroup>
                        {% } %}
                        <optgroup label="{%=options[i].optgroup%}">
                    {% optgroup = true; } else { %}
                    <option value="{%=options[i].value%}">{%=options[i].text%}</option>
                {% } } %}
            </select>

              <div class="search">
                  <input class="form-control search" placeholder="Search elements" type="text">
                  <button class="clear-backspace">
                      <i class="la la-times"></i>
                  </button>
            </div>

            <div class="elements">
                    {%=elements%}
            </div>
        </div>
    </div>

</script>

<script id="vvveb-input-dateinput" type="text/html">

    <div>
        <input name="{%=key%}" type="date" class="form-control"
            {% if (typeof min_date === 'undefined') { %} min="{%=min_date%}" {% } %}
            {% if (typeof max_date === 'undefined') { %} max="{%=max_date%}" {% } %}
        />
    </div>

</script>

<script id="vvveb-input-listinput" type="text/html">

    <div class="sections-container">

        {% for ( var i = 0; i < options.length; i++ ) { %}
        <div class="section-item" draggable="true">
            <div class="controls">
                <div class="handle"></div>
                <div class="info">
                    <div class="name">{%=options[i].name%}
                        <div class="type">{%=options[i].type%}</div>
                </div>
              </div>
                <div class="buttons">
                    <a class="delete-btn" href="" title="Remove section"><i class="icon-trash-outline text-danger"></i></a>
                    <!--
                    <a class="up-btn" href="" title="Move element up"><i class="la la-arrow-up"></i></a>
                    <a class="down-btn" href="" title="Move element down"><i class="la la-arrow-down"></i></a>
                    <a class="properties-btn" href="" title="Properties"><i class="icon-settings-outline"></i></a>
                    -->
        </div>
            </div>


            <input class="header_check" type="checkbox" id="section-components-{%=options[i].suffix%}">

            <label for="section-components-{%=options[i].suffix%}">
                <div class="header-arrow"></div>
            </label>

            <div class="tree">
                {%=options[i].name%}
            </div>
        </div>




        {% } %}


        {% if (typeof hide_remove === 'undefined') { %}
        <div class="mt-3">

            <button class="btn btn-sm btn-outline-primary btn-new">
                <i class="la la-plus la-lg"></i> Add new
            </button>

        </div>
        {% } %}

    </div>

</script>

<script id="vvveb-input-grid" type="text/html">

    <div class="row">
        <div class="col-6">

            <label>Extra small</label>
            <select class="form-select" name="col" autocomplete="off">

                <option value="">None</option>
                {% for ( var i = 1; i <= 12; i++ ) { %}
                <option value="{%=i%}" {% if ((typeof col !== 'undefined') && col == i) { %} selected {% } %}>{%=i%}</option>
                {% } %}

            </select>
        </div>


        <div class="col-6">
            <label>Small</label>
            <select class="form-select" name="col-sm" autocomplete="off">

                <option value="">None</option>
                {% for ( var i = 1; i <= 12; i++ ) { %}
                <option value="{%=i%}" {% if ((typeof col_sm !== 'undefined') && col_sm == i) { %} selected {% } %}>{%=i%}</option>
                {% } %}

            </select>
        </div>

        <div class="col-6">
            <label>Medium</label>
            <select class="form-select" name="col-md" autocomplete="off">

                <option value="">None</option>
                {% for ( var i = 1; i <= 12; i++ ) { %}
                <option value="{%=i%}" {% if ((typeof col_md !== 'undefined') && col_md == i) { %} selected {% } %}>{%=i%}</option>
                {% } %}

            </select>
        </div>

        <div class="col-6">
            <label>Large</label>
            <select class="form-select" name="col-lg" autocomplete="off">

                <option value="">None</option>
                {% for ( var i = 1; i <= 12; i++ ) { %}
                <option value="{%=i%}" {% if ((typeof col_lg !== 'undefined') && col_lg == i) { %} selected {% } %}>{%=i%}</option>
                {% } %}

            </select>
        </div>


        <div class="col-6">
            <label>Extra large </label>
            <select class="form-select" name="col-xl" autocomplete="off">

                <option value="">None</option>
                {% for ( var i = 1; i <= 12; i++ ) { %}
                <option value="{%=i%}" {% if ((typeof col_xl !== 'undefined') && col_xl == i) { %} selected {% } %}>{%=i%}</option>
                {% } %}

            </select>
        </div>

        <div class="col-6">
            <label>Extra extra large</label>
            <select class="form-select" name="col-xxl" autocomplete="off">

                <option value="">None</option>
                {% for ( var i = 1; i <= 12; i++ ) { %}
                <option value="{%=i%}"
                    {% if ((typeof col_xxl !== 'undefined') && col_xxl == i) { %} selected {% } %}>{%=i%}</option>
                {% } %}

            </select>
        </div>

        {% if (typeof hide_remove === 'undefined') { %}
        <div class="col-12">

            <button class="btn btn-sm btn-outline-light text-danger">
                <i class="la la-trash la-lg"></i> Remove
            </button>

        </div>
        {% } %}

    </div>

</script>

<script id="vvveb-input-textvalue" type="text/html">

    <div class="row">
        <div class="col-6 mb-1">
            <label>Value</label>
            <input name="value" type="text" value="{%=value%}" class="form-control" autocomplete="off" />
        </div>

        <div class="col-6 mb-1">
            <label>Text</label>
            <input name="text" type="text" value="{%=text%}" class="form-control" autocomplete="off" />
        </div>

        {% if (typeof hide_remove === 'undefined') { %}
        <div class="col-12">

            <button class="btn btn-sm btn-outline-light text-danger">
                <i class="la la-trash la-lg"></i> Remove
            </button>

        </div>
        {% } %}

    </div>

</script>

<script id="vvveb-input-rangeinput" type="text/html">

    <div class="input-range">

        <input name="{%=key%}" type="range" min="{%=min%}" max="{%=max%}"
            step="{%=step%}" class="form-range" data-input-value
            {% if (typeof disabled !== 'undefined' && disabled == true) { %} disabled{% } %}/>
        <input name="{%=key%}" type="number" min="{%=min%}" max="{%=max%}"
            step="{%=step%}" class="form-control" data-input-value
            {% if (typeof disabled !== 'undefined' && disabled == true) { %} disabled{% } %}/>
    </div>

</script>

<script id="vvveb-input-imageinput" type="text/html">
    <div class="d-flex filepicker">
        <input name="{%=key%}" type="text" class="form-control epbe-file-url-in" />
            <!-- <input name="file" type="file" class="form-control"/> -->
        <button class="btn btn-outline-secondary edwiser-select-file m-0"
            data-backdrop="false" data-toggle="modal" data-bs-toggle="modal"
            data-target="#edwiser-page-builder-fp"
            data-bs-target="#edwiser-page-builder-fp">
            <i class="fa fa-upload"></i>
        </button>
    </div>
</script>

<script id="vvveb-input-videoinput" type="text/html">
    <div class="d-flex filepicker">
        <input name="{%=key%}" type="text" class="form-control epbe-file-url-in" />
            <!-- <input name="file" type="file" class="form-control"/> -->
        <button class="btn btn-outline-secondary edwiser-select-file m-0"
            data-backdrop="false" data-toggle="modal" data-bs-toggle="modal"
            data-target="#edwiser-page-builder-fp"
            data-bs-target="#edwiser-page-builder-fp">
            <i class="fa fa-upload"></i>
        </button>
    </div>
</script>

<script id="vvveb-input-imageinput-gallery" type="text/html">
    <div>
        <img id="thumb-{%=key%}" class="img-thumbnail p-0"
            data-target-input="#input-{%=key%}" data-target-thumb="#thumb-{%=key%}"
            style="cursor:pointer" src="" width="225" height="225" />
        <input name="{%=key%}" type="text" class="form-control mt-1" id="input-{%=key%}" />
        <button name="button" class="btn btn-primary btn-sm btn-icon mt-2"
            data-target-input="#input-{%=key%}" data-target-thumb="#thumb-{%=key%}">
            <i class="la la-image la-lg"></i>&ensp;Set image
        </button>
    </div>
</script>

<script id="vvveb-input-videoinput-gallery" type="text/html">

    <div>
        <video id="thumb-v{%=key%}" class="img-thumbnail p-0"
            data-target-input="#input-v{%=key%}"
            data-target-thumb="#thumb-v{%=key%}"
            style="cursor:pointer" src="" width="225" height="225"
            playsinline loop muted controls></video>
        <input name="v{%=key%}" type="text" class="form-control mt-1" id="input-v{%=key%}"/>
        <button name="button" class="btn btn-primary btn-sm btn-icon mt-2 px-2"
            data-target-input="#vinput-v{%=key%}"
            data-target-thumb="#thumb-v{%=key%}">
            <i class="la la-video la-lg"></i><span>Set video</span>
        </button>
    </div>

</script>

<script id="vvveb-input-colorinput" type="text/html">

    <div>
        <input name="{%=key%}"
            {%  if (typeof palette !== 'undefined') { %} list="{%=key%}-color-palette" {% } %}
            type="color"
            {% if (typeof value !== 'undefined' && value != false) { %} value="{%=value%}" {% } %}
            pattern="#[a-f0-9]{6}" class="form-control form-control-color"/>
        {%  if (typeof palette !== 'undefined') { %}
        <datalist id="{%=key%}-color-palette">
            {% for (const color in palette) { %}
                <option>{%=palette[color]%}</option>
            {% } %}
        {% } %}
    </div>

</script>

<script id="vvveb-input-bootstrap-color-picker-input" type="text/html">

    <div>
        <div id="cp2" class="input-group" title="Using input value">
          <input name="{%=key%}" type="text"
              {% if (typeof value !== 'undefined' && value != false) { %} value="{%=value%}" {% } %}
              class="form-control"/>
          <span class="input-group-append">
            <span class="input-group-text colorpicker-input-addon"><i></i></span>
          </span>
        </div>
    </div>

</script>

<script id="vvveb-input-numberinput" type="text/html">
    <div>
        <input name="{%=key%}" type="number" value="{%=value%}"
              {% if (typeof min !== 'undefined' && min != false) { %}min="{%=min%}"{% } %}
              {% if (typeof max !== 'undefined' && max != false) { %}max="{%=max%}"{% } %}
              {% if (typeof step !== 'undefined' && step != false) { %}step="{%=step%}"{% } %}
        class="form-control"/>
    </div>
</script>

<script id="vvveb-input-button" type="text/html">
    <div>
        <button class="btn btn-sm btn-primary" {% if (typeof disabled !== 'undefined' && disabled == true) { %} disabled{% } %}>
            <i class="la  {% if (typeof icon !== 'undefined') { %} {%=icon%} {% } else { %} la-plus {% } %} la-lg"></i> {%=text%}
        </button>
    </div>
</script>

<script id="vvveb-input-edwbutton" type="text/html">
    <div>
        <button class="{%if (typeof extraclasses !== undefined) { %}{%=extraclasses%} {% } %}">
            <i class="fa  {% if (typeof icon !== 'undefined') { %} {%=icon%} {% } else { %} fa-plus {% } %}"></i>
            {%=text%}
        </button>
    </div>
</script>

<script id="vvveb-input-edwbuttonwithtext" type="text/html">
    <div class="{%if (typeof wrapperclasses !== undefined) { %}{%=wrapperclasses%} {% } %}">
        <div class="titletext ellips ellips-2">{%=titletext%}</div>
        <button class="{%if (typeof extraclasses !== undefined) { %}{%=extraclasses%} {% } %}">
            <i class="fa  {% if (typeof icon !== 'undefined') { %} {%=icon%} {% } else { %} fa-plus {% } %}"></i>
            {%=text%}
        </button>
    </div>
</script>

<script id="vvveb-input-linkbutton" type="text/html">
    <div>
        <button class="btn btn-sm btn-outline-light
            {% if (typeof className !== 'undefined') { %} {%=className%}
            {% } else { %} text-danger {% } %}">
            <i class="fa  {% if (typeof icon !== 'undefined') { %} {%=icon%} {% } else { %} fa-trash {% } %}"></i>
            {%=text%}
        </button>
    </div>
</script>

<script id="vvveb-input-cssunitinput" type="text/html">
    <div class="input-group css-unit" id="cssunit-{%=key%}">
        <input name="number" type="number"  {% if (typeof value !== 'undefined' && value != false) { %} value="{%=value%}" {% } %}
              {% if (typeof min !== 'undefined' && min != false) { %}min="{%=min%}"{% } %}
              {% if (typeof max !== 'undefined' && max != false) { %}max="{%=max%}"{% } %}
              {% if (typeof step !== 'undefined' && step != false) { %}step="{%=step%}"{% } %}
        class="form-control"/>
        <select class="form-select small-arrow" name="unit">
            <option value="em">em</option>
            <option value="rem">rem</option>
            <option value="px">px</option>
            <option value="%">%</option>
            <option value="vw">vw</option>
            <option value="vh">vh</option>
            <option value="ex">ex</option>
            <option value="ch">ch</option>
            <option value="cm">cm</option>
            <option value="mm">mm</option>
            <option value="in">in</option>
            <option value="pt">pt</option>
            <option value="auto">auto</option>
            <option value="">-</option>
        </select>
    </div>

</script>


<script id="vvveb-filemanager-folder" type="text/html">
    <li data-folder="{%=folder%}" class="folder">
        <label for="{%=folder%}"><span>{%=folderTitle%}</span></label> <input type="checkbox" id="{%=folder%}" />
        <ol></ol>
    </li>
</script>

<script id="vvveb-filemanager-page" type="text/html">
    <li data-url="{%=url%}" data-file="{%=file%}" data-page="{%=name%}"
        class="file{% if (typeof className !== 'undefined') { %} {%=className%}{% } %}">
        <label for="{%=name%}" {% if (typeof description !== 'undefined') { %} title="{%=description%}" {% } %}>
            <span>{%=title%}</span>
            <div class="file-actions">
                <button href="#" class="delete btn btn-outline-danger" title="Delete"><i class="la la-trash"></i></button>
                <a href="{%=url%}" target="_blank"
                    class="view btn btn-outline-primary" title="View page">
                    <i class="la la la-external-link-alt"></i></a>
                <button href="#" class="rename btn btn-outline-primary" title="Rename"><i class="la la-pen"></i></button>
            </div>
        </label> <input type="checkbox" id="{%=name%}" />
        <!-- <ol></ol> -->
    </li>
</script>

<script id="vvveb-filemanager-component" type="text/html">
    <li data-url="{%=url%}" data-component="{%=name%}" class="component">
        <a href="{%=url%}"><span>{%=title%}</span></a>
    </li>
</script>

<script id="vvveb-breadcrumb-navigaton-item" type="text/html">
    <li class="breadcrumb-item"><a href="#"
        {% if (typeof className !== 'undefined') { %}class="{%=className%}"{% } %}>{%=name%}</a></li>
</script>

<script id="vvveb-input-sectioninput" type="text/html">
    <div>
        {% var namespace = '-' + Math.floor(Math.random() * 1000); %}
        <label class="header" data-header="{%=key%}"
            for="header_{%=key%}{%=namespace%}"
            {% if (typeof group !== 'undefined' && group != null) { %}data-group="{%=group%}" {% } %}>
            <span>{%=header%}</span>
            <div class="header-arrow"></div>
        </label>
        <input class="header_check" type="checkbox"
            {% if (typeof expanded !== 'undefined' && expanded == false) { %}
            {% } else { %}checked="true"{% } %}
            id="header_{%=key%}{%=namespace%}">
        <div class="section row" data-section="{%=key%}"
            {% if (typeof group !== 'undefined' && group != null) { %}data-group="{%=group%}" {% } %}></div>
    </div>
</script>



<script id="vvveb-property" type="text/html">
    <div class="m-0 p-0
        {% if(typeof edwclasses !== 'undefined' && edwclasses!=false) { %} {%=edwclasses%} {%}%}
        {% if (typeof col !== 'undefined' && col != false) { %} col-sm-{%=col%}
        {% } else { %}row{% } %}
        {% if (typeof inline !== 'undefined' && inline == true) { %}inline{% } %} "
        data-key="{%=key%}"
        {% if (typeof group !== 'undefined' && group != null) { %}data-group="{%=group%}" {% } %}>
        {% if (typeof name !== 'undefined' && name != false) { %}
        <label class="{% if (typeof inline === 'undefined' ) { %}col-sm-4{% } %}
            form-label" for="input-model">{%=name%}</label>
        {% } %}
        <div class="{% if (typeof inline === 'undefined') { %}col-sm-{%
            if (typeof name !== 'undefined' && name != false) { %}8{%
            } else { %}12{% } } %} input">
    </div>
    </div>
</script>

<script id="vvveb-input-autocompletelist" type="text/html">

    <div>
        <input name="{%=key%}" type="text" class="form-control"/>

        <div class="form-control autocomplete-list" style="min-height: 150px; overflow: auto;">
                  </div>
                  </div>

</script>

<script id="vvveb-input-tagsinput" type="text/html">

    <div>
        <div class="form-control tags-input" style="height:auto;">


                <input name="{%=key%}" type="text" class="form-control" style="border:none;min-width:60px;"/>
                  </div>
                  </div>

</script>

<script id="vvveb-input-noticeinput" type="text/html">
    <div>
        <div class="alert alert-dismissible fade show alert-{%=type%}" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <strong class="d-block mb-1">{%=title%}</strong>

            {%=text%}
        </div>
    </div>
</script>

<script id="vvveb-section" type="text/html">
    {% var suffix = Math.floor(Math.random() * 10000); %}

    <div class="section-item" draggable="true">
        <div class="controls">
            <div class="handle"></div>
            <div class="info">
                <div class="name">{%=name%}
                    <div class="type">{%=type%}</div>
                </div>
            </div>
            <div class="buttons">
                <a class="delete-btn" href="" title="Remove section"><i class="la la-trash text-danger"></i></a>
                <!--
                <a class="up-btn" href="" title="Move element up"><i class="la la-arrow-up"></i></a>
                <a class="down-btn" href="" title="Move element down"><i class="la la-arrow-down"></i></a>
                -->
                <a class="properties-btn" href="" title="Properties"><i class="icon-settings-outline"></i></a>
        </div>
        </div>


        <input class="header_check" type="checkbox" id="section-components-{%=suffix%}">

        <label for="section-components-{%=suffix%}">
            <div class="header-arrow"></div>
        </label>

        <div class="tree">
            <ol>
                <!--
                <li data-component="Products" class="file">
                    <label for="idNaN" style="background-image:url(/js/vvvebjs/icons/products.svg)"><span>Products</span></label>
                    <input type="checkbox" id="idNaN">
                </li>
                <li data-component="Posts" class="file">
                    <label for="idNaN" style="background-image:url(/js/vvvebjs/icons/posts.svg)"><span>Posts</span></label>
                    <input type="checkbox" id="idNaN">
                </li>
                -->
            </ol>
        </div>
    </div>

</script>


<script id="vvveb-input-layoutselector" type="text/html">
    <div class="layoutselector">
        {% for ( var i = 0; i < options.length; i++ ) { %}
        <label class="epb-ly-sele" title="{%=options[i].title%}">
            <input name="{%=key%}" class="epb-ly-sele-input" type="radio" value="{%=options[i].value%}" id="{%=key%}{%=i%}" {%if
                (options[i].checked)
                {
                %}checked="{%=options[i].checked%}" {%
                }
                %} />
            <img class="epb-ly-sele-img" src="{%=options[i].img%}" alt="{%=options[i].text%}" />
        </label>

        {% } %}
    </div>
</script>

<script id="vvveb-input-multiselect" type="text/html">
    <div>
        <select multiple="multiple" class="form-select multiselect" id="{%=eleid%}">
            {% for ( var i = 0; i < options.length; i++ ) { %}
            <option value="{%=options[i].value%}">{%=options[i].text%}</option>
            {% } %}
        </select>
    </div>
</script>

<script id="vvveb-input-edwcustomdropdown" type="text/html">
    <div class="dropdown {%=edwclasses%} " id="{%=eleid%}">
        <button class="btn  dropdown-toggle" type="button"
            id="edwcustomdropdownmenutooglebtn"
            data-toggle="dropdown" data-bs-toggle="dropdown"
            aria-expanded="false">
            {%=buttontext%}
            <img src="../edwiserpagebuilder/libs/builder/edw_icons/DownArrow.svg" alt="" id="yui_3_18_1_1_1724150271575_75">
        </button>
        <ul class="dropdown-menu" aria-labelledby="edwcustomdropdownmenutooglebtn" id="edwcustomdropdownmenu">
            <!-- Options will be dynamically added here -->
            {%=initialhtml%}
            {% for ( var i = 0; i < options.length; i++ ) { %}
            <li class="course-list-item">
                <input name="{%=key%}" class="form-check-input mr-2" type="checkbox" value="{%=options[i].value%}" {%if
                    (options[i].checked)
                    {
                    %}checked="{%=options[i].checked%}" {%
                    }
                    %} />
                <span class="text">{%=options[i].text%}</span>
            </li>

            {% } %}

        </ul>
    </div>
</script>

<script id="vvveb-section-rowcreator" type="text/html">
    <div>
        <section class="row p-2">
            {% for ( var i = 0; i < rows; i++ ) { %}
                <div class="col has-dummy">
                    <div class="add-content"
                        style="margin: 20px;border: 1px dashed #ccc;height: 50px;
                        display: flex;align-items: center;justify-content: center;"
                        data-vvveb-disabled-area contenteditable="false">
                        <img src="../../local/edwiserpagebuilder/libs/builder/edw_icons/Add.svg" alt="">
                    </div>
                </div>
            {% } %}
        </section>

    </div>
</script>
<!--// end templates -->


<div id="tree-list">
    <div class="header">
        <div>Navigator</div>
        <button class="btn btn-sm" data-vvveb-action="toggleTreeList" aria-pressed="true">
            <i class="icon-close"></i>
        </button>
    </div>
    <div class="tree">
        <ol>
            <!--
            <li data-component="Products" class="file">
                <label for="idNaN" style="background-image:url(/js/vvvebjs/icons/products.svg)"><span>Products</span></label>
                <input type="checkbox" id="idNaN">
            </li>
            <li data-component="Posts" class="file">
                <label for="idNaN" style="background-image:url(/js/vvvebjs/icons/posts.svg)"><span>Posts</span></label>
                <input type="checkbox" id="idNaN">
            </li>
            -->
        </ol>
    </div>
</div>

<!-- code editor modal -->
<div class="modal modal-full fade" id="codeEditorModal" tabindex="-1" aria-labelledby="codeEditorModal" role="dialog"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <input type="hidden" name="file" value="">

            <div class="modal-header justify-content-between">
                <span class="modal-title"></span>
                <div class="float-end">
                    <button type="button" class="btn btn-light border btn-icon" data-bs-dismiss="modal"><i
                            class="la la-times"></i>Close</button>

                    <button class="btn btn-primary btn-icon save-btn" title="Save changes" id="save-btn">
                        <span class="loading d-none">
                            <i class="la la-save"></i>
                            <span class="spinner-border spinner-border-sm align-middle" role="status"
                                aria-hidden="true">
                            </span>
                            <span>Saving </span> ... </span>

                        <span class="button-text">
                            <i class="la la-save"></i> <span>Save changes</span>
                        </span>
                    </button>
                </div>
            </div>

            <div class="modal-body p-0">
                <textarea class="form-control h-100"></textarea>
            </div>


        </div>
    </div>
</div>

<!-- export html modal-->
<div class="modal fade" id="textarea-modal" tabindex="-1" role="dialog" aria-labelledby="textarea-modal"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <p class="modal-title text-primary"><i class="la la-lg la-save"></i> Export html</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <!-- span aria-hidden="true"><small><i class="la la-times"></i></small></span -->
                </button>
            </div>
            <div class="modal-body">

                <textarea rows="25" cols="150" class="form-control"></textarea>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-lg" data-bs-dismiss="modal"><i
                        class="la la-times"></i> Close</button>
            </div>
        </div>
    </div>
</div>

<!-- message modal-->
<div class="modal fade" id="message-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <p class="modal-title text-primary"><i class="la la-lg la-comment"></i> VvvebJs</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <!-- span aria-hidden="true"><small><i class="la la-times"></i></small></span -->
                </button>
            </div>
            <div class="modal-body">
                <p>Page was successfully saved!.</p>
            </div>
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-primary">Ok</button> -->
                <button type="button" class="btn btn-secondary btn-lg" data-bs-dismiss="modal"><i
                        class="la la-times"></i> Close</button>
            </div>
        </div>
    </div>
</div>

<!-- new page modal-->
<div class="modal fade" id="new-page-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">

        <form action="save.php">

            <div class="modal-content">
                <div class="modal-header">
                    <span class="modal-title text-primary fw-normal"><i class="la la-lg la-file"></i> New page</span>
                    <button type="button" class="btn-close p-0 me-1" data-bs-dismiss="modal" aria-label="Close">
                        <!-- span aria-hidden="true"><small><i class="la la-times"></i></small></span -->
                    </button>
                </div>

                <div class="modal-body text">
                    <div class="mb-3 row" data-key="type">
                        <label class="col-sm-3 col-form-label">
                            Template
                            <abbr title="The contents of this template will be used as a start for the new template">
                                <i class="la la-lg la-question-circle text-primary"></i>
                            </abbr>

                        </label>
                        <div class="col-sm-9 input">
                            <div>
                                <select class="form-select" name="startTemplateUrl">
                                    <option value="new-page-blank-template.html">Blank Template</option>
                                    <option value="demo/narrow-jumbotron/index.html">Narrow jumbotron</option>
                                    <option value="demo/album/index.html">Album</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3 row" data-key="href">
                        <label class="col-sm-3 col-form-label">Page name</label>
                        <div class="col-sm-9 input">
                            <div>
                                <input name="title" type="text" value="My page" class="form-control"
                                    placeholder="My page" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3 row" data-key="href">
                        <label class="col-sm-3 col-form-label">File name</label>
                        <div class="col-sm-9 input">
                            <div>
                                <input name="file" type="text" value="my-page.html" class="form-control"
                                    placeholder="my-page.html" required>
                            </div>
                        </div>
                    </div>

                    <!--
        <div class="mb-3 row" data-key="href">
             <label class="col-sm-3 form-label">Url</label>
            <div class="col-sm-9 input">
                <div>
                    <input name="url" type="text" value="my-page.html" class="form-control" placeholder="/my-page.html" required>
                </div>
            </div>
        </div>
        -->

                    <div class="mb-3 row" data-key="href">
                        <label class="col-sm-3 col-form-label">Save to folder</label>
                        <div class="col-sm-9 input">
                            <div>
                                <input name="folder" type="text" value="my-pages" class="form-control" placeholder="/"
                                    required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary btn-icon" type="reset" data-bs-dismiss="modal"><i
                            class="la la-times"></i> Cancel</button>
                    <button class="btn btn-primary btn-icon" type="submit"><i class="la la-check"></i> Create
                        page</button>
                </div>
            </div>

        </form>

    </div>
</div>

<!-- save toast -->
<div class="toast-container position-fixed end-0 bottom-0 me-3 mb-3" id="top-toast">
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header text-white">
            <strong class="me-auto">Page save</strong>
            <!-- <small class="badge bg-success">status</small> -->
            <button type="button" class="btn-close text-white px-2" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body ">
            <div class="flex-grow-1">
                <div class="message">Elements saved!
                    <div>Template backup was saved!</div>
                    <div>Template was saved!</div>
                </div>
                <!--
              <div><a class="btn btn-success  btn-icon btn-sm w-100 mt-2" href="">View page</a></div>
              -->
            </div>
        </div>
    </div>
</div>

<div id="device-failure">
    <div class="modal">
        <div class="modal-header">
            <h3 class="m-0 p-0">Device not supported</h3>
        </div>
        <div class="modal-body">Current device does not support editing</div>
    </div>
</div>

<div id="epbtaostwrap" aria-live="polite" aria-atomic="true" style="">
    <div style="position: absolute; top: 10px; left: 50%; transform: translate(-50%); z-index: 2;">
        <div id="epb-toast-message" class="alert d-none" role="alert" aria-live="assertive" aria-atomic="true"
            style="width:fit-content;max-width:500px">
            <div class="toast-msg"></div>
            <button type="button" class="close ml-1" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    </div>
</div>
<div id="edwiser-page-builder-fp" class="modal fade modal-static"
    tabindex="-1" role="modal" aria-labelledby="my-modal-title"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xs">
        <div class="modal-content">
            <div class="modal-header d-block border-0 p-0">
                <div class="d-flex mx-4 mt-4">
                    <h4 class="">
                        <?= $strmediaselpopuptite ?>
                    </h4>
                    <button type="button" class="close ml-auto" data-dismiss="modal" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="edw-icon edw-icon-Cancel small"></span>
                    </button>

                </div>
                <ul class="nav nav-tabs" id="file-piker-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab"
                            data-bs-toggle="tab" href="#edwiser-tab-file-upload"
                            role="tab" aria-controls="blocks"
                            aria-selected="true">
                            <span>
                                <?= $strmediaselpopuptab1 ?>
                            </span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab"
                            data-bs-toggle="tab" href="#edwiser-tab-file-selector"
                            role="tab" aria-controls="components"
                            aria-selected="false">
                            <span>
                                <?= $strmediaselpopuptab2 ?>
                            </span></a>
                    </li>
                </ul>
            </div>
            <div class="modal-body d-flex p-0">
                <div class="flex-grow-1 tab-content">
                    <div id="epbfm-savefile" class="alert d-none" role="alert"></div>
                    <div id="edwiser-tab-file-upload"
                        class="tab-pane fade p-4 flex-grow-1" role="tabpanel"
                        aria-labelledby="edwiser-tab-file-select"></div>
                    <div id="edwiser-tab-file-selector"
                        class="tab-pane fade show active flex-grow-1"
                        role="tabpanel" aria-labelledby="edwiser-tab-file-upload">
                        <div class="d-flex flex- justify-content-between pl-4 w-100">
                            <div id="epb_media_list_wrap"></div>
                            <div id="epb_media_list_empty">
                                <?= $strnomediafile ?>
                            </div>
                            <input type="hidden" name="file_list_fromlimit" id="file_list_fromlimit" value="0" />
                            <div class="border bg-grey-200 media-details-wrap">
                                <div class="media-details d-none p-3" id="media-details">
                                    <h5 class="text-uppercase bold text-black-50">
                                        <?= $strmediadetails ?>
                                    </h5>
                                    <div id="epbfm-deletefile" class="d-none alert" role="alert"></div>
                                    <div class="details">
                                        <img class="epb-selected-file" id="epb-selected-file"
                                            src="" alt="" width="200" height="auto" />
                                        <div class="bold" id="epbmd-name"></div>
                                        <div id="epbmd-time"></div>
                                        <div id="epbmd-size"></div>
                                        <div id="epbmd-dimensions"></div>
                                        <input type="hidden" name="epbfm-file-name" id="epbfm-file-name" value="" />
                                        <input type="hidden" name="epbfm-file-path" id="epbfm-file-path" value="" />
                                        <input type="hidden" name="epbfm-file-id" id="epbfm-file-id" value="" />
                                        <input type="hidden" name="epbfm-media-id" id="epbfm-media-id" value="" />
                                        <button type="button" id="epbmd-btn-delete-file" class="p-0 btn btn-link text-danger">
                                            <?= $strmediadeletebtn ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-primary ml-auto d-none mt-2" id="epb-save-popup-media">
                    <?= $strmediasavebtn ?>
                </button>
                <button class="btn btn-primary ml-auto epb-btn-setfile disabled"
                    id="epb-btn-setfile" data-dismiss="modal"
                    data-bs-dismiss="modal" aria-label="Close">
                    <?= $strmediaselectbtn ?>
                </button>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery.hotkeys.js"></script>

<!-- bootstrap-->
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script src="js/beautify.min.js"></script>
<script src="js/beautify-css.min.js"></script>
<!-- <script src="js/beautify-html.min.js"></script> -->

<script src="libs/builder/builder.js"></script>

<!-- <script src="libs/builder/inputs.js"></script> -->

<!-- media gallery -->
<link href="libs/media/media.css" rel="stylesheet">
<script>
    var mediaPath = "<?= $mediapath ?>";
    var mediaScanUrl = "scan.php";
    var uploadUrl = "upload.php";
    Vvveb.themeBaseUrl = 'demo/landing/';
</script>
<script src="libs/media/media.js"></script>
<!--
<script src="libs/media/openverse.js"></script>
-->
<!-- <script src="libs/builder/plugin-media.js"></script> -->

<!-- code mirror - code editor syntax highlight -->
<link href="libs/codemirror/lib/codemirror.css" rel="stylesheet" />
<link href="libs/codemirror/theme/material.css" rel="stylesheet" />
<script src="libs/codemirror/lib/codemirror.js"></script>
<script src="libs/codemirror/lib/xml.js"></script>
<script src="libs/codemirror/lib/css.js"></script>
<script src="libs/codemirror/lib/formatting.js"></script>
<script src="libs/builder/plugin-codemirror.js"></script>


<!-- jszip - download page as zip -->
<script src="libs/jszip/jszip.min.js"></script>
<script src="libs/jszip/filesaver.min.js"></script>
<script src="libs/builder/plugin-jszip.js"></script>


<!-- autocomplete plugin used by autocomplete input-->
<!--
<script src="libs/autocomplete/jquery.autocomplete.js"></script>
-->
