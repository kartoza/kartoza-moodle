<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

declare(strict_types=1);

namespace bookingextension_agent\local\wizard\services;

use bookingextension_agent\local\wizard\skill_discovery;
use bookingextension_agent\local\wizard\interfaces\skill_catalog;

/**
 * Engine adapter: skill_catalog backed by skill_discovery.
 *
 * @package    bookingextension_agent
 * @copyright  2026 Wunderbyte GmbH <info@wunderbyte.at>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class skill_catalog_discovery implements skill_catalog {
    /**
     * Return the skill instances registered for a component.
     *
     * @param string $component Frankenstyle component name.
     * @return array Skill instances for the component.
     */
    public function instances(string $component): array {
        return skill_discovery::get_skill_instances($component);
    }

    /**
     * Return diagnostics from the last skill discovery run.
     *
     * @return array Discovery diagnostics.
     */
    public function diagnostics(): array {
        return skill_discovery::get_last_diagnostics();
    }
}
