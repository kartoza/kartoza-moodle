<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Defines all the restore steps that will be used by the restore_booking_activity_task
 *
 * @package mod_booking
 * @copyright 2012 onwards David Bogner
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use mod_booking\booking_option;
use mod_booking\local\connectedcourse;
use mod_booking\teachers_handler;

/**
 * Structure step to restore one booking activity
 */
class restore_booking_activity_structure_step extends restore_activity_structure_step {
    /**
     * Maps the courseid of a connected Moodle course to the id of the copy made for it during
     * this restore. Several booking options may share one connected course, and they must keep
     * sharing it afterwards, so every source course is copied at most once per restore.
     *
     * @var array
     */
    protected $connectedcoursemap = [];

    /**
     * Function that will return the structure to be processed by this restore_step.
     * Must return one array of @restore_path_element elements
     *
     * @return mixed
     * @throws base_step_exception
     * @throws dml_exception
     */
    protected function define_structure() {
        $paths = [];
        $userinfo = $this->get_setting_value('userinfo');

        $paths[] = new restore_path_element('booking', '/activity/booking');

        $paths[] = new restore_path_element(
            'booking_category',
            '/activity/booking/categories/caegory'
        );
        $paths[] = new restore_path_element(
            'booking_tag',
            '/activity/booking/tags/tag'
        );
        $paths[] = new restore_path_element(
            'booking_history',
            '/activity/booking/history/historyitem'
        );
        $paths[] = new restore_path_element(
            'booking_other',
            '/activity/booking/options/option/others/other'
        );

        $paths[] = new restore_path_element(
            'booking_customfield',
            '/activity/booking/customfields/customfield'
        );

        // Only restore booking rules, if config setting is set. Rules are scoped to the
        // instance context, so they are independent of the booking options setting below.
        if (get_config('booking', 'duplicationrestorerules')) {
            $paths[] = new restore_path_element(
                'booking_rule',
                '/activity/booking/bookingrules/bookingrule'
            );
        }

        // If we don't have booking options, of course we don't have any of the below settings.
        if (get_config('booking', 'duplicationrestorebookings')) {
            $paths[] = new restore_path_element(
                'booking_option',
                '/activity/booking/options/option'
            );
            $paths[] = new restore_path_element(
                'booking_optiondate',
                '/activity/booking/optiondates/optiondate'
            );

            // Only restore teachers, if config setting is set.
            if (get_config('booking', 'duplicationrestoreteachers')) {
                $paths[] = new restore_path_element(
                    'booking_teacher',
                    '/activity/booking/teachers/teacher'
                );
            }

            // Only restore prices, if config setting is set.
            if (get_config('booking', 'duplicationrestoreprices')) {
                $paths[] = new restore_path_element(
                    'booking_price',
                    '/activity/booking/options/option/prices/price'
                );
            }

            // Only restore entitiesrelations if config setting is set.
            if (get_config('booking', 'duplicationrestoreentities')) {
                // For options.
                $paths[] = new restore_path_element(
                    'booking_option_entity',
                    '/activity/booking/options/option/entitiesrelationsforoptions/entitiesrelationforoption'
                );
                // For optiondates.
                $paths[] = new restore_path_element(
                    'booking_optiondate_entity',
                    '/activity/booking/optiondates/optiondate/entitiesrelationsforoptiondates/entitiesrelationforoptiondate'
                );
            }

            // Only restore subbookingoptions (aka subbookings), if config setting is set.
            if (get_config('booking', 'duplicationrestoresubbookings')) {
                $paths[] = new restore_path_element(
                    'booking_subbookingoption',
                    '/activity/booking/options/option/subbookingoptions/subbookingoption'
                );
            }

            if (class_exists('local_shopping_cart\shopping_cart')) {
                $paths[] = new restore_path_element(
                    'booking_option_shoppingcartiteminfo',
                    '/activity/booking/options/option/shoppingcartiteminfoforoptions/shoppingcartiteminfoforoption'
                );
            }
        }

        if ($userinfo) {
            $paths[] = new restore_path_element('booking_answer', '/activity/booking/answers/answer');
        }

        // Return the paths wrapped into standard activity structure.
        return $this->prepare_activity_structure($paths);
    }

    /**
     * Processes the instance.
     *
     * @param array $data The instance data from the backup file.
     * @throws base_step_exception
     * @throws dml_exception
     * @throws file_exception
     * @throws stored_file_creation_exception
     */
    protected function process_booking($data) {
        global $DB;

        $data = (object) $data;
        $data->course = $this->get_courseid();
        $data->timemodified = $this->apply_date_offset($data->timemodified);

        $oldbookingid = $data->id;

        // Insert the booking record.
        $newbookingid = $DB->insert_record('booking', $data);
        // Immediately after inserting "activity" record, call this.
        $this->apply_activity_instance($newbookingid);

        $cmid = null;
        $cmidsql = "SELECT cm.id AS cmid
                    FROM {course_modules} cm
                    LEFT JOIN {modules} m
                    ON m.id = cm.module
                    WHERE m.name = 'booking' AND cm.instance = :newbookingid";

        if ($cmidrecord = $DB->get_record_sql($cmidsql, ['newbookingid' => $newbookingid])) {
            $cmid = $cmidrecord->cmid;

            // Also copy associated header images (images on instance level).
            $filesql = "SELECT id, component, contextid, filepath, filename, userid, source, author, license
                        FROM {files}
                        WHERE component = 'mod_booking'
                        AND filearea = 'bookingimages'
                        AND filesize > 0
                        AND mimetype LIKE 'image%'
                        AND itemid = :oldbookingid";

            $params = [
                'oldbookingid' => $oldbookingid,
            ];

            $fs = get_file_storage();
            $oldimagefiles = $DB->get_records_sql($filesql, $params);
            foreach ($oldimagefiles as $oldimagefile) {
                // Prepare file record object.
                $fileinfo = [
                    'component' => 'mod_booking',
                    'filearea' => 'bookingimages',
                    'itemid' => $oldbookingid,
                    'contextid' => $oldimagefile->contextid,
                    'filepath' => $oldimagefile->filepath,
                    'filename' => $oldimagefile->filename,
                    'userid' => $oldimagefile->userid,
                    'source' => $oldimagefile->source,
                    'author' => $oldimagefile->author,
                    'license' => $oldimagefile->license,
                ];

                // Get file.
                $file = $fs->get_file(
                    $fileinfo['contextid'],
                    $fileinfo['component'],
                    $fileinfo['filearea'],
                    $fileinfo['itemid'],
                    $fileinfo['filepath'],
                    $fileinfo['filename']
                );

                // Read contents of the old image file.
                if ($file && $cmid) {
                    $contents = $file->get_content();
                    // Now store a copied image file with the new bookingid.
                    $fileinfo['itemid'] = $newbookingid; // New bookingid of the instance duplicate.
                    // Important: set the correct context of the new instance.
                    $context = context_module::instance($cmid);
                    $fileinfo['contextid'] = $context->id;
                    $fs->create_file_from_string($fileinfo, $contents);
                }
            }
        }
    }

    /**
     * This is executed every time we have one /MOODLE_BACKUP/COURSE/MODULES/MOD/CHOICE/OPTIONS/OPTION
     * data available
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     * @throws file_exception
     * @throws restore_step_exception
     * @throws stored_file_creation_exception
     */
    protected function process_booking_option($data) {
        global $DB;

        $data = (object) $data;
        $oldid = $data->id;

        $data->bookingid = $this->get_new_parentid('booking');
        $data->timemodified = $this->apply_date_offset($data->timemodified);

        // Map user IDs for usercreated and usermodified.
        if (!empty($data->usercreated)) {
            $data->usercreated = $this->get_mappingid('user', $data->usercreated) ?: 0;
        }
        if (!empty($data->usermodified)) {
            $data->usermodified = $this->get_mappingid('user', $data->usermodified) ?: 0;
        }

        $this->remap_connected_course($data);

        $cmid = null;
        $cmidsql = "SELECT cm.id AS cmid
                    FROM {course_modules} cm
                    LEFT JOIN {modules} m
                    ON m.id = cm.module
                    WHERE m.name = 'booking' AND cm.instance = :newbookingid";

        if ($cmidrecord = $DB->get_record_sql($cmidsql, ['newbookingid' => $data->bookingid])) {
            $cmid = $cmidrecord->cmid;
        }

        // Calendarid should not be copied or set.
        $data->addtocalendar = 0;
        $data->calendarid = 0;

        // Unique identifier must not be copied, instead we create a new random one.
        if (empty($data->identifier) || $DB->record_exists('booking_options', ['identifier' => $data->identifier])) {
            // If the identifier already exists, we need to create a new one.
            $data->identifier = booking_option::create_truly_unique_option_identifier();
        }

        $newitemid = $DB->insert_record('booking_options', $data);

        /* The connected Moodle course is not part of this backup - only its id is - so the
        restored option points at the very same course as the original. When the site asks for
        it, duplicate that course as well, so the copy is a self contained duplicate. */
        $this->duplicate_connected_course((int) $newitemid, (int) ($data->courseid ?? 0));

        // Also copy custom fields (e.g. sports).
        // Note: Do not confuse normal customfields (stored in customfield_data) with booking_customfields (used for optiondates).
        // This SQL will only select customfields for the mod_booking component.
        $sql = "SELECT cfd.*
            FROM {customfield_data} cfd
            LEFT JOIN {customfield_field} cff
            ON cff.id = cfd.fieldid
            LEFT JOIN {customfield_category} cfc
            ON cfc.id = cff.categoryid
            WHERE cfc.component = 'mod_booking'
            AND cfc.area = 'booking'
            AND cfd.instanceid = :oldid";

        $params = [
            'oldid' => $oldid,
        ];

        $oldcustomfields = $DB->get_records_sql($sql, $params);
        foreach ($oldcustomfields as $cf) {
            unset($cf->id);
            $cf->timecreated = time();
            $cf->timemodified = time();
            $cf->instanceid = $newitemid;
            $DB->insert_record('customfield_data', $cf);
        }

        // Also copy image files associated with the booking option.
        $filesql = "SELECT id, component, contextid, filepath, filename, userid, source, author, license
            FROM {files}
            WHERE component = 'mod_booking'
            AND filearea = 'bookingoptionimage'
            AND filesize > 0
            AND mimetype LIKE 'image%'
            AND itemid = :oldoptionid";

        $params = [
            'oldoptionid' => $oldid,
        ];

        $fs = get_file_storage();
        $oldimagefiles = $DB->get_records_sql($filesql, $params);
        foreach ($oldimagefiles as $oldimagefile) {
            // Prepare file record object.
            $fileinfo = [
                'component' => 'mod_booking',
                'filearea' => 'bookingoptionimage',
                'itemid' => $oldid,
                'contextid' => $oldimagefile->contextid,
                'filepath' => $oldimagefile->filepath,
                'filename' => $oldimagefile->filename,
                'userid' => $oldimagefile->userid,
                'source' => $oldimagefile->source,
                'author' => $oldimagefile->author,
                'license' => $oldimagefile->license,
            ];

            // Get file.
            $file = $fs->get_file(
                $fileinfo['contextid'],
                $fileinfo['component'],
                $fileinfo['filearea'],
                $fileinfo['itemid'],
                $fileinfo['filepath'],
                $fileinfo['filename']
            );

            // Read contents of the old image file.
            if ($file && $cmid) {
                $contents = $file->get_content();
                // Now store a copied image file with the new optionid.
                // Prepare new file record object.
                $fileinfo['itemid'] = $newitemid; // New optionid of the duplicate.
                // Important: set the correct context of the new instance.
                $context = context_module::instance($cmid);
                $fileinfo['contextid'] = $context->id;
                $fs->create_file_from_string($fileinfo, $contents);
            }
        }

        $this->set_mapping('booking_option', $oldid, $newitemid);
    }

    /**
     * Make sure a restored booking option does not point at a foreign Moodle course.
     *
     * A Moodle course is never part of an activity backup - only its id is. On a restore onto
     * a DIFFERENT site that id belongs to the origin site, so keeping it would silently connect
     * the option to whichever unrelated course happens to carry that id here, or to a course
     * that does not exist at all. Neither is a connection anybody asked for.
     *
     * The one id which can be translated is the course the backup was taken from: an option
     * enrolling into that course should now enrol into the course we are restoring into.
     * Everything else loses its connection and has to be re-established by hand.
     *
     * On the same site the id is still valid and is left untouched.
     *
     * @param stdClass $data the booking option data from the backup file, modified in place
     * @return void
     */
    protected function remap_connected_course(stdClass $data) {

        if (empty($data->courseid) || $this->get_task()->is_samesite()) {
            return;
        }

        $originalcourseid = (int) ($this->get_task()->get_info()->original_course_id ?? 0);

        if (!empty($originalcourseid) && (int) $data->courseid === $originalcourseid) {
            $data->courseid = $this->get_courseid();
            return;
        }

        $data->courseid = 0;
    }

    /**
     * Duplicate the Moodle course connected to a restored booking option.
     *
     * A course is not part of an activity backup, so a restored option inherits the courseid of
     * the original and both end up enrolling into the same Moodle course. With the
     * duplicatemoodlecourses setting turned on, the connected course is copied as well and the
     * restored option is pointed at the copy.
     *
     * The copy itself is asynchronous: a course shell exists immediately, its content is filled
     * in by the core copy task on the next cron run.
     *
     * @param int $newoptionid the id of the booking option just restored
     * @param int $oldcourseid the connected course as stored in the backup file
     * @return void
     */
    protected function duplicate_connected_course(int $newoptionid, int $oldcourseid) {

        global $DB;

        if (empty($newoptionid) || empty($oldcourseid)) {
            return;
        }

        // The very same setting which already governs duplication of a single booking option.
        if (!get_config('booking', 'duplicatemoodlecourses')) {
            return;
        }

        /* On a different site the stored courseid refers to a course of the origin site and
        means nothing here, so there is nothing meaningful to copy. */
        if (!$this->get_task()->is_samesite()) {
            return;
        }

        /* Only the duplication of a single booking instance copies connected courses. A course
        copy, a course restore or a course import brings the connected course along by itself, or
        is not asked to. Above all, the course copy started here restores its own booking
        instances later - with this very step - and copying their connected courses again would
        chain one copy to the next without end. */
        if (!$this->is_activity_duplication()) {
            return;
        }

        /* An option enrolling into the very course its booking instance lives in keeps doing so.
        Copying that course would copy the booking instance along with it, and a course which
        contains its own copy is not a self contained duplicate of anything. */
        if ($oldcourseid === (int) $this->get_courseid()) {
            return;
        }

        if (!$DB->record_exists('course', ['id' => $oldcourseid])) {
            return;
        }

        // Options which shared one connected course must keep sharing it, so a source course is
        // copied only once per restore and every further option reuses that copy.
        if (isset($this->connectedcoursemap[$oldcourseid])) {
            $DB->set_field('booking_options', 'courseid', $this->connectedcoursemap[$oldcourseid], ['id' => $newoptionid]);
            return;
        }

        $newcourseid = connectedcourse::copy_course($oldcourseid);

        if (empty($newcourseid)) {
            return;
        }

        $this->connectedcoursemap[$oldcourseid] = $newcourseid;
        $DB->set_field('booking_options', 'courseid', $newcourseid, ['id' => $newoptionid]);

        /* Name the copy after the option which owns it. Only the option that actually triggered
        the copy does this - for a shared course, renaming it again for every further option
        would just leave it named after whichever option happened to come last. */
        connectedcourse::apply_naming_scheme($newcourseid, $newoptionid);

        /* The copy is asynchronous and cron rewrites the names from the copy data when it runs,
        so the naming has to be applied again afterwards. */
        connectedcourse::queue_naming_finalizer($newcourseid, $newoptionid);
    }

    /**
     * Whether this restore duplicates a single booking instance, as opposed to restoring, copying
     * or importing a whole course.
     *
     * duplicate_module() backs up one activity in import mode; a course copy, a course restore
     * or a course import backs up a whole course. Both facts are recorded in the backup itself,
     * so this is decided from the backup information and not from anything the data says.
     *
     * @return bool
     */
    protected function is_activity_duplication(): bool {
        $info = $this->get_task()->get_info();
        return ($info->type ?? '') === backup::TYPE_1ACTIVITY
            && (int) ($info->mode ?? 0) === backup::MODE_IMPORT;
    }

    /**
     * Processes booking answer data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_answer($data) {
        global $DB;

        $data = (object) $data;
        $data->bookingid = $this->get_new_parentid('booking');
        $data->optionid = $this->get_mappingid('booking_option', $data->optionid);
        $data->userid = $this->get_mappingid('user', $data->userid);
        $data->timemodified = $this->apply_date_offset($data->timemodified);
        $data->completeddate = $this->apply_date_offset($data->completeddate);

        $DB->insert_record('booking_answers', $data);
        // No need to save this mapping as far as nothing depend on it.
    }

    /**
     * Processes booking option date data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     * @throws restore_step_exception
     */
    protected function process_booking_optiondate($data) {
        global $DB;

        $data = (object) $data;
        $oldid = $data->id;

        $data->bookingid = $this->get_new_parentid('booking');
        $data->optionid = $this->get_mappingid('booking_option', $data->optionid);

        // Eventid should not be copied or set.
        $data->eventid = 0;

        $newitemid = $DB->insert_record('booking_optiondates', $data);
        $this->set_mapping('booking_optiondate', $oldid, $newitemid);
    }

    /**
     * Processes booking teacher data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     * @throws moodle_exception
     */
    protected function process_booking_teacher($data) {
        global $DB;

        $data = (object) $data;
        $data->bookingid = $this->get_new_parentid('booking');
        $data->optionid = $this->get_mappingid('booking_option', $data->optionid);
        // Only change userid, if a mapped id could be found.
        $data->userid = $this->get_mappingid('user', $data->userid, $data->userid);

        // If one ID is missing, we show a debug message and return.
        if (empty($data->bookingid)) {
            debugging('process_booking_teacher - bookingid missing for $data: ' . json_encode($data));
            return;
        }
        if (empty($data->optionid)) {
            debugging('process_booking_teacher - optionid missing for $data: ' . json_encode($data));
            return;
        }
        if (empty($data->userid)) {
            debugging('process_booking_teacher - userid missing for $data: ' . json_encode($data));
            return;
        }

        $DB->insert_record('booking_teachers', $data);

        // When inserting a new teacher, we also need to insert the teacher for each optiondate.
        teachers_handler::subscribe_teacher_to_all_optiondates($data->optionid, $data->userid);

        // No need to save this mapping as far as nothing depends on it.
    }

    /**
     * Processes booking category data.
     *
     * @param array $data The instance data from the backup file.
     * @throws base_step_exception
     * @throws dml_exception
     */
    protected function process_booking_category($data) {
        global $DB;

        $data = (object) $data;
        $data->course = $this->get_courseid();
        $DB->insert_record('booking_category', $data);
        // No need to save this mapping as far as nothing depend on it.
    }

    /**
     * Processes booking tag data.
     *
     * @param array $data The instance data from the backup file.
     * @throws base_step_exception
     * @throws dml_exception
     */
    protected function process_booking_tag($data) {
        global $DB;

        $data = (object) $data;
        $data->courseid = $this->get_courseid();
        // When duplicating this module instance, it duplicates also tags.
        // There is no need to duplicate, so before inserting, check, if tag exists.
        $nofrecords = $DB->count_records('booking_tags', ['courseid' => $data->courseid, 'tag' => $data->tag]);
        if ($nofrecords == 0) {
            $DB->insert_record('booking_tags', $data);
        }
        // No need to save this mapping as far as nothing depend on it.
    }

    /**
     * Processes booking other data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_other($data) {
        global $DB;

        $data = (object) $data;
        $data->optionid = $this->get_mappingid('booking_option', $data->optionid);
        $DB->insert_record('booking_other', $data);
        // No need to save this mapping as far as nothing depends on it.
    }
    /**
     * Processes booking history data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_history($data) {
        global $DB;
        $data = (object)$data;

        $data->bookingid = $this->get_new_parentid('booking');
        $data->optionid = $this->get_mappingid('booking_option', $data->optionid);
        $data->answerid = $this->get_mappingid('booking_answers', $data->answerid);
        $data->userid = $this->get_mappingid('user', $data->userid);

        $DB->insert_record('booking_history', $data);
    }

    /**
     * Processes booking rule data.
     *
     * Rules are linked to an instance solely by contextid (the module context). We map the old
     * context to the newly restored instance's module context and insert a fresh rule record.
     *
     * Note: rulejson->ruledata->cancelrules may reference other rule IDs; those references are
     * not remapped to the duplicated rules, so cross-rule cancellation links between two
     * instance rules will not survive duplication. This is a known limitation.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_rule($data) {
        global $DB;

        $data = (object) $data;

        $newbookingid = $this->get_new_parentid('booking');

        // Resolve the course module id of the newly restored instance (same lookup as process_booking()).
        $cmidsql = "SELECT cm.id AS cmid
                    FROM {course_modules} cm
                    LEFT JOIN {modules} m
                    ON m.id = cm.module
                    WHERE m.name = 'booking' AND cm.instance = :newbookingid";

        if (!$cmidrecord = $DB->get_record_sql($cmidsql, ['newbookingid' => $newbookingid])) {
            // Without a target context we cannot attach the rule, so skip it.
            debugging('process_booking_rule - could not find cmid for bookingid: ' . $newbookingid);
            return;
        }

        // Attach the rule to the new instance's module context.
        unset($data->id);
        $data->contextid = context_module::instance($cmidrecord->cmid)->id;

        $DB->insert_record('booking_rules', $data);
        // No need to save this mapping as far as nothing depends on it.
    }

    /**
     * Processes booking entity data for booking options.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_option_entity($data) {
        global $DB;

        // Make sure, we have local_entities installed.
        if (get_config('booking', 'duplicationrestoreentities') && class_exists('local_entities\entitiesrelation_handler')) {
            $data = (object) $data;
            if ($data->area == 'optiondate') {
                return;
            }
            if ($data->area != 'option') {
                throw new moodle_exception('entityrelationhasinvalidarea');
            }
            $data->instanceid = $this->get_mappingid('booking_option', $data->instanceid);
            $data->timecreated = time();
            $DB->insert_record('local_entities_relations', $data);
            // No need to save this mapping as far as nothing depends on it.
        }
    }

    /**
     * Processes booking entity data for booking optiondates.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_optiondate_entity($data) {
        global $DB;

        // Make sure, we have local_entities installed.
        if (get_config('booking', 'duplicationrestoreentities') && class_exists('local_entities\entitiesrelation_handler')) {
            $data = (object) $data;
            if ($data->area == 'option') {
                return;
            }
            if ($data->area != 'optiondate') {
                throw new moodle_exception('entityrelationhasinvalidarea');
            }
            $data->instanceid = $this->get_mappingid('booking_optiondate', $data->instanceid);
            $data->timecreated = time();
            $DB->insert_record('local_entities_relations', $data);
            // No need to save this mapping as far as nothing depends on it.
        }
    }

    /**
     * Processes subbooking options.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_subbookingoption($data) {
        global $DB, $USER;

        if (get_config('booking', 'duplicationrestoresubbookings')) {
            $data = (object) $data;
            $data->optionid = $this->get_mappingid('booking_option', $data->optionid);
            $data->timecreated = time();
            $data->timemodified = time();
            $data->usermodified = $USER->id;
            $DB->insert_record('booking_subbooking_options', $data);
        }
    }

    /**
     * Processes booking custom field data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_customfield($data) {
        global $DB;

        $data = (object)$data;

        $data->bookingid = $this->get_new_parentid('booking');
        $data->optionid = $this->get_mappingid('booking_option', $data->optionid);

        $data->optiondateid = $this->get_mappingid('booking_optiondate', $data->optiondateid);

        $DB->insert_record('booking_customfields', $data);
        // No need to save this mapping as far as nothing depends on it.
    }

    /**
     * Processes booking price data.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_price($data) {
        global $DB;

        $data = (object) $data;

        if ($data->area == 'option') {
            $data->itemid = $this->get_mappingid('booking_option', $data->itemid);
            $DB->insert_record('booking_prices', $data);
            // No need to save this mapping as far as nothing depends on it.
        }
        // NOTE: In the future we might want to support additional price areas!
    }

    /**
     * Processes shopping cart iteminfo data for booking options.
     *
     * @param array $data The instance data from the backup file.
     * @throws dml_exception
     */
    protected function process_booking_option_shoppingcartiteminfo($data) {
        global $DB;

        // Make sure, we have shopping cart installed.
        if (class_exists('local_shopping_cart\shopping_cart')) {
            $data = (object) $data;
            if ($data->area != 'option') {
                return;
            }
            $data->itemid = $this->get_mappingid('booking_option', $data->itemid);
            $data->timecreated = time();
            $data->timemodified = time();
            $DB->insert_record('local_shopping_cart_iteminfo', $data);
            // No need to save this mapping as far as nothing depends on it.
        }
    }

    /**
     * Post-execution processing.
     */
    protected function after_execute() {
        // Add booking related files, no need to match by itemname (just internally handled context).
        $this->add_related_files('mod_booking', 'intro', null);
        $this->add_related_files('mod_booking', 'bookingpolicy', null);
        $this->add_related_files('mod_booking', 'description', 'booking_option');
    }
}
