## Version 10.0.7 (2026110500)
* Bugfix: Recurring options: creating more than one recurring option failed with "implode(): Argument #2 ($array) must be of type ?array, string given" as soon as the booking option had a responsible contact (before version 8.18.1 also with competencies). The children were created from one shared template which the first save had already converted, so the second child received a string instead of a list. Every child now gets its own copy, and the responsible contact field accepts an already converted value.
* Bugfix: Recurring options: when an existing booking option was edited and "Repeat this booking option" was ticked in the same save, the recurring options were created from the values before the edit (e.g. the old title, without a responsible contact added in that save). The children are now created from the booking option as it was just saved.

## Version 10.0.6 (2026110300)
* New feature: The condition "Only specific user(s) are allowed to book" can remove users from its list once they have booked. The new site setting "Allow removing users from "Only specific user(s) are allowed to book" once they have booked" (Availability conditions) offers the checkbox "Remove users from the list once they have booked" in the condition and in the easy availability form, ticked by default for new options while the site allows it. As soon as a selected user books, they are taken off the list and stay booked; a booking onto the waiting list does not remove them. An emptied list then means that everybody allowed has booked and nobody else may book until users are selected again. This is decided per option, so switching the site setting off later never opens an option that uses it, and options that use it keep the checkbox visible. Imports, web services and the wizard that do not send the setting keep the stored value. The removal does not go through the option form, so it sends no change notification; it is recorded by the new event "User removed from "Only specific user(s) are allowed to book" after booking".
* New feature: New event "User added to "Only specific user(s) are allowed to book"" (selectusers_user_added), triggered for every user newly added to the list when a booking option is saved, in the full availability field as well as in the easy "select users" field; nothing is triggered for users already on the list or for removed users. The event is available to booking rules ("React on event", "Select user from event"), and the new rule template "Template - User added to "Only specific user(s) are allowed to book"" tells the user that they can now book the option, with a link to it.
* Improvement: Changes of the availability conditions of a booking option are tracked condition by condition: the change notice names the condition and shows its old and new settings (allowed users only as their number, because the change log is readable by everybody who edits the option). Differences that only come from re-serialising the same settings (key order, numeric strings, order of selected ids) no longer count as changes. Before, the whole availability JSON was compared as one string and the recorded change held the old value twice.
* Improvement: Booking rules never react on changes of the availability conditions any more: they decide who may book, not what the option is about, so e.g. adding a user to "Only specific user(s) are allowed to book" no longer sends the "booking option updated" mails of a rule to all participants, whatever the setting limiting the rule reactions to selected fields says.
* Bugfix: Bulk operations of booking options: the field selector of the bulk edit form labels the fields like the option form configuration does; the hidden fields of the form carry types, so the class names of the chosen fields (with backslashes) are no longer altered between the form steps; options of a booking instance whose course module is gone (half deleted instance) are left out of the table because they have no page to be edited on, option templates stay; the booking instance filter offers only instances that still have a course module, ordered by id, with the option templates first. In the easy availability form the checkbox of the booking closing time had the label of the opening time.
* Bugfix: The easy availability fields (opening time, closing time, "Selected users are allowed to book outside normal booking times", "Even if the course is fully booked") show their labels also when local_musi is not installed; the plugin now has its own strings and uses the wording of local_musi only when it is present.
* Bugfix: Saving an existing booking option no longer fails with "The theme has already been set up for this page" when the form is opened outside the booking page (e.g. from a list of a different page). The option form now sets the course module of the page before the option settings are loaded, because formatting their textarea customfields runs the text filters, and filters like emoticons initialise the theme, after which the course of the page can no longer be changed.
* Bugfix: Responsible contacts who may edit a booking option but are not enrolled in its course are also taken to the page of the setting "Return page after editing without course login" after saving or cancelling the option form, if "Enrol responsible contact person to connected Moodle course" is disabled (before: the dashboard). Only applies while "Course login required to edit booking options" is disabled.
* Bugfix: local_entities calendar and room occupancy: a date of a booking option that takes place in another location than the option itself is no longer reported for the option's location as well. Before, the location of the option applied to every date without a relation to the queried location, so a session moved to another room still blocked the option's room. Equipment linked to the option still applies to every session. The service provider accepts the id of the queried entity as a new optional parameter (local_entities passes it).
* Bugfix: Typo in the string "Go to booking option".

## Version 10.0.5 (2026102200)
* Improvement: Moodle 5.3 is supported. The deprecated global external_* classes are replaced by core_external\* in bookingextension_todolist (MDL-81225), \core\user::get_users_by_id(), \core\user::can_view_profile() and \core\user::update_user() are used on Moodle 5.3+ with a fallback to the old functions on 4.5 to 5.2 (MDL-82650), the Behat tests use the new secondary navigation and the duplicate tests use formatactions on 5.2+ (MDL-86858); CI runs the Moodle 5.3 tests.
* Bugfix: Accessibility on Moodle 5.3: the booking step tabs of the booking process use the Bootstrap secondary text colour (enough contrast on the light grey of Moodle 5.3, follows the dark mode), and the option links in the header of the report pages have click targets of at least 24px (WCAG 2.2).
* Bugfix: Searching in the lists of a teacher's own options (teacher page, "options I teach", trainer course list) and in lists bypassed for responsible contacts failed with an SQL error: the bypasses referred to the alias of the derived table (s1), which is out of scope once wunderbyte_table wraps the query for the full text search. They now use the bare columns and IN instead of a correlated EXISTS.
* Bugfix: The logos of the sign-in sheet (booking instance form and site settings) only accept jpg, jpeg, png and gif, because TCPDF cannot render SVG; an uploaded SVG broke the generated PDF.
* Improvement: Certificates: new field "Teachers (comma separated)" for tool_certificate templates, which lists the teachers of the option in one line separated by commas instead of one per line.
* Bugfix: The tab bar above the booking options (classic view next to the Booking Wizard view) is only shown when there is more than one view to switch between; with a single view the list is shown directly.
* Bugfix: Cancelling a purchase made through the shopping cart ("Storno" button): the cancel-until date stored at checkout is binding. Before, once the option's own "cancel until" date had passed, the cancel button disappeared even though the shopping cart still allowed the cancellation, and the option description showed the option's date instead of the one stored at checkout.
* Bugfix: New files of the bundled bookingextension/agent (the Booking Wizard engine) were ignored by git, because the .gitignore excludes every bookingextension subplugin that is not listed; the agent is listed now. New tests make sure that "Enable Booking Wizard" switches the whole engine off, not only the settings page.
* Test: The rule mail tests no longer depend on the order of the adhoc tasks (the task queries have no ORDER BY, so they failed at random on PostgreSQL).

## Version 10.0.4 (2026101500)
* Bugfix: The dates a booking option reports to local_entities (entity calendar, room occupancy) no longer depend on the current user. Before, invisible options were dropped for users without mod/booking:canseeinvisibleoptions and the links carried the user's id, and local_entities caches these dates across users, so the first viewer of an entity decided for everybody whether invisible options showed up in its calendar. Invisible options are now always reported, flagged for local_entities to hide per viewer, and their links name no user. Consequently an invisible option blocks its room for everybody, also for users who may not see it.

## Version 10.0.3 (2026101300)
* Improvement: The booking wizard is off by default on new installations; an admin switches it on with "Enable Booking Wizard". Sites that already have the setting stored keep it. All wizard settings now keep their defaults while the wizard is off and are only hidden. (Wunderbyte-GmbH/Wunderbyte-GmbH#2605)
* Improvement: Once the standalone Wizard plugin (local_wizard) is installed, the bundled booking wizard shows no settings pages any more; its settings live in the Wizard plugin. (Wunderbyte-GmbH/Wunderbyte-GmbH#2605)
* Bugfix: Unticking "Enable Booking Wizard" switches the whole booking wizard off - the navbar wand, the wizard panel on booking pages, the shortcode and all its webservices. Before, the setting was only read on the settings page and the wizard stayed visible. (Wunderbyte-GmbH/Wunderbyte-GmbH#2605)
* Bugfix: The login button shown to logged-out users in a list of booking options leads to the option (optionview.php with forcelogin) and returns there after login. Before, every rendered card overwrote the session's return address, so a plain login on a booking list or shortcode page ended on the last option of the list. (Wunderbyte-GmbH/Wunderbyte-GmbH#2571)

## Version 10.0.1 (2026100600)
* New feature: Booking wizard. mod_booking now ships the AI agent (bookingextension/agent) with its wizard and skills: users describe in their own words what they need, the wizard picks the matching skill, asks only for what is missing and shows a confirmation before anything is changed. Skills cover booking options (search, details, create, update, bulk update, slot booking and self-learning options, trainers, prices and price categories, option fields), bookings (book users, diagnose bookings, cancellations, the waiting list and notifications), booking rules from templates, courses and activities (create, scaffold content, quizzes, questions, enrolments), reports and the documentation. A person the request names as the requester (e.g. "I am the trainer") is resolved to the requester without word lists, and an ambiguous person is offered as a choice. (Wunderbyte-GmbH/Wunderbyte-GmbH#2569)

## Version 10.0.0 (2026100500)
* Improvement: The "Booking 10" pill is also shown next to "Booking documentation" in the admin link lists and on the booking category page, the documentation is new in Booking 10. (Wunderbyte-GmbH/Wunderbyte-GmbH#2445)
* Improvement: The Bookings tracker (report2.php) is the default view of the booked users. The new site setting "Bookings tracker instead of "Manage bookings"" decides where all links to the booked users of an option lead (option menu, navigation, option lists, the placeholder {bookingreportlink}, log entries, back links of the pages for booking other users, sending messages, slots etc.). New installations use the Bookings tracker; on upgrade, sites that had activated the Bookings tracker (booking/bookingstracker, also when only the admin settings log still remembers it) keep it, all other sites keep "Manage bookings". "Manage bookings" (report.php) stays reachable, shows a deprecation notice and lets administrators switch the whole site to the Bookings tracker (undo in the site administration). (Wunderbyte-GmbH/Wunderbyte-GmbH#2332)
* Improvement: End date reminders of self-learning courses (rules on "selflearningcourseenddate" with the condition "students of the booking option") also cover previously booked answers whose period still runs, e.g. a second license for another site. A reminder queued at purchase is no longer dropped when a later purchase demotes the answer to "previously booked"; ended periods still get none. (Wunderbyte-GmbH/Wunderbyte-GmbH#2545)
* Bugfix: Removing a booking option from the shopping cart restores exactly the answers its reservation had demoted to "previously booked" (book again), and nothing when no reservation was removed. Before, every removal - also a cart cleanup after a successful checkout - reactivated the previously booked answer modified last, so an old, replaced license came back next to the paid renewal (two booked answers) or was reactivated instead of it. Reservations now record the demoted answers (json demotedanswerids); reservations written before keep the old behaviour. (Wunderbyte-GmbH/Wunderbyte-GmbH#2544)
* Improvement: Self-learning courses show the remaining time of every period of the user that still runs, one line each, oldest first - also of a previous booking ("Previously booked") whose period has not ended yet, e.g. after buying a license again before the old one expired. A period starts at the booked date (timebooked) instead of the creation of the answer; old answers without a booked date still start at their creation. Applies to the option list, the option detail page and the placeholder {datesandentities}. Before, only one booked answer was used - the one modified last - so after a renewal the page could show the old period or "no access". (Wunderbyte-GmbH/Wunderbyte-GmbH#2543)
* Bugfix: The ticket scanner (scan.php), "Book all students" (bulk_book_handler.php) and the meeting link page (link.php) no longer fail with "The theme has already been set up for this page" when a customfield value of the option is rendered by a filter (e.g. a shortcode in a dynamic dropdown label). The pages loaded the option settings, which format customfields through the text filters, before require_login() set the course; they now resolve the course module first (new booking_option::get_cmid_from_optionid_before_login()) or set it on the page before loading the option. (Wunderbyte-GmbH/moodle-mod_booking#1623)
* Improvement: The number of places on the notification list (bell icon in the column of available places) is only shown to users with the new capability mod/booking:viewnotificationlistplaces (editing teachers and managers by default). Neither the setting nor the shortcode argument shownotificationlist can show it to anyone else, and the number is no longer part of the template data for them. (Wunderbyte-GmbH/Wunderbyte-GmbH#2288)
* Improvement: The field filter of booking rules also offers the poll url, the teachers poll url and the option type (0 = default, 1 = self-learning course, 2 = slot booking). A booking option without a stored type counts as a default option, just like everywhere else in the plugin. (Wunderbyte-GmbH/Wunderbyte-GmbH#2289)
* Improvement: An import (CSV, web service, test generators) can enable the trainer confirmation workflow of a booking option with the column confirmationtrainerenabled; before, the column was ignored and the option had no responsible workflow, so nobody could confirm its answers. (CI MOODLE_405_DEV, run 36720717529)
* Bugfix: Saving a booking option with the id of an entity that was deleted in local_entities (option form opened before the deletion, import, web service) no longer fails and no longer stores relations to the missing entity for the option or its dates; the id is treated as "no entity". (Wunderbyte-GmbH/moodle-mod_booking#1620)
* Bugfix: Ticket PDFs are served without browser caching. They were sent with a private six-hour cache lifetime, so a browser used by several accounts in turn could hand the cached PDF of one user to the next one logged in without asking the server. The download decision moved from lib.php into ticket_manager::can_download() (holder, "View ticket report", or entry staff of the option).
* Test: The sticky save/cancel bars of the booking option form and the booking instance form (and the sticky "you are editing" alert) stay in the flow on Behat sites, like core does for its sticky footer. The driver does not account for sticky elements when scrolling a field into view, so the bar covered the "Ticket design" field and intercepted the click (Moodle 5.1, Chrome).
* Improvement: mod_booking's own JavaScript no longer uses jQuery. The rating stars of the options overview run on a new dependency-free widget (mod_booking/starrating) that keeps the look and adds keyboard and screen reader support; the bundled jQuery Bar Rating plugin was removed. view_actions, performance_chart, the inline editor of booking notes, the booking instance template selector and the sync source selector use plain DOM APIs. The bundled Vue app (app-lazy) read the page language through jQuery; it uses the DOM now, so no AMD module of the plugin depends on jQuery any more.
* Bugfix: The ticket scanner follows the option's current "Personalised ticket" setting instead of the flag stored on the ticket when it was issued, so tickets issued before an option was switched to transferable are checked in automatically too.
* Improvement: Ticket scanner - for booking options with dates a check-in only sets the presence of the scanned date; the presence status of the whole booking is no longer touched (options without dates still set it on the booking). Tickets that are neither personalised nor subject to an identity confirmation are checked in automatically on scan: the green screen shows for two seconds (or until "Next" is pressed) and the camera returns. The last successful scan is shown below the camera. New webservice parameter autocheckin and return values autocheckin / autocheckedin on mod_booking_verify_ticket.
* Bugfix: The "Manage responses" page showed an empty presence cell for participants checked in with the ticket scanner: its presence column only knew the statuses up to "Excused", so "Checked in" was stored but not displayed. The column now uses the common list of presence statuses.
* Bugfix: In the ticket scanner "Confirm entry" and "Reject" did nothing after the first scan (no request was sent), because finally() was called on the jQuery promises returned by core/ajax.
* New feature: The ticket scanner is started per booking option (entry "Ticket scanner" in the option's action menu, or a scanner button for entry staff without editing rights) and then only accepts tickets of that option; a ticket of another event is refused with a red screen naming the event. The option's dates are offered before the first scan. The instance-wide scanner stays and moved into the "More" menu of the booking instance. New webservice parameter expectedoptionid on mod_booking_verify_ticket / mod_booking_reject_ticket (statuses wrongoption, closed).
* New feature: Who may scan is decided in one place (ticket_manager::can_scan()): holders of "Scan entry tickets", or users picked as "Additional entry staff" in the option's "Ticketing" section. The picker only offers users whose profile the editor may view (a manager sees everyone); staff a manager picked survive a teacher's save. New webservice mod_booking_search_ticketscanners.
* New feature: Availability window of the scanner per option: "Scanner available before / after each date" in the "Ticketing" section (unlimited by default, options without dates are always available). Outside the window the scanner page is blocked with the next opening time and the webservices refuse with status "closed".
* Improvement: The entry ticket can be shown as a download button with a ticket icon: "Ticket (download button)" is selectable under "Customize columns and fields" of the booking instance for "Bookings overview - page" (list and cards, the viewer's own ticket) and for "Manage responses page & Bookings tracker" (the participant's ticket, on report.php and in the bookings tracker) once entry tickets are enabled. In the overview a booking made before the ticket design was chosen gets its ticket created on first sight; participant lists only show tickets that exist.
* New feature: Entry tickets are checked in per date. For booking options with several dates the scanner records the presence for the date being admitted (stored per date in the bookings tracker, plus on the booking answer on the first admission), defaulting to the nearest date - the session running right now, else the next upcoming one - with a sticky date selection per option in the scanner. A date checked in with the scanner is counted by the tracker's presence counter as soon as the counted presence status equals the status set on check-in; the ticket settings warn when the two differ. The webservice mod_booking_verify_ticket gained the parameter optiondateid and returns the dates of the option, the selected date and the per-date presence.
* New feature: Full-screen scanner result. Every scan covers the page with a colour-coded result (animated check mark for a valid ticket), a big "Confirm entry" button and a "Reject" button; the check-in is only written on confirmation, a rejection writes no presence but is logged as the new event "Entry ticket rejected" (usable in booking rules) via the new webservice mod_booking_reject_ticket. The new site setting "Identity data shown on scan" selects the holder data shown for personalised tickets and options requiring an identity confirmation - profile picture, name, e-mail and any custom profile field such as birth date or gender.
* Bugfix: Unticking "Personalised ticket" in the option form is saved now; before, the flag fell back to its default (personalised) because the unticked value was dropped.
* New feature: Entry tickets for booking options: personalised PDF entry tickets with a QR code, created on booking, delivered by a booking rule and verified and checked in at the door. tool_certificate is used as a layout engine only — a ticket is a booking_tickets record with its own file area, so creating a ticket fires no certificate events, sends no tool_certificate notification and does not appear in the certificate report. The site administration only switches the feature on (plus the site-wide scanner defaults); the ticket design and behaviour are configured per booking option in the new "Ticketing" section of the option form (design, personalised, require identity confirmation, additional ticket information). Includes the new event ticket_created and the rule action "Send ticket", which mails the ticket PDF and resolves the ticket at run time (so it also works on other events, e.g. to send the ticket a few days before the start), the placeholders {ticketurl}, {ticketcode} and {ticketverifyurl}, "My tickets" (mytickets.php, a profile node and a column in My bookings), race-safe ticket creation and check-in, GDPR coverage and ticket cleanup on option/instance deletion, and agent skills for ticketing. Requires an upgrade run (new table booking_tickets).
* Improvement: Slot booking: the calendar marks the selected slots and lists the current selection with a summary, and the pre-booking modal can be closed. (Wunderbyte-GmbH/Wunderbyte-GmbH#2314)
* Improvement: Slot booking: the booked slots of a user are listed in the option description and in the options table, single slots can be released selectively, and the slot list view is easier to read. (Wunderbyte-GmbH/Wunderbyte-GmbH#2315)
* Improvement: Slot booking: releasing slots refunds the purchase through the shopping cart, and a booking answer remembers the purchase that paid for it (new column booking_answers.purchaseidentifier), so cancelling one purchase no longer deletes all bookings of the user on that option. (Wunderbyte-GmbH/Wunderbyte-GmbH#2316)
* Bugfix: Slot booking: examiner selection works for every slot, also after changing the option in the merged calendar view. (Wunderbyte-GmbH/Wunderbyte-GmbH#2320)
* Bugfix: Slot booking: moving and cancelling slots respects the cancel policy, the booking button state is correct after a slot purchase, the slot dates appear in receipts and in the success message after a slot update, and the merged calendar of several options renders correctly and no longer overflows. (Wunderbyte-GmbH/Wunderbyte-GmbH#2321)
* Improvement: Slot booking: the booked slots are rendered in confirmation mails and in the placeholders {slotsbooked} and {bookingdetails}. (Wunderbyte-GmbH/Wunderbyte-GmbH#2286)
* New feature: mod_booking feeds Moodle's global search. Three new search areas make booking instances, booking options and subbookings findable from the search box of the site; each of them can be switched on and off on the search areas page. The document of a booking option carries its title, description, location, institution, address, day of week and time and identifier, plus the display values of its custom fields, its teachers, entities, the name of the connected Moodle course, competencies and the name of the certificate template; attached files are indexed by engines which support file indexing. A new settings section "Global search" decides which of these sources are used, which custom fields are indexed and how invisible booking options are treated (indexed and restricted to users with mod/booking:canseeinvisibleoptions, or never indexed). Custom fields which are not visible to everybody, the internal annotation (opt in) and personal data (booking answers, issued certificates) are never indexed. Availability conditions do not hide search results: they gate booking, not seeing. Changes of related data reach the indexer - teacher changes and a renamed connected course bump the modification date of the affected options, a changed custom field definition requests a reindex of the areas. (Wunderbyte-GmbH/Wunderbyte-GmbH#2344, #2345, #2346, #2347, #2348, #2349)

## Version 9.7.10 (2026092105)
* Improvement: The courses in the agent's booking activity list are linked, in the preview and in the chat text. (Wunderbyte-GmbH/Wunderbyte-GmbH#2448)

## Version 9.7.10 (2026092104)
* Improvement: Asked without a booking activity in context, the agent previews the whole list of accessible booking activities, linked and with the cmid and the number of options behind each name. (Wunderbyte-GmbH/Wunderbyte-GmbH#2448)
* Improvement: Clicking the magic wand in the navbar puts the cursor straight into the agent input, also when the panel opens in the modal. (Wunderbyte-GmbH/Wunderbyte-GmbH#2449)

## Version 9.7.10 (2026092103)
* Bugfix: The option card in the agent preview ships the render-time JS of the booking templates, so its booking button works outside a booking page as well; without it the card arrived with a button no handler listened to. (Wunderbyte-GmbH/Wunderbyte-GmbH#2446)
* Improvement: Asked without a booking activity in context, the agent lists the accessible booking activities with the number of options each one holds, ordered by that number and with the totals, so empty activities are no longer proposed. (Wunderbyte-GmbH/Wunderbyte-GmbH#2447)

## Version 9.7.10 (2026092101)
* New feature: Three agent skills for the booking option fields (custom fields of the booking options): mod_booking.list_option_fields shows all fields or one of them with type, category, configuration and the number of options holding a value; mod_booking.create_option_field creates a field for every customfield type installed on the site; mod_booking.update_option_field changes name, shortname, category, default value, selectable values and the required/unique flags. All three run at the system context and are gated by the new capability mod/booking:managecustomfields (manager by default), because a booking option field affects every option on the site. A shortname that would shadow a booking option property or that another field already uses is refused before the write and ends as a question - the rule the custom field management page only warned about after the fact now lives once on booking_handler and is shared by the page and the skills. (Wunderbyte-GmbH/Wunderbyte-GmbH#2441)

## Version 9.7.10 (2026091500)
* New feature: When the setting "Dont add personal calendar events" is switched off again, an adhoc task creates the personal calendar events that are missing for all booked users and all future sessions, so bookings made while the setting was on show up in the users' calendars after all. The events are created by the very code path of a live booking (calendar::create_user_event_for_optiondate(), extracted from the calendar constructor), without any booking event, rule, mail or other side effect. The task is built for large sites: it visits the options in pages with a cursor, reads the missing (user, session) pairs of an option as a recordset, stops after a page, a time budget or an event budget and requeues itself, releases the per-option and per-user caches after every option, is idempotent, repairs tracking rows whose event was deleted, skips deleted users and waiting-list answers, and stops without writing when the setting is switched on again. The settings page queues the chain (one at a time); the new CLI script cli/backfill_user_calendar_events.php queues or runs it and reports the missing events with --dry-run, for sites that change the setting outside the admin UI. (Wunderbyte-GmbH/moodle-mod_booking#1613)
* New feature: Shortcode [mytaughtcourselist] lists the booking options in which the current user (or the user given by userid="…") is assigned as teacher. It takes the same table arguments as [mycourselist] (type, perpage, search, sort, filter, futureonly, cmid, custom field filters). With cmid the capability mod/booking:canseeinvisibleoptions of that activity is respected.
* New feature: Shortcode [userid] returns the id of the current user, e.g. for links like /mod/booking/teacher.php?teacherid=[userid].
* Bugfix: The adhoc task purge_campaign_caches no longer dies on an orphaned booking option (a row in booking_options whose bookingid has no course module left, e.g. after a deleted instance). get_coursemodule_from_instance() returned false there and singleton_service handed null to booking_settings::__construct(), which raised a TypeError - a \Error, so neither the catch in the singleton service nor the one in the task loop caught it. The whole campaign transition aborted at the first such option: every option after it got neither sync_waiting_list() nor the bookingoption_freetobookagain event, and the failed task was retried with a growing faildelay, purging the option, settings and price caches site-wide on every attempt. The singleton service returns null for a missing course module now, the task skips a broken option instead of aborting, and it reads the ids and maxanswers of the options with limited places in one query restricted to options that still have a course module (one query per option less). (Wunderbyte-GmbH/moodle-mod_booking#1588)

## Version 9.7.10 (2026090305)
* New feature: Waiting list progression refactoring - the legacy chains of confirm_bookinganswer / send_mail_interval rule actions and their adhoc tasks are replaced by a reconciler (progression) with a single source of truth: booking_waitlist_offers holds every offered / accepted / declined / expired / skipped / autobooked decision per round, booking_waitlist_declines is the round-independent lockout ledger (declined = permanent, expired = resettable). Offers expire via expire_waitlist_offer_adhoc, a waitlist_heartbeat_task (every 5 minutes, admin setting waitlistheartbeatinterval) self-heals lost triggers, the per-option field waitlistrecycling controls what happens after a full pass (stop / go through again / open up), the open mode (type 2) lets anyone book directly once the list was processed without the seat being claimed. Event observers (adapters) drive the reconciler from booked, unconfirmed, cancelled and late-joined answers; still-running legacy chains are migrated on upgrade (idempotent). The onwaitinglist condition reads the open mode state from the repository. Privacy metadata, unit and behat tests, and architecture blueprints included. (Wunderbyte-GmbH/moodle-mod_booking#1506)
* Bugfix: Booking rules normalize userid, objectid and relateduserid to int before embedding them into rulejson, so two triggers of the same event deduplicate into one adhoc task. Waiting list ordering tie-breaks on the answer id when timemodified is equal. (Wunderbyte-GmbH/moodle-mod_booking#1506)
* Note: The upgrade steps of this feature use the savepoints 2026090302 - 2026090305, all steps are guarded and idempotent. (Wunderbyte-GmbH/moodle-mod_booking#1506)

## Version 9.7.10 (2026090301)
* New feature: New site setting "Course login required to edit booking options" (editoptionsrequirecourselogin, enabled by default). When disabled, a site login is enough to open the booking option form (editoptions.php), e.g. for external trainers who are not enrolled in the course. The capability checks of the form still apply.
* New feature: Booking instance duplication copies the connected Moodle courses. With the setting "Duplicate Moodle course" active, duplicating a booking instance copies every connected course as well and points the duplicated options at the copies; options which shared one course keep sharing its single copy. The copy itself runs in the core adhoc course copy task, so a course shell is linked immediately and filled in on the next cron run. On a restore onto another site nothing is copied: an option connected to the course the backup came from is connected to the course being restored into, any other connection is dropped instead of silently pointing at whatever course carries that id there. (Wunderbyte-GmbH/Wunderbyte-GmbH#2193)
* New feature: Naming scheme for connected Moodle courses (PRO). Three new settings define templates for the full name, the short name and the ID number of a course that mod_booking creates or copies for a booking option, e.g. {titlewithoutprefix}_{optionid}. Short names and ID numbers are kept unique. The new placeholder {titlewithoutprefix} renders the option title without its prefix and, unlike {title}, does not need a logged in user, so it also works in background tasks. Courses the user picked from the list are never renamed. (Wunderbyte-GmbH/Wunderbyte-GmbH#2193)
* Bugfix: The naming scheme survives the asynchronous course copy. Core's copy task rewrote the full name, short name and ID number of the copy on the next cron run; a new adhoc task re-applies the naming once the copy has settled. Two options created from the same template with the same title both end up with a course named exactly after the option. (Wunderbyte-GmbH/Wunderbyte-GmbH#2193)
* Bugfix: Duplicating a booking instance or option no longer starts an endless chain of course copies. The connected course copy ran in every restore, including the restore performed by the course copy it had just queued, so a course containing a booking instance whose option enrolled into that very course - or two courses referencing each other - was copied again on every cron run. Connected courses are now only copied when a single booking instance is duplicated, never by a course copy, course restore or course import, and an option enrolling into the course its booking instance lives in keeps that connection. (Wunderbyte-GmbH/Wunderbyte-GmbH#2193)
* Improvement: The course copy no longer depends on the acting user - the backup and restore are attributed to the admin user, so it also works from adhoc tasks and restore steps; the capability check for duplicating a booking option is done at the call site. (Wunderbyte-GmbH/Wunderbyte-GmbH#2197)
* Bugfix: The privacy export no longer fails. (Wunderbyte-GmbH/moodle-mod_booking#1517)
* Bugfix: The privacy export exports only the options the user actually booked, one entry per answer with the user's own rating, and the complete booking history of the user in the instance. Before, every answer was combined with every option of the instance, the rating could belong to another user, and only the history of the first answer was exported. (Wunderbyte-GmbH/moodle-mod_booking#1583)
* Bugfix: Unloading a subbooking from the shopping cart or cancelling a subbooking that was never booked no longer inserts an artefact row (status "not booked" or "deleted") into booking_subbooking_answers. (Wunderbyte-GmbH/moodle-mod_booking#1584)
* Bugfix: The rule condition "responsible contact" mailed the responsible contacts of every booking option on MySQL/MariaDB instead of the contacts of the affected option only. (Wunderbyte-GmbH/moodle-mod_booking#1547)
* Bugfix: The first form save of an option created outside the option form (CSV import, web service, wizard) no longer records phantom changes and no longer notifies booked users about a change that never happened: dates are compared with minute precision, editor markup around plain text is not a change, and an empty text is not a change against a missing one. (Wunderbyte-GmbH/moodle-mod_booking#1556)
* Test: Behat suite sped up and stabilised - preconditions are seeded through generators instead of forms, hard waits, redundant logins and duplicate scenarios removed, cron and log round trips replaced by an adhoc run and an events log step. (Wunderbyte-GmbH/moodle-mod_booking#1551)
* Bugfix: With the setting "Use SQL filter for availability" (usesqlfilteravailability) enabled, trainers now see the booking options they teach on their teacher page, in the "Options I teach" tab and in the trainer course list shortcode, even if they do not fulfil the availability conditions of these options themselves. Visitors of a teacher page who are not that teacher still get the filtered list.

## Version 9.7.9 (2026090300)
* New feature: Hidden Moodle courses can be connected to a booking option. The course selector of the option form lists every course the user may enrol into manually, hidden ones included (they are marked as "Hidden course"), so an option can be prepared and booked before the course is released - the booked users are enrolled as usual. The links to the connected course ("Start" on the booked button, "Go to Moodle course", the buttons of the Moodle app, the redirect to the course after login, the link on the enrol link page and the iCal location) are only shown while the course is visible, or to users who may see hidden courses (moodle/course:viewhiddencourses).
* Bugfix: The course selector of the option form no longer throws a coding exception for users who may not enrol into any course; they get the "No course selected" entry only.

## Version 9.7.9 (2026090200)
* New feature: New site setting "Course login required for the booked users report" (reportrequirecourselogin, enabled by default). When disabled, a site login is enough to open report.php and the Bookings Tracker (report2.php), e.g. for external trainers who are not enrolled in the course. The capability checks of the reports still apply.
* New feature: Slot booking - several booking options can be merged into one calendar (multi-option calendar view with sidebar, shortcode support), user-defined and rolling slot types, an option defines how many slots one user can book at once (max_slots_per_user), a slot that overlaps a distinct existing booking is exclusive regardless of remaining capacity, the "available for you" counter respects the per-user slot cap, the slotbooking condition validates a selection itself with a clear notification instead of a silent no-op, a per-request cache of booked slot ranges is kept and cleared on every answer write. Behat coverage for the fixed, rolling, session and user-defined slot types. (Wunderbyte-GmbH/Wunderbyte-GmbH#2054)
* Documentation: Complete slot booking user guide. (Wunderbyte-GmbH/Wunderbyte-GmbH#2231)
* New feature: The elementid migration for customform elements of existing booking options is part of this branch now (savepoint 2026083106). The feature code was already here, but the migration that assigns the stable ids was missing, so installed sites never got their elements anchored. elementid := historical position, therefore every stored answer key customform_{formtype}_{position} stays valid and no answer data is rewritten. The step is idempotent and includes templates. (Wunderbyte-GmbH/Wunderbyte-GmbH#2195)
* Bugfix: The add-to-cart button is kept when bookit reports that nothing changed. (Wunderbyte-GmbH/Wunderbyte-GmbH#2277)
* Bugfix: The confirmation page reads the booking result from the user's actual booking state, not from the blocker cascade - for slot options the slotbooking condition stays blocking by design and masked the real state. (Wunderbyte-GmbH/Wunderbyte-GmbH#2281)
* Bugfix: An armed two-step confirmation (click again to book/cancel) is told apart from a no-op booking answer, so the button is re-rendered to "click again" instead of staying as it is. (Wunderbyte-GmbH/Wunderbyte-GmbH#2306)
* Improvement: Missing language strings added, hardcoded texts replaced by localized strings, comments translated to english. (Wunderbyte-GmbH/Wunderbyte-GmbH#2085, Wunderbyte-GmbH/Wunderbyte-GmbH#2117)
* Bugfix: Removed html build inside a string of the dynamic option date form. (Wunderbyte-GmbH/Wunderbyte-GmbH#2116)
* Bugfix: The option list cache (local_wunderbyte_table) is purged on every booking answer write, so a row's button state no longer stays stale across page reloads.
* Test: The credits test asserts the message users actually get, not the missing-string fallback. (Wunderbyte-GmbH/Wunderbyte-GmbH#2309)

## Version 9.7.9 (2026083100)
* Bugfix: With multiple bookings enabled, a re-booking that landed in the same second as the previous booking (slow servers, CI runners) was stored as PREVIOUSLYBOOKED itself while the old answer stayed BOOKED; the next booking then updated that historic row in place instead of inserting a new answer, so one booking was silently lost (behat scenario booking_multiple_bookings.feature:29 failed - and kept failing in the automatic reruns - on slow CI cells). A live booking is now always the newest one, a previously booked answer is never reused, and an active answer is never shadowed by a historic one in booking_answers::get_users(). (Wunderbyte-GmbH/moodle-mod_booking#1550)
* New feature: Custom form elements can be moved, inserted and deleted directly in the booking option form. Every element keeps a stable elementid, so the answer keys stored in booking_answers (customform_{formtype}_{position}) stay valid when elements are reordered - reordering no longer shifts the answers of one field onto another. Deleting a field removes the field, never the answers already given for it. On rows without a field, the row buttons are hidden. (Wunderbyte-GmbH/Wunderbyte-GmbH#2195)
* Improvement: Mandatory custom form fields are marked as required in the prepage modal (client side rule and error message), and the url and mail element types get their missing setType() call. (Wunderbyte-GmbH/Wunderbyte-GmbH#2232)
* Bugfix: Scroll position, focus and the open state of the date cards survive the no-submit reloads of the booking option form - editing a long option no longer jumps back to the top of the page on every internal form reload. (Wunderbyte-GmbH/Wunderbyte-GmbH#2215)
* Bugfix: Booking instances created outside the module form (webservices, wizard, generators) fall back to the default field lists for responsesfields, reportfields, signinsheetfields and showviews instead of being stored empty - report.php rendered no standard columns at all for such instances, and the custom form columns ended up leftmost. Existing instances with empty field lists are healed when their settings are read. (Wunderbyte-GmbH/Wunderbyte-GmbH#2310)
* Bugfix: get_all_options_of_teacher_sql() is passed the instance context, so canseeinvisibleoptions is evaluated in the context it belongs to and invisible options stay invisible for teachers without that capability. (Wunderbyte-GmbH/Wunderbyte-GmbH#2237)
* Bugfix: Direct option ids handed to the get_option_details AI skill are checked against the booking instance in scope, so an id from another instance is rejected instead of answered. (Wunderbyte-GmbH/Wunderbyte-GmbH#2230)
* Bugfix: The get_option_details AI skill reports the seats of an option correctly and distinguishes fields that were not requested from fields that are empty. (Wunderbyte-GmbH/Wunderbyte-GmbH#2233)
* Improvement: The deep link back to a booking option after login also works for options with a price. (Wunderbyte-GmbH/Wunderbyte-GmbH#1182)

* Bugfix: Saving a booking campaign resets the campaign list memoized in the singleton_service for the current request. Since the empty campaign list is memoized as well (9.7.8, #2307), a campaign created within a request that had already read the (empty) list stayed invisible for the rest of that request - the blockbooking and customfield limit campaign tests failed on all CI cells for that reason; delete_campaign() already did the reset. (Wunderbyte-GmbH/Wunderbyte-GmbH#2307)
* Improvement: The date placeholders {dates}, {datescompact}, {startdate}, {starttime}, {enddate}, {endtime} and {pollstartdate} render an empty value for self-learning courses (option type "self-learning course"): such options have no option dates and no official start or end, but dates left over from before a type change (or imported together with the type) were still rendered. Together with the section syntax {#dates}...{/dates} (the text between the markers is dropped when the placeholder is empty) this hides date related passages of rule mails and descriptions for self-learning courses. {datesandentities} keeps its dedicated self-learning course text (remaining duration).
* Improvement: The placeholders documentation explains the conditional text syntax {#name}...{/name} (the section is removed as a whole when the placeholder is empty) including its limitations: the placeholder has to occur in the text, unknown names and missing closing markers leave the section untouched, and a value of 0 counts as empty.
* Bugfix: Warnings of availability conditions (e.g. "maximum number of bookings reached" or "overlaps with the option(s) you booked") are always shown ABOVE the book button and above the price / add-to-cart button now, never next to them. Two causes: the wrapper of the price button (bookit_price) was a horizontal flex row, and the area of the plain book button (bookit_button) had no direction at all, so plugin css loaded in every theme (local_urise sets display:flex on .booking-button-area) laid the warning out left of the "Book now" button - in the list and cards views as well as on the option detail page. Both templates are explicit vertical flex columns now (warning, button / price, price label). theme_lexa ships its own copies of both templates and got the same fix (its price label / button row is nested below the warning), theme_musi uses the core templates.
* Bugfix: The placeholders {startdate}, {starttime}, {enddate}, {endtime} and {pollstartdate} are cached per user now, like {dates}: their values are rendered with userdate() in the language (and timezone) of the user, and rule mails force the language of each recipient - with the previous per-option cachekey, the second recipient of a multilingual cron run got the date format of the first one. {starttime} additionally never stored its value in the cache at all.
* Bugfix: When booking option singleton is destroyed, then also destroy placeholder singletons.
* Bugfix: Placeholders without a value (e.g. {institution} of an option without institution, which returns null) no longer trigger a PHP 8.1+ deprecation (str_replace() with null) while the text is rendered.

## Version 9.7.6 (2026082101)
* New feature: Form elements of the customform availability condition can be moved, inserted and deleted in the booking option form (buttons per row) without breaking existing booking answers. Every element now carries a stable elementid (migration assigns the historical position, so all stored answer keys stay valid - no answer data is rewritten); the runtime identifier customform_{formtype}_{elementid} and the report column formfield_{elementid} are built from that id, so reordering no longer shifts the mapping between answers and elements. New elements get their id from a monotonic nextelementid counter that never reuses freed ids. The prefill key hint of the option form shows the stable id now, and the subbooking additionalitem form link references elements by elementid. Also fixes the report lookup of the deleteinfoscheckboxuser answer, which was searched with a counter suffix although it is stored without one. (Wunderbyte-GmbH/Wunderbyte-GmbH#2195)
* Bugfix: The option form no longer jumps back to the top on no-submit reloads (adding a date, a customform element or any other no-submit button): scroll position, the focused element and the expanded date cards are preserved. (Wunderbyte-GmbH/Wunderbyte-GmbH#2215)
* Improvement: Mandatory elements of the custom booking form (customform availability condition) are marked as required in the prepage modal now: the label carries the core required marker (red exclamation mark) and the client-side check runs before submission, exactly like the modal to change form values in the Bookings Tracker. Static texts and the privacy consent checkbox stay unmarked, they have no input to fill in. The url and mail element types also got their missing setType(), which made every form build emit a Moodle debugging message. (Wunderbyte-GmbH/Wunderbyte-GmbH#2232)
* Bugfix: get_option_details reports the seats of an option correctly and never presents a field that was not requested as absent: the default set now covers availability, location and imageurl, availability is assembled from booking_answers (an option without a limit reports places_limited=false instead of a made-up zero), and the result carries omitted_fields next to per-option empty_fields. (Wunderbyte-GmbH/Wunderbyte-GmbH#2233)
* Bugfix: Teachers with mod/booking:canseeinvisibleoptions see invisible options in their taught courses again - get_all_options_of_teacher_sql evaluated the capability without the instance context. (Wunderbyte-GmbH/Wunderbyte-GmbH#2237)
* Bugfix: A booking option id supplied directly to get_option_details is bound to the booking instance of the cmid now. In module context it bypassed the instance scope entirely, so a chat running in one booking activity answered about - and rendered a bookable preview card for - an option in another activity. (Wunderbyte-GmbH/Wunderbyte-GmbH#2230)
* Improvement: Users who log in from the login button of an option that shows a price return to that option afterwards. The isloggedinprice condition linked to the login page without a return url, so those users ended up wherever they had started; the return url logic moved into bo_info::set_login_returnurl() and is used by both login conditions. (Wunderbyte-GmbH/Wunderbyte-GmbH#1182)

## Version 9.7.6 (2026082100)
* Bugfix: The plugin version was lower than the highest upgrade savepoint (2026082100) introduced with the waiting-list progression migration, so the upgrade step wrote a version into the database that version.php did not know about and the savepoints check of the CI failed. The version is raised to match the savepoint. (Wunderbyte-GmbH/moodle-mod_booking#1525)

## Version 9.7.6 (2026082001)
* Bugfix: The capability mod/booking:skill_mod_booking_diagnose_waitinglist was never defined in db/access.php, so the diagnose_waitinglist AI skill (added in 9.7.5) was denied everywhere with "Capability is NOT defined". The capability is now declared like its diagnose siblings (read, module context, teacher/editingteacher/manager) including en/de capability strings. (Wunderbyte-GmbH/Wunderbyte-GmbH#2168)

## Version 9.7.6 (2026081901)
* Improvement: The bookforuser session cache was removed entirely - the acting user is now resolved strictly request-bound (explicit userid, else the capability-gated shopping cart cashier param, else the logged-in user). The single-key MODE_SESSION cache was shared across all tabs of a login and let one request leak its acting user into unrelated requests of the same session. price::set_bookforuser() stays as a deprecated no-op so older local_shopping_cart/local_taskflow versions do not fatal. (Wunderbyte-GmbH/Wunderbyte-GmbH#2214)
* Improvement: The lazy responsible-contact tab of view.php no longer runs a full table render (including the filter build with per-column value counts over the whole instance) just to decide whether the tab should be shown - one cheap existence check on the already-built SQL replaces it. On a cold cache this contributed ~600ms DB time per view.php request. (Wunderbyte-GmbH/Wunderbyte-GmbH#2212)
* Improvement: The slotmove booking condition checks the cheap settings gate (slot config present and self-rebooking allowed, read from the cached option settings) BEFORE fetching the user's booked answer - previously every rendered booking options table row paid one booking_answers read per shown option per request, even on instances without any slot config. (Wunderbyte-GmbH/Wunderbyte-GmbH#2209)

* New feature: The sign-in sheet in HTML template mode (setting signinsheethtml) and the checklist (setting checklisthtml) can be generated as PDF/A-2b (archivable) - switched on with the setting "Create PDF/A-2b compliant PDFs" of the Wunderbyte Table plugin (local_wunderbyte_table/pdfaenabled, off by default): all fonts are embedded (Helvetica/Times/Courier in templates are mapped to FreeSans/FreeSerif/FreeMono), CMYK images are converted to RGB, images referenced by URL are downloaded by the server (Moodle's cURL security settings apply) and left out when they cannot be loaded. When the setting is off the PDFs are generated exactly as before. Requires local_wunderbyte_table 3.3.2 (2026081800).
* New feature: Booking option dates can now be added to the Moodle calendar as site events ("Add to Moodle calendar" > "Add as site event (visible to all users of the site)", addtocalendar = 2) in addition to the existing course events - site events are shown in the calendar of every user of the site, no enrolment in the course of the booking instance is needed (they are created without modulename/instance on purpose: Moodle's calendar filters module events by course module visibility and enrolment, which would hide them again for unenrolled users; an earlier attempt stored them with eventtype 'booking' and they ended up as "other events"). Setting the value requires the new capability mod/booking:createcalendarsiteevents (module context, RISK_SPAM; default: manager archetype, assigned to existing manager roles on upgrade - custom roles have to be granted manually; site administrators always have it). Without it the option form offers only "do not add" and "course event"; an option that already is a site event is shown read-only, so the decision of a privileged user is preserved when others edit the option. The check is enforced server-side for all save paths (option form, bulk editing, web service addbookingoption, CSV import) - a value of 2 submitted without the capability is rejected with a permission error and nothing is saved; the option form additionally shows a validation error. Switching between course and site events converts the existing calendar events in place (same event ids), switching to "do not add" deletes them; invisible options and hidden booking activities hide site events like course events. New settings: booking/addtocalendardefault preselects the dropdown for NEW booking options (do not add / course event / site event - site event falls back to course event for users without the capability), booking/addtocalendar_locked (until now read by the form but never defined) freezes the dropdown at that default - administrators then see a hint below the locked field linking directly to that setting, where it can be unlocked. Labels renamed for consistency: "Add to course calendar" > "Add to Moodle calendar", "Do not add to calendar of moodle course" > "Do not add to calendar". Capability violations thrown by option fields are no longer swallowed by fields_info::prepare_save_fields().
* New feature: New placeholder {datescompact} rendering the dates of a booking option like {dates}, but without bullet points: one line per day (separated by a &lt;br&gt; HTML tag), and several dates on the same day are combined into a single line - the date is shown once, the time slots follow separated by commas with a localized "and" before the last one (e.g. "20 August 2026, 10:00-12:00, 13:00-15:00 and 17:00-18:00"; German: "20. August 2026, 10:00-12:00, 13:00-15:00 und 17:00-18:00"). Dates spanning more than one day keep the full date string known from {dates}. Like {dates}, timezone abbreviations are appended to the times when the user's timezone differs from the site timezone (see the new setting below to turn them off).
* New feature: New setting "Hide timezones in dates" (booking/hidetimezonesindates, off by default): when active, the timezone abbreviation that is normally appended to rendered dates when a user's timezone differs from the site timezone (e.g. "(EDT)") is never rendered in the dates displayed by the plugin - most importantly the date-related placeholders ({dates}, {datesandentities}, {datescompact}, {startdate}, {starttime}, {enddate}, {endtime}), but everything going through the plugin's timezone-aware date formatting is covered, so booking opening/closing times in the tables and option descriptions lose the abbreviation as well. Note that only the label is hidden - the times themselves are still rendered in the timezone of the user.
* New feature: New global setting "Availability conditions when booking other users" (booking/bookotherusersavailability) decides how the "Book other users" page (subscribeusers.php) handles availability conditions of the booking option which the selected users do not meet. "Ignore availability conditions" (default) keeps the behavior known so far: conditions are not checked when booking for others. "Show a warning that needs to be confirmed" lists the affected users together with the conditions they do not meet, and the users are only booked after the booking agent confirms with "Book anyway" (cancelling books nobody); a confirmed warning also overrides the "Max current bookings per user" limit of the instance for exactly the users the warning listed with that blocker, so confirming really books them (new parameter $skipuserlimitcheck of user_submit_response - the capacity of the option is still respected). For users blocked by that limit, the warning and the block-mode error additionally name the booking options they are already booked in. "Block booking if availability conditions are not met" refuses to book exactly those users - they are listed with the blocking conditions in an error message, while selected users who do meet the conditions are still booked. Only real availability restrictions count as blockers (booking times, "booking option has started", profile field / enrolment / cohort / competency / selected-users restrictions, blocking campaigns, overlapping options, max number of bookings etc.); steps of the normal booking flow (bookit button, price, confirmation pages, booking policy, subbookings, custom form), capacity ("fully booked" - the existing waiting list logic stays in charge) and already-booked states are not. Cohort/group booking on the same page is not affected by the setting.
* Bugfix: Marking a booking option as completed (or undoing it) updates the activity completion of the booking instance again right away - the checkbox in the course view stayed unchecked until a completion recompute (e.g. a cache purge) happened, although the booking answer was set to completed and the completion event fired correctly. Root cause: since the separation of activity completion and option completion (v8.16.2), booking_option::toggle_user_completion() writes the new completion state to the DB before triggering the event which leads to booking_activitycompletion(), so the two branches of that function checked the state that was already toggled and were therefore inverted - in the common case (one option to complete, option just completed) COMPLETION_COMPLETE was never pushed at all. Phpunit pins both directions now: completing an option writes the completion of the activity immediately, undoing it revokes it (#1341, #1546).
* Bugfix: The iCal (.ics) of a booking rule mail for a booking option with several dates (e.g. two time slots on the same day) only added the first date to the calendar in Outlook (Windows and web), while Outlook for Mac or Apple Calendar added all of them. The file was sent as METHOD:REQUEST (meeting request) which, according to RFC 5546, may only carry one single event - Outlook strictly follows this and ignores the other VEVENTs. Options with more than one date are now sent as METHOD:PUBLISH (without ATTENDEE, as required for a PUBLISH), which every client imports completely - at the price of having no Accept/Decline buttons for those options. Options with one single date are still sent as METHOD:REQUEST, so the Accept/Decline buttons - including the inline invitation of the "Use a non-native mailer" setting - keep working there; cancellations stay METHOD:CANCEL.
* Bugfix: Two guards between an enrolment link (customform "Enrol multiple users" field) and the cancellation of the booking it belongs to. (1) As soon as somebody else is booked via the enrolment link, the booker cannot cancel that booking anymore: the cancel button on the booking option is replaced by the note "You cannot cancel anymore because your enrolment link has already been used.", the cancel flow of the bookit webservice refuses (no cancellation mark, no confirm step, stale confirm clicks are rejected) and the local_shopping_cart callback allowed_to_cancel() denies the cancellation for the booker ("Cancel purchase" in the purchase history is hidden with "No cancelation possible."); cashiers and users with booking management rights can still cancel the booker via the tracker/report. Link users who cancel again release the block; link users themselves are never blocked. (2) An enrolment link whose booking has been cancelled is dead: enrollink.php and enrollink::enrol_user() answer with the new status MOD_BOOKING_AUTOENROL_STATUS_BUNDLE_CANCELLED ("This enrolment link is no longer valid because the booking it belongs to has been cancelled.") before any place is consumed - until now the link kept working with its remaining places after the booker had cancelled (and was maybe refunded), and users booking via it even received the regular booking confirmation. Users already booked via the link before the cancellation stay booked. The bundle is verified through the stored booking answer id; legacy bundles without one (created before 2024-11-26) cannot be verified and keep working. The "diagnose cancellation issue" agent skill reports the new blocker explicitly instead of "cancel flow available".
* Bugfix: Availability conditions that count a user's existing bookings (max number of bookings per user, max options from category, overlapping options) returned wrong results when they were evaluated for ANOTHER user in a web session - eg. on the "book other users" page or by enrolment sync rules in "respect conditions" mode. The per-session MUC cache of a user's booking answers ('bookinganswers', key "myanswers&lt;bookingid&gt;") is keyed by the booking instance only, so such a check read the answers of the logged-in agent instead of the target user (typically: agent has no bookings > limit never reported as reached) - and afterwards even stored the target user's answers under that key, poisoning the agent's own subsequent checks in the same session. The cache is now bypassed in both directions whenever the answers of somebody else than the session user are requested; repeated lookups within one request stay cheap through the userid-keyed singleton in front of the cache.
* Test: Phpunit for both enrolment link guards (enrollink_cancellation_guard_test): booker blocked while a link user is booked and released again after that user is cancelled (condition result, rendered button, bookit flow incl. stale confirm, shopping cart callback), dead link after the booker's cancellation incl. hard-deleted answer and legacy bundle without answer id.

## Version 9.7.6 (2026081701)
* Bugfix: Booking option settings no longer re-query the slot booking config from the DB on every instantiation for options WITHOUT a slot config: the cached NULL was defeated by an isset() check, so every settings build (each table row, web service call and cron run) paid one extra query per option despite a warm cache - on large instances a single view.php request issued one query per option of the instance. The perf regression tests now rebuild the settings from the MUC cache between the two measured passes and assert exactly zero reads, so any field missing from the cached payload fails the suite. (Wunderbyte-GmbH/Wunderbyte-GmbH#2207)
* Improvement: The AI readiness panel no longer loads the full settings and answers of every single booking option of the instance just to display its two welcome-text counters (number of options / booked users): one aggregate query counts the booked users now, so view.php no longer scales linearly with the number of options when a wizard engine (agent) is installed. (Wunderbyte-GmbH/Wunderbyte-GmbH#2208)

## Version 9.7.6 (2026081700)
* New feature: The values a participant entered in the custom booking form (customform availability condition) can now be corrected afterwards in the Bookings Tracker (report2.php, option scope): the booked users and waiting list tables offer an "Edit form values" action for exactly one selected booking answer, loading the form fields of the option with the stored values and updating the answer json after validation (mandatory fields, mail/URL format, select values restricted to the configured options). PRO feature, gated by the new capability mod/booking:changecustomformofotherusers (module context, default: manager archetype only — existing sites have to assign it manually, as archetype defaults only apply on fresh installs); capability and PRO gate are enforced on the server side as well, and the answer id is validated against option and cmid. Element types with side effects stay read-only in the modal: "Enrol users action" (coupled to the booked places of the answer), the privacy consent checkbox of the user and static display texts. Saving is double-secured: a mandatory confirmation checkbox (red label "I am aware that saving will overwrite the form values entered by the user.", validation error otherwise) plus a save confirmation step — the first "Save" click only shows the question "Do you really want to overwrite the form values of this user?", and only confirming it with a second "Save" click actually writes the changes (cancelling aborts without saving). Every change is logged to the booking history of the answer with a per-field old/new diff (new history status "Form values edited"), and the timemodified of the answer stays untouched, so the waiting list order remains stable.
* New feature: New read-only agent skill "diagnose_waitinglist" for the booking wizard, answering "why did the waiting list not move?" for a single booking option - most importantly why reducing the number of places moved nobody. It resolves the option, asks the new waiting list sync explainer (see improvement below) and translates its deterministic gate codes into localized, actionable reasons naming the exact setting to change (e.g. option already started while "Allow updates" of the instance is off, waiting list turned off globally, keepusersbookedonreducingmaxanswers still on). Auto-discovered like the other diagnose skills, en/de strings and a skill test included.
* Improvement: While the global setting "Always book anyone" (booking/alwaysbookanyone) is active, the button "Do not allow booking of users who are not enrolled (recommended)" and the "Be careful: You can now book any users you want..." warning are not shown anymore on the page for booking other users — turning the toggle off had no effect anyway, as the setting forces it back on with every request. Site admins see an info alert instead, explaining that the plugin is configured to always allow booking any user of any course, with a direct link to the setting in the global plugin settings.
* Improvement: The "Availability conditions settings" section of the plugin settings (PRO; from the section heading down to "Enrol multiple users") moved from the main settings page to its own settings page in the booking folder of the site administration (section modbookingconditions). The setting names (booking/...) are unchanged, so all stored values stay as they are and nothing has to be migrated. All links into the section now point to the new page: the "Settings" column of the availability conditions dashboard and the help button of the booking time condition in the option form. Sites without a PRO license see the PRO teaser of the section on the new page.
* Improvement: The gate cascade of the waiting list synchronisation (sync_waiting_list: waiting list turned off globally, the "after start" switch, option already started while "Allow updates" of the instance is off, the paid-option skip and the capability gate on reduction) is now a single source of truth in the new class waitinglist_sync_status, whose explain() composes the pure predicates into a read-only report - so "I reduced the places but nobody moved" can be answered deterministically from the engine state. No behaviour change, the extraction is a 1:1 substitution at each call site. The waiting list documentation now names the two previously undocumented reasons a reduction moves nobody (the option-started/allowupdate gate and keepusersbookedonreducingmaxanswers being ON by default) plus a short troubleshooting checklist.
* Improvement: mod_booking no longer ships its own copy of the wizard engine alias layer (classes/local/wizard/engine/, 19 vendored files including engine_resolver). Like any third-party plugin it now relies on the active engine (local_wizard if installed, otherwise the bundled agent) registering the component-local aliases at runtime; the paths of mod_booking that instantiate skills directly (test seams, Behat diagnosis step) bootstrap them via engine_component::ensure_engine_aliases().
* Improvement: The "Type" select of the booking option form (option with dates, self-learning course, slot booking) only offers the non-default types when they are actually available on the site: self-learning courses now require the PRO license AND the global toggle booking/selflearningcourseactive (before, the type was always selectable, even without PRO), slot booking requires PRO and its toggle as before. If neither is available, the select is not rendered at all and the default type is stored via a hidden field. An option that already is a self-learning course or a slot option keeps its type in the list and is no longer silently reset to an option with dates when the license expired or the toggle was switched off afterwards - before, editing such a slot option turned it into an option with dates behind the scenes. Both checks are single sources of truth (selflearning_feature::is_enabled() mirroring slot_feature::is_enabled()).
* Improvement: The hidden no-submit buttons of the option form (option type, slot type, change template) carry proper localized labels instead of the placeholder "xxx".
* Improvement: The CSV import documentation now describes how booking custom fields are imported: the field shortname is accepted as CSV column name (mapped internally to customfield_<shortname>; a column already named customfield_<shortname> does NOT work), present-but-empty cells clear the stored value, omitted columns keep it.
* Improvement: The "Hide booking option when condition not met" checkboxes of the availability conditions booking time, enrolled in course, enrolled in cohorts and custom user profile field are disabled (soft-frozen: rendered disabled, the stored value is still exported and posted, so nothing is wiped) with an explanatory note as long as the global setting booking/usesqlfilteravailability is off - before, they were offered but silently did nothing, because the whole SQL filter machinery is skipped with the setting off. Users with moodle/site:config additionally get a direct link to the setting on the booking admin page (#1516).
* Bugfix: Security hardening of the slot picker webservices (loading the picker state, validating/caching a selection): acting on another user now requires the book for others (or cashier) rights, like in the other user-facing booking webservices — before, any logged-in user could read another user's picker state or write their cached slot selection by passing a foreign userid. Acting on yourself (and the existing trainer/cashier flows) is unchanged; phpunit covers both the rejection without and the acceptance with the book for others capability.
* Bugfix: Rating a booking option through the webservice (the stars of the lists) now uses the same context validation as the booking chain: booked users are not necessarily enrolled in the course of the booking instance (e.g. booked via shortcode lists, option without connected course), so users holding mod/booking:choose there may rate without course access. The context is now resolved from the option itself instead of trusting the submitted course module id, can_rate() keeps gating who may rate, and users without the capability and without course access keep being rejected — both directions covered by phpunit.
* Bugfix: The mobile customform submission webservice (get_submission_mobile, used by the Moodle app) now uses the same context validation as the booking chain: users holding mod/booking:choose on the booking instance may submit or reset the custom form data without access to the course of the booking instance (like on the website, where the same fix already covered load_pre_booking_page); the book for others gate for foreign users stays untouched. Phpunit coverage for both directions: the unenrolled user with the capability submits, without the capability the submission keeps being rejected.
* Bugfix: The price of a booking option is not rendered twice anymore for users on the notification list while the option is bookable again (price above the notify-me bell AND above the add-to-cart button, cards, list and detail views alike). Root cause: the standalone bell template (wrapper plus price plus bell) was embedded as a mustache partial into the bookit button templates, and partials inherit the full parent context — so the bell rendered the price of the surrounding template a second time, including a nested duplicate of the button wrapper. The bell markup is now split into a bare bell partial (button_notifyme_bell) that the bookit templates embed, while the standalone template keeps composing wrapper, price and bell for the fully booked state (unchanged there). The bell also moved INSIDE the button wrapper that the JS replaces on booking actions, so re-renders cannot leave a stale bell behind anymore. The bell keeps following the booking answer state only: filled bell next to the add-to-cart button while the user is on the notification list, filled or empty standalone bell when fully booked, no bell for booked users or users in the shopping cart (their notification list entry is consumed by the transition). Phpunit pins the rendered button HTML for every one of these states.
* Bugfix: The date columns of the Bookings Tracker (report2.php) now match report.php exactly: the creation date column (timecreated) shows date AND time in the localized full format of report.php (e.g. "Thursday, 13 August 2026, 10:29") instead of a bare "13.08.2026", the timebooked column shows the same localized full format and is labelled "Booking date" like on report.php (before: "Booking time" — the header of the sort dropdowns follows suit). In the tracker table downloads, all time columns now use the fixed sortable format "2026-08-13 10:29" (creation date, booking date, time modified, course start/end time, completed date, and slot start/end time of slotbooking options).
* Bugfix: A CSV or webservice import row carrying the indexed date columns coursestarttime_<n>/courseendtime_<n> without the matching optiondateid_<n> silently lost the date twice over: the optiondates field class was skipped for the row (the indexed coursestarttime columns were not among its import identifiers) and the date parser only accepted indexed rows keyed by optiondateid_. The option was imported without any date and without an error - and as coursestarttime 0 reads as "not started" everywhere, the loss stayed invisible. Now the alternative import identifiers ending in "_" match any index and the parser injects the missing optiondateid_<n>=0 marker for import inputs (the interactive option form is untouched, as injecting there could resurrect a deleted date). The CSV import guide documents optiondateid_<n> as optional on import (0 assumed) and corrects the misleading "for updating" column description.
* Bugfix: The expiry check of the "book for user" override (price::return_user_to_buy_for(), the 10 second window relied on by the bookit webservice and local_taskflow) was inverted: a still-valid override was discarded while an expired entry kept being applied for the rest of the session, so the session-global cache leaked the booking target across browser tabs (supervisors booked employees instead of themselves). A valid override now applies within its window; an expired entry is discarded AND deleted, so it can never poison later requests of the same session.
* Bugfix: The booking option detail page (optionview.php) opened with a userid parameter (e.g. the assignment link for booking a foreign user) discarded the resolved user and re-read the session-global "book for user" cache - together with the inverted expiry check (see above) an unrelated browser tab booked whoever's assignment link was opened last. The buy-for target of a tab is now bound to the link it was opened with (an explicitly passed foreign user wins over the session-based resolution; the session override only applies where no explicit target exists), the userid parameter gate additionally accepts mod/booking:bookforothers (matching the enforcement of the booking chain), and the customform prefill follows the buy-for target.
* Bugfix: The SQL filter relevance helper and the cache report service require mod_booking's lib.php explicitly, so the MOD_BOOKING_* constants are defined when they run inside a task where the plugin lib is not loaded yet.
* Test: Characterization tests for the waiting list synchronisation gates that were still uncovered (global turnoffwaitinglist early exit, option started with instance "Allow updates" off, waitforconfirmation on the reduction path, unlimited places promoting all waiting users) plus unit tests for the new explainer and the diagnose skill; the perf guard of the waiting list promotion was recalibrated for the CI execution context (bound 22 instead of 16 reads per promoted user, still catching a full-magnitude relapse).
* Test: Phpunit coverage for the visibility of the option types in the option form (PRO/toggle combinations for self-learning courses and slot booking, stored type kept for existing options).
* Test: Importer regression test for indexed date columns without optiondateid_<n> (the test generator injects the marker for seeds the same way, so 17 test files whose seeds silently lost their dates now run against real dates), and unit tests for the SQL filter form support helper.
* Test: Characterization tests for the "book for user" session cache (bookforuser_cache_test, bookforuser_optionview_test, bookforuser_listing_guard_test) pinning the fixed expiry contract, the link-bound target on optionview.php and the unchanged stateless "act for user" listing path used by cashier/USI.

## Version 9.7.5 (2026081101)
* Bugfix: Confirming the cancellation of a booking on the booking option detail page (optionview.php) gave no visual feedback at all for options with pre booking pages - the "Book now" button only came back after a manual page reload. While the option is booked, its button area is a plain bookit button without the wrapper which opens the pre booking pages (the prepage modal is suppressed for the booked state). Cancelling makes the option bookable again, so the webservice answers with the prepage modal (or inline) template - and the JS replaced the element carrying exactly that missing wrapper, found nothing and silently skipped the DOM update. It now falls back to the button area itself, so the new state is rendered right away. The same replacement was skipped in the list views as well, but went unnoticed there, as the table reload following a cancellation re-renders the row anyway; the detail page has no table to reload.
* Improvement: Confirming a cancellation on the booking option detail page (optionview.php) reloads the page now. Replacing the booking button alone leaves the rest of the page showing the state of the booked user - above all the status text of the option or instance (beforebookedtext while the option is not booked, beforecompletedtext/aftercompletedtext while it is) and the remaining places, none of which the bookit webservice returns. A booking already reloads the detail page when the pre booking pages are closed, so cancelling now gets the same treatment; all other views keep updating just the button area plus the table.
* Test: Behat coverage for the bugfix and the reload (see above): a student cancels a booking on the detail page and has to see both the "Book now" button and the status text of the unbooked state without reloading manually - once for an option without pre booking pages and once for an option with a booking policy, where booking has to open the policy in the prepage modal again afterwards.

## Version 9.7.4 (2026081100)
* Bugfix: Follow-up to the 9.7.3 context validation fix: further user-facing webservices still rejected users without access to the course of the booking instance (requireloginerror since the 9.7.0 hardening) even when they hold mod/booking:choose there — the "notify me when a place is free" toggle of the booking button, the option description modal of the lists, and the slot picker services of the slot booking chain (loading the slots, validating/caching a selection, releasing booked slots). They now use the same context validation as the booking chain: users holding mod/booking:choose on the booking instance are accepted via the system context (an active login and session is still enforced), all other users keep being rejected, and all further capability and ownership checks of the services stay untouched.
* Test: Phpunit coverage for the follow-up (see bugfix): the unenrolled user holding mod/booking:choose via a system level role opens the option description modal and toggles the notification list through the webservices, and loads the slots and validates/caches a slot selection through the slot picker webservices; without the capability, the unenrolled user keeps being rejected by the slot picker (and, per existing coverage, by the notification toggle).

## Version 9.7.3 (2026081000)
* New feature: The group(s) of the connected course a user is enrolled in when booking an option can now be selected manually in the booking option (section "Moodle course", stored in the option json as addtogroupsofconnectedcourse). The selection is only offered while a course is connected (anything but "No connection to Moodle course") and while "Automatically enrol users in group of connected course" is NOT active in the booking instance - with the automatic mode active, the option form shows a notice (alert-light) that the group is generated automatically and cannot be selected manually. Only groups of the currently saved connected course are offered (after a course change, save first; groups not belonging to the final course are discarded on save). Booked users are added to newly selected groups on saving the option, and on cancellation users are removed from the selected groups, keeping the course enrolment while other group memberships exist - both like in the automatic mode.
* New feature: New global setting "Sender of messages from the bookings tracker" (booking/bookingstrackermessagesender): messages sent from the bookings tracker (report2.php) — "Send message", "Send message to teacher(s)", "Send message to responsible contact(s)" — are sent either as the booking manager of the booking instance (default, behaviour as before; falls back to the logged-in user if no valid booking manager is set) or as the logged-in user actually sending the message, so recipients can reply directly to the right person. The resolved sender is shown (read-only) in the three message modals.
* New feature: The markdown documentation shipped in the docs/ folder of the plugin can now be read directly in Moodle: the new page documentation.php renders the pages (index, user documentation, developer guides) and rewrites their links, so the existing cross-links and index tables of the docs work as click-through navigation; images and the CSV examples referenced by the pages are served as well. Access requires the new capability mod/booking:viewdocumentation (default: manager archetype only), and users with the capability get a "Booking documentation" entry in the settings navigation of every booking instance as well as a "Booking: Documentation" entry in the site administration next to the other booking pages (Booking: Semesters, Booking: Cache report etc.).
* New feature: New read-only admin page "Booking: Cache report" (site administration) measuring the behaviour of the booking table caches, so production sites can answer the cache questions themselves: configuration and relevance state of the SQL availability filter, cache key sharing across a sample of recently active users (the distinct-stems metric of the cache fixes below), timing of the options query with and without the availability filter WHERE, store usage of the booking relevant cache definitions (core cache usage API) and a daily snapshot trend collected by a new scheduled task (new table booking_cachereport_snapshots — retention bound, aggregates only, no user data). The report never populates or purges any cache; an anchor test pins that the measured stem equals the WHERE plus params of the real general view. Requires an upgrade run (table, scheduled task, admin page). (#1508)
* Improvement: The two instance settings for the enrolment into the connected course ("Automatically enrol users in connected course" and "Automatically enrol users in group of connected course") moved from "Advanced options" into a new dedicated section "Connected Moodle course" of the instance settings; the two settings concerning the course of the booking instance (the group multiselect and the unenrol checkbox) stay in "Advanced options". "Automatically enrol users in group of linked course" was renamed to "... of connected course" and is indented via styles.css, as it is only shown while the connected-course enrolment is active; the "current course" wordings now say "the course in which this booking instance is located" to make clear which Moodle course is meant.
* Improvement: The favorites star toggle (PRO setting enablefavoritestoggle) is now shown on all tabs of view.php — e.g. "Active booking options", "My bookings", "What's new?", visible/invisible options, the single-option view and the "Field of study" tab (which receives the star via the favorites=1 argument of the [fieldofstudyoptions] shortcode) — and no longer only on "All booking options". The bulk operations tab intentionally stays without the star, as it is an administrative table. Technically the flag moved into the central table layout initialization, so every table rendered for view.php gets it under the same PRO/setting gate as before.
* Improvement: The [recommendedin] shortcode supports the favorites=1 argument to show the favorites star toggle on every listed booking option (handled by the argument processing shared by the table shortcodes). The argument is now documented in the shortcode docs, including the shared parameter list of the shortcodes README.
* Improvement: Saving the booking option with a manually selected group that does not (or no longer) exist in the connected course now shows a validation error at the group selection, naming the missing group(s), instead of silently discarding them - e.g. after the connected course was changed without adjusting the selected groups, or after a selected group was deleted in the course. While no course is connected, the hidden selection is still discarded without an error, as before.
* Improvement: The "-related" suffix for customfield placeholders is now documented: {shortname-related} inserts the custom user profile field of the related user of the event triggering a booking rule (e.g. the user a booking was made for) instead of the recipient. The placeholder list in the booking rules editor ("Show placeholders") mentions the suffix now, and the placeholder documentation got a reworked customfields section ({shortname} for booking option custom fields and user profile fields incl. lookup order, {shortname-related} for the related user). Two errors in the docs were fixed along the way: custom fields are referenced by their bare shortname (not with a profile_field_ prefix), and the {firstnamerelated}/{lastnamerelated}/{emailrelated} placeholders resolve the related user of the triggering event, not the responsible contact.
* Improvement: A booking instance referencing booking customfields that do not exist on this Moodle platform — e.g. after restoring a course backup from another site, where the instance settings "Customfields for filter" and "Customfields shown for each option in the overview" keep the shortnames of the source platform — now shows a clear message on view.php instead of just silently dropping the affected filters and columns. The message lists the missing fields by name and shortname (as stored on the source platform); users who can create the fields (site administration) additionally get a direct link to "Booking: Custom booking option fields", users who can manage the booking instance (mod/booking:updatebooking) see the message without the administration link, and all other users are not bothered with it. The message disappears as soon as all missing fields have been created.
* Improvement: Availability conditions that no booking option on the site uses are now skipped entirely when the SQL of the availability filter (usesqlfilteravailability) is built. In particular, on sites not using the "booking time" filter its day-bucketed time params stay out of the SQL — they would otherwise rotate every table cache key at midnight. On sites that DO use the booking time filter the keys legitimately rotate at midnight, turning the previous day's table cache entries into an unreachable dead generation: the day rollover is now detected exactly once and an adhoc task (deduplicated for parallel requests) purges the affected caches.
* Improvement: Fixed the customform layout, and checkbox labels as well as static text elements of the customform now support links.
* Improvement: The names and links of booking items resolved for shopping cart coupons now come from the booking option settings API instead of raw SQL, so the displayed name respects the title prefix. (GH-176)
* Improvement: The action columns of the reduced bookings tracker scopes (options to confirm, supervisor team) are not offered as sortable anymore, and the duplicated scope code moved into a commonly used function in scope_base.
* Bugfix: "Unenrol from group when user is unenrolled from corresponding booking option?" now also removes the user from the fixed group(s) selected in the instance settings - not only from the group created for the booked option. As the fixed groups are shared between all options of an instance, the user is only removed once no active booking (booked, waiting list, reserved) within the instance is left.
* Bugfix: Creating a booking instance stored the "unenrol from group" setting as active even when the checkbox was unchecked (isset check on an advcheckbox that always submits 0 or 1). Updating an instance was not affected.
* Bugfix: The group of a booking option in the current course ("Enrol in specific group for each booked option" of the addtogroupofcurrentcourse instance setting) was silently never created when a group with the identical generated name "&lt;instance&gt; - &lt;option&gt; (&lt;optionid&gt;)" already existed in the course of the booking instance - in particular the automatically created group of the connected course, whenever the connected course is the very course the booking instance lives in: create_group deduplicated by group name before the idnumber lookup which actually identifies the option groups of the current course, so the booked users silently landed in the connected-course group instead. The option group of the current course is now identified by its idnumber only; in the other direction, the lookup of the connected-course group (including the repair lookup of the "wrong group?" reset checkbox) now ignores the option groups of the current course, so a same-named option group is never linked as the group of the connected course.
* Bugfix: Downloading the sign-in sheet in HTML mode could fail with a TCPDF error "Unable to create output file: /tmp/...". Before streaming the download, the PDF was needlessly written to a file in the system temp directory named after the raw booking option title — a title containing e.g. a slash made that write fail, and since the file was never deleted, a leftover file owned by another system user blocked all further downloads of the same option. The useless temp file write is removed; the PDF is streamed directly (like in the classic mode, which was never affected). The Word export wrote its .docx to the system temp directory the same way (raw title, no cleanup, participant lists lingering in the world-readable /tmp): it now writes to a per-request directory of the Moodle File API and is sent via send_temp_file(), which deletes the file right after streaming. The download filename of both formats and of the classic PDF mode is now sanitized by one shared helper, which falls back to "signinsheet" for titles without any ASCII letters or digits.
* Bugfix: Recipients of messages sent from the bookings tracker modals could not reply to the sender shown in the modal: Moodle core replaces the visible from address of outgoing mails with the noreply address (unless the sender's domain is listed in $CFG->allowedemaildomains), and as no explicit reply-to was set, replies went to the noreply address as well. The mails now carry a reply-to header pointing to the resolved sender (booking manager or, with booking/bookingstrackermessagesender set to "logged-in user", the user actually sending the message), so answering reaches the right person even while the visible from address stays the noreply address.
* Bugfix: Creating, updating or deleting a booking customfield did not purge the cached customfield list (customfields cache): the observer fired the cache invalidation event with an empty key list, which is a no-op in the Moodle cache API. Until some other purge happened, the stale cache could keep offering deleted fields or ignore freshly created ones everywhere the list is used (instance form selects, overview columns, and the new missing-customfield message). The whole cache is now purged via the invalidation event.
* Bugfix: Since the security hardening of the webservices in 9.7.0, clicking "Book now" did nothing or opened an empty modal for users without access to the course of the booking instance ("Course or activity not accessible" / requireloginerror in the AJAX response): the webservices of the booking chain (the pre booking check of the booking button, the loading of the prepage modal and the booking itself) validated the module context of the booking instance, which requires access to its course and activity (enrolment, visibility). Booking options are regularly presented outside of their course, e.g. via shortcode lists, where the booking users are not (or not yet) enrolled in that course. As before the hardening, users holding mod/booking:choose on the booking instance — the same capability the "Has the capability to book in this instance" condition checks — can now book without course access: for them, the system context is validated instead, which still enforces an active login and session; all other users keep being rejected.
* Bugfix: The SQL availability filter (usesqlfilteravailability) no longer floods the table caches with per-user entries. The availability conditions embedded user specific data into the options WHERE clause through two channels: enrolledincourse/-cohorts inlined ALL course/cohort ids of the user as literals, and the profile field condition added ALL custom profile field values as params — including memberships and fields no filter condition references anywhere on the site. The table cache key is a hash over exactly this SQL, so every user produced their own application cache entries (mod_booking/bookingoptionstable) even when the visible result was identical, filling the cache until the site went down. The conditions now trim the embedded user data to the values actually referenced by sqlfilter conditions site-wide (tracked by a new, globally cached relevance service), and when no option uses the SQL filter at all, the user specific WHERE is skipped entirely. In a measured 102-user scenario the number of distinct cache keys drops from 102 to 10 (one per visibility class) with unchanged visibility results.
* Bugfix: The booking option detail page (optionview.php) was always visible for logged-out users: the access check block was wrapped in isloggedin(), so for logged-out users and guests no check ran at all and the page rendered regardless of the "Show booking details to all" setting. The access rule is now centralized in booking_option::can_view_option_details() — details are visible to everyone with showbookingdetailstoall, otherwise only to logged-in users who are booked/on the waiting list/reserved, when bookonlyondetailspage is active, or with the mod/booking:view capability. optionview.php enforces the rule (login redirect for logged-out users, capability exception otherwise), and the booking options table renders the option title without a link for users who may not see the page.* Bugfix: view.php no longer trips over customfields referenced in the filter config of the instance that do not exist on this site (e.g. after restoring a course backup from another platform) — missing fields are skipped when the filters are built (see also the missing-customfield message improvement above).* Bugfix: Reducing the limit of a priced option no longer deletes paid users' bookings through the waiting list trim: the waiting list sync deliberately skips paid users when demoting booked answers (they keep their seat), but their answer still landed in the local waiting list array the trim loop pops from, so reducing maxanswers DELETED the newest paid user's booking through the back door while a real waiting user was spared. The answer is only added after the price gate now, so paid users keep their booking entirely.* Bugfix: Saving a booking option now fails loudly instead of corrupting data when the acting user has no option form profile at all (none of expertoptionform / reducedoptionform1-5, but e.g. mod/booking:updatebooking) or when the pipeline loses the id of an existing option (e.g. a misconfigured form profile without the id field): before, the empty field set made update() fall into the insert branch and create a junk booking_options row (or blow up with a confusing dml_write_exception on strict SQL modes) instead of updating the addressed option. Editing teachers and managers hold expertoptionform via archetype and are unaffected; deliberate copy flows (copy to template, duplication) clear the id on purpose and keep working.* Bugfix: The reduced bookings tracker scopes (options to confirm, supervisor team) now show the correct filter names.
* Bugfix: Fixed the accordion of the booked users overview for Moodle 4.5.
* Test: Behat feature for the reworked instance settings (new section, visibility dependency, saving/reloading the group multiselect); phpunit coverage for the instance settings storage and the removal from shared groups only after the last active booking. Fixed a latent bug in the group enrolment test which compared group names against group ids, so the membership assertions never ran.
* Test: Behat scenario for the manual group selection in the booking option (selecting and saving a group, hidden without course connection, notice instead of selection while the automatic group mode is active) and phpunit coverage for the manual connected-course groups (enrolment into the selected groups, removal on cancellation incl. keeping the course enrolment while other memberships exist, selection ignored while addtogroup is active).
* Test: Phpunit coverage for the favorites star on the view.php tables (star on all rendered tables with the setting on, on none with the setting off) and for the favorites=1 argument of [recommendedin] (star present with the argument, absent without it).
* Test: Phpunit coverage for the validation of the manually selected connected-course groups: error naming the missing group(s) for a group of another course or a deleted group, no error for a valid selection, while the automatic group mode is active, without course connection or without selection.
* Test: Phpunit coverage for the enrolment into group(s) of the current course (addtogroupofcurrentcourse) when OTHER users are booked ("Book other users", subscribeusers flow): the very first bookings of a fresh option create the option group in the current course and add the users to it and to the fixed group; with "enrol users only at coursestart" the whole group logic is deferred to the enrol_bookedusers_tocourse task, which processes the option only once its coursestarttime has passed. Both directions of the group name collision (see bugfix) are covered: the option group of the current course is created and filled although the same-named connected-course group exists in the course, and activating the automatic connected-course group only after the option group already exists creates a separate connected-course group instead of linking the same-named option group. Self-booking ("Book now", booking_bookit) with a separately connected course is covered as well: both same-named groups are created and filled for an enrolled participant, while a site admin who is not enrolled in the current course only fills the connected-course group - core groups_add_member silently skips users without an enrolment in the course of the group, and booking only enrols into the connected course, never into the current one.
* Test: Phpunit coverage for the reply-to header of the mails sent from the bookings tracker modals: replies go to the booking manager by default and to the logged-in sender with the bookingstrackermessagesender setting active, while the visible from address stays the noreply address. A guard test pins down that the default send path without set_sender() — used by all other booking mails, in particular the booking rules — keeps the core noreply defaults for from and reply-to untouched.
* Test: Phpunit coverage for the missing-customfield message after a restore on another platform: a course with a booking instance referencing customfields is backed up, the fields are deleted (simulating the target platform) and the backup is restored — the restore completes, view.php renders without a technical error, the detection lists the missing fields with the names of the source platform, site admins get the message with the link to the configuration page, instance managers without the link, students nothing, an instance without references stays without message, and the message disappears once the fields have been created again.
* Test: Phpunit coverage for booking without access to the course of the booking instance (see bugfix): an authenticated user who is not enrolled but holds mod/booking:choose via a system level role passes the pre booking check and books through the bookit webservice; for an option with a customform condition, the customform prepage is offered to the unenrolled user and loads through the webservice, the submitted form data is stored, and loading the confirmation page books the user with the customform data carried in the booking answer. An unenrolled user without the capability keeps being rejected (existing coverage).

## Version 9.7.2 (2026080400)
* New feature: New setting "Location filter: only filter by top level" (booking/entitytreefiltertoplevelonly): the multilevel location filter then offers only the first (top) level of the entity tree — selecting an entry filters all booking options of the entire branch; sub-levels (e.g. single rooms) are no longer offered as separate filter options. (Wunderbyte-GmbH/Wunderbyte-GmbH#2011)
* New feature: New setting "Show hover card for deep location hierarchies" (booking/entitytreefiltershowlocationhovercard, default on): when disabled, locations in hierarchies of three or more levels are shown as a plain "direct parent (entity)" link without the hover card with the superordinate levels. (Wunderbyte-GmbH/Wunderbyte-GmbH#2011)
* Improvement: The three settings belonging to the multilevel location filter (top level only, hover card, hover card images) are now visually grouped under the entitytreefilter setting — indented with a "⤷ " label prefix — and are only shown while the multilevel location filter is enabled. The hover card image setting booking/showlocationimages was renamed to booking/entitytreefiltershowlocationimages accordingly (a stored value is migrated on upgrade). The whole settings block is only offered when the local_entities plugin is installed, as the filter has no effect without it. Changing any of the four settings automatically purges the cached booking options tables and filters, so the change takes effect immediately without a manual cache purge. (Wunderbyte-GmbH/Wunderbyte-GmbH#2011)
* Improvement: Locations in a hierarchy of three or more levels are now displayed as "direct parent (entity)" — e.g. "level 2 (level 3)" for three levels, "level 3 (level 4)" for four — matching the familiar two-level format; the hover card and the screenreader text keep showing all superordinate levels (incl. the direct parent). Table exports keep the full path. (Wunderbyte-GmbH/Wunderbyte-GmbH#2011)
* Improvement: The booking activity now declares the "Administration" purpose (FEATURE_MOD_PURPOSE), so the activity chooser lists it under the "Administration" tab (Moodle 4.4+) instead of only under "All".
* Improvement: When an option that requires confirmation is full and a user books onto the real waiting list, the "waiting for confirmation" event now fires as well — such a user is waiting for confirmation just like a parked user, as the waiting list sync never promotes unconfirmed users. It only fires for new answers: confirming/unconfirming an existing answer does not retrigger it, and autoenrol keeps its own confirmation flow.
* Improvement: New answers restriction interface for booking extensions: an extension can limit which users' booking answers the current user may see (e.g. a supervisor who may only see their own team); if several extensions restrict, every restriction narrows the result further. The restriction is applied directly in the SQL of the bookings tracker scopes (system, course, instance and options).
* Improvement: The answers restriction of booking extensions (e.g. supervisors seeing only their subordinates) also applies to report.php, subscribeusers.php and to the booking history and sent messages of the booked users overview.
* Bugfix: An over-full waiting list no longer causes overbooking of the option. When the waiting list limit was reduced (e.g. from unlimited "-1" to a fixed number) while more users were already waiting than the new limit allows — and the excess entries were kept, e.g. because of the site setting "keepusersbookedonreducingmaxanswers" — the number of free waiting list places became negative. The fullybooked availability condition misread that value as "places left" (empty() check), so check_if_limit fell through to its overbooking branch and booked every further user directly, although maxanswers was already reached; a computed value of exactly -1 (one user over the limit) was even mistaken for the "unlimited waiting list" sentinel. The free waiting list places are now clamped to 0, the fullybooked condition checks the value explicitly instead of via empty(), and -1 only counts as unlimited if the maxoverbooking setting itself is -1.
* Bugfix: Fix HTML and links in ical event descriptions (also for Outlook). Fix placeholders and enable {mlang} (multi-language filters) for ical descriptions.
* Bugfix: Trimming the waiting list no longer fires the cancellation event twice. When the waiting list sync removed excess waiting list entries after a limit reduction (with "keepusersbookedonreducingmaxanswers" off), the removed user got the bookinganswer_cancelled event twice with differing payloads, so the mail task dedup could not merge them and every rule listening to the event (e.g. cancellation notices) sent its mail twice.
* Bugfix: The trigger button of the pre booking modal showed "No price set" instead of the price for already booked users. When a cancel button condition (e.g. "cancel myself" for users who already booked, with "book again" enabled) becomes the extra button condition on the details page, the merge preserving the price data only triggered on button-style data, so the price of price conditions (like priceisset) was discarded for users without the book-for-others capability. The merge now also triggers on a set price and carries the currency along.
* Test: New behat feature covering the multilevel location filter UI: the tree panel offers all levels (or only the top level with entitytreefiltertoplevelonly), selecting the top node filters the whole branch, and the location hover card for deep hierarchies appears by default and disappears with entitytreefiltershowlocationhovercard off. The behat option generator ("mod_booking > options") accepts a new optional 'entity' column (entity name) that attaches a local_entities entity to the created option. (Wunderbyte-GmbH/Wunderbyte-GmbH#2011)
* Test: Cover confirmation mode 2 on an over-full waiting list.

## Version 9.7.1 (2026073000)
* Improvement: Accessibility improvements for bookit button.
* Improvement: Update vue to 3.5.40 for security reasons.
* Improvement: Accessibility improvements (navigation in report2.php and checkout workflow).
* Bugfix: Fix bug with ambiguous id in SQL of entities tree provider class.
* Bugfix: The site setting "Turn off modals" (booking | turnoffmodals) now takes effect in EVERY list view (list, image left, image right, image left half) and in every list rendered by a shortcode - including [courselist] and shortcodes from external plugins. So far the decision was made from the view configured in the booking instance, so a shortcode list of an instance that is set to (or merely offers) the cards view kept opening modals; and the pre booking pages only ever loaded into rows carrying the mod_booking .mod-booking-row markup, which meant the inline area of other row templates (e.g. of external plugins) opened empty. The booking options table now reports the view it actually renders (respecting the runtime template switcher) and the inline area is placed into the option row of any table template. Only the cards view keeps its modals, as inline pre booking pages are not supported there yet. A booking action re-rendering the button no longer flips an inline area into a modal (or vice versa) either, and closing a pre booking page now closes the container it really lives in.
* Bugfix: Inline pre booking pages stuck out over the left border of the booking option card, because their rows still carried the negative gutters they need inside a modal body. The gutters are neutralised now and the content is centered.

## Version 9.7.0 (2026072401)
* New feature: Bookings tracker, option scope - "Rate users" bulk modal (migrated and modernized from the report.php rating column + button): rate all checked booked users at once through the standard Moodle rating API (numeric or custom scales, "Rate..." entry removes a rating; raters cannot rate their own booking). Shown when the rating column is configured, ratings are enabled on the instance (assessed) and the user is a teacher of the option or has moodle/rating:rate; writing is enforced through mod/booking:rate as before.
* New feature: Bookings tracker, option scope - "Enrol users in the course" bulk action (migrated from report.php subscribetocourse): manually enrols the checked users into the course connected to the option, also when auto-enrolment is disabled. Shown when the instance has autoenrol off and the option has a connected course. Gated by mod/booking:subscribeusers (re-checked server-side) - the plugin capability for putting other users into bookings/courses; the old report.php button was gated by the unrelated messaging capability mod/booking:communicate.
* New feature: Booking agent can link a Moodle course when creating an option (linkedcoursequery); update_option advertises its course-linking capability for discovery.
* Improvement: The Bookings Tracker (report2.php) now supports the same columns as report.php: responsesfields/reportfields and custom form columns are mapped onto the tracker tables. (MUSI-895 / GH-1801)
* Improvement: report2.php also accepts the id parameter of old report.php URLs, so existing links keep working.
* Improvement: Added missing de_gs language strings.
* Improvement: Namespace collisions (moodle.org approval blocker): all global plugin functions now carry the frankenstyle prefix booking_ so they cannot clash with functions of other plugins or Moodle core. Renamed: is_json, get_list_of_booking_events and db_is_at_least_mariadb_106_or_mysql_8 (lib.php), get_rendered_customfields, get_rendered_eventdescription and optiondate_duplicatecustomfields (locallib.php), send_custom_message (sendmessage.php) as well as all upgrade step helpers in db/upgradelib.php - each with the booking_ prefix prepended and all callers updated. Class methods (like the availability conditions' is_json_compatible) are untouched, and the required Moodle callback names (booking_add_instance, xmldb_booking_upgrade etc.) already followed the convention.
* Improvement: Licensing compliance (moodle.org approval blocker): the plugin root now contains a LICENSE file with the full GNU GPL v3 license text, matching the license declared in all file headers and the README (which now links to the file).
* Improvement: All external service classes were migrated from the deprecated global externallib.php aliases (external_api & co.) to the core_external namespace, which also makes them unit-testable without process isolation. The MOODLE_INTERNAL checks of these classes were removed along with the require of externallib.php they used to guard, so the codechecker (moodle-cs) no longer flags them as unexpected.
* Improvement: Bookings tracker - the "View all bookings separately" view of the system and course scopes now shows the booking instance of each booking too, as a sortable column with a filter and included in the fulltext search - like the aggregated options view of these scopes already does (the table download includes the new column as well). In instance scope the column stays hidden, as it would repeat the same value in every row.
* Improvement: Bookings tracker - the option and optiondate scopes are now readable by the same audience as the old report.php: teachers of the option, mod/booking:viewreports and (fallback) mod/booking:readresponses, in addition to mod/booking:updatebooking which gated the tracker so far. Write actions strictly keep their own capability checks, and gaps were closed along the way: deleting checked answers now requires mod/booking:deleteresponses server-side (like on report.php and like the button gate - before, the server check was bookforothers); triggering certificates now rechecks tool/certificate:manage server-side (before, only the button was gated); the table download requires mod/booking:downloadresponses (the report.php export capability) instead of updatebooking. Buttons whose modals require more rights than reading (presence/notes need managebookedusers, rating needs mod/booking:rate) are hidden from read-only users instead of failing on submit.
* Improvement: Bookings tracker - write actions are gated by their specific write capability alone: deleting checked answers by mod/booking:deleteresponses, transferring and enrolling users by mod/booking:subscribeusers. Toggling the completion status now requires mod/booking:managebookedusers (before, the read capability readresponses sufficed like on old report.php); presence/notes already required managebookedusers. Rating stays gated by mod/booking:rate (an assessment capability that deliberately includes teachers), messaging by mod/booking:communicate.
* Improvement: The write capabilities mod/booking:deleteresponses and mod/booking:subscribeusers are no longer granted to the non-editing teacher archetype by default, so on NEW installations non-editing teachers are read-only in the reports (they keep readresponses/downloadresponses). Existing installations are not affected: archetype changes never touch existing role definitions on upgrade - non-editing teachers who already have these rights keep them (the defaults only apply to fresh installs and manual role resets).
* Improvement: The bookings tracker (report2.php) is a regular feature now - no PRO license required anymore and always active: the on/off admin setting (booking/bookingstracker) was removed entirely (an upgrade step drops the stale config value), access is controlled purely by the capabilities. The remaining tracker settings (presence counter) moved out of the PRO section, the navigation nodes lost their PRO badge/disabled styling, and the report2 entry in the booking options table dropdown is always offered.
* Improvement: New dedicated download endpoints download_signinsheet.php and download_checklist.php replace the report.php?action=... download flow. The sign-in sheet URL only carries cmid and optionid: the sheet settings are persisted in the option JSON by the configuration modal and resolved server-side, as is the mode (legacy PDF vs. HTML template with pdf/word output). The checklist endpoint now requires the mod/booking:downloadchecklist capability (the old report.php action relied on page access only); the checklist button in the option description points to the new endpoint. report.php itself is unchanged until its removal.
* Improvement: Bookings tracker, option scope - the slot management header links (teacher unavailability, teacher assignments, slot calendar) were migrated from the old report.php header for slot booking options, with the same capability gating.
* Improvement: report.php shows a deprecation warning (alert-warning) at the top, linking to the option scope of the bookings tracker (report2.php), so users can already try the new version.
* Improvement: Deleting a booking option now runs through a delete/cancel confirmation modal plus the new webservice mod_booking_delete_booking_option instead of the old action=deletebookingoption URL flow on report.php (which stays unchanged until report.php is removed). Both entry points were moved to the modal: the "Delete this booking option" entry in the actions menu of the booking options table (after the deletion the current page is reloaded, so shortcode pages like [allbookingoptions] listing options of several instances stay open and show that the option is gone; a page scoped to the deleted option escapes to the instance view instead) and the entry in the booking option settings navigation (without JS it now falls back to the detail view of the option instead of report.php). As before, the confirmation shows the option title incl. the number of booked users, and deleting requires mod/booking:updatebooking in the instance the option belongs to - enforced by the webservice, also in tables mixing options of several instances.
* Improvement: Bookings Tracker (report2.php, option scope): users with mod/booking:updatebooking see an info hint that the visible columns are configured in the instance settings, section "Configure fields and columns" > "Manage Responses Page & Bookings Tracker" - with a direct link to that section of the settings form.
* Improvement: Bookings Tracker (report2.php, option scope): a compact info line below the title now shows the optiondates (a single date directly, multiple dates behind a "Show dates" link that expands them, incl. entities, if installed), a "Show description" link expanding the description, the teacher(s) and responsible contact(s) linked to their user profiles and - like on the old report.php - the associated course (if the option is connected to a Moodle course) as a link.
* Improvement: Bookings Tracker (report2.php, option scope): new buttons "Send message to teacher(s)" and "Send message to responsible contact(s)" next to the sign-in sheet download button — both open the same e-mail modal as the "Send custom message" action button of the booked users table (recipient autocomplete with preselection, subject, message, attachment), but preselect the teachers resp. the responsible contacts of the option instead of the checked rows of the table; each button is only shown if the option has such recipients and the user has the mod/booking:communicate capability. The former "Send message to teacher(s)" action button of the booked users table was folded into the new header button, so the teacher e-mail action no longer appears twice in the option scope.
* Improvement: The instance setting "Custom fields that are to be displayed as filter options" is now an autocomplete instead of a plain multi-select.
* Improvement: Bookings Tracker (report2.php, option scope): the sign-in sheet can now be configured and downloaded there too — via a modern dynamic form modal instead of the old inline JS form on report.php (which stays unchanged); the download itself uses the identical endpoint, so the generated sheets are the same.
* Improvement: Sign-in sheet settings made in the modal are persisted in the JSON of the booking option, and a "Download sign-in sheet" quick button downloads with them directly. Fallback chain when an option has no persisted settings yet: booking instance defaults (new fields in mod_form incl. "Use sign-in sheet settings from plugin configuration" with a link there) → global plugin presets (new settings.php section "Sign-in sheet download presets").
* Improvement: Sign-in sheet settings that are not applied in HTML template mode are not offered there anymore (new UIs only): "Add empty rows" (PDF mode only), "Save as" (HTML mode only) and the "Add date manually" choice of "Display date(s) in the header", which behaves identically to "Hide dates" in HTML mode.
* Improvement: German translation added for the {customfields} placeholder description (lang/de contained the English text).
* Improvement: Bookings Tracker (report2.php): the scope navigation (site / course / instance / option / date) is now a standard Bootstrap breadcrumb (new template mod_booking/report/navigation_breadcrumbs) with the localized scope labels in small print above each crumb. Ancestor scopes link to their report2 view (plain text without the capability), the current scope links out to its own page (course page, instance view, detail view of the option) in a new tab. The optiondate switcher is now a Bootstrap dropdown crumb with plain links instead of a JS-driven select - in optiondate scope it is the active crumb, showing the current session as toggle text and marking it in the menu. Each crumb is styled as a rounded box (scope label above the name) with chevron arrows pointing to the next hierarchy level; the current scope is tinted with the theme primary, linked boxes lift on hover and keyboard focus. WCAG 2.2 AA: nav landmark with aria-label, aria-current on the active crumb and session, the sessions toggle is a real button (native Enter/Space, aria-expanded), the decorative arrows are hidden from screen readers, the icon-only page link names its target and meets the 24px minimum target size. Removed along the way: the bookingjslib AMD module and the navigation_dropdown template (incl. its broken inline onchange handler), the dynamically generated style block for the localized labels and the now unused public helper booking::generate_localized_css_for_navigation_labels().
* Improvement: The e-mail modals in the Bookings Tracker (report2.php: send custom message, send message to teacher(s), send message to responsible contact(s)) now show the list of available e-mail {placeholders} in the same collapsible info box as the booking rules mail actions.
* Improvement: The "Configure sign-in sheet" modal now starts with an info box explaining that the "Download sign-in sheet" button reuses the settings of the last download, how the settings cascade works (booking option → booking instance → global plugin presets) and which sign-in sheet mode (classic / HTML template) is currently active — all labels resolved from the live UI strings; admins (moodle/site:config) additionally get a link directly to the mode setting in the plugin configuration.
* Bugfix: User-visible error text of the booking redirect page now comes from the lang string API (en, de, de_gs) instead of a hardcoded English string. (GH-2102)
* Bugfix: The built AMD artifact of the Vue app (app-lazy.min.js) no longer appears invalid, unminified or out-of-sync with its source: the committed amd/src file is regenerated in sync with the build and the license comments stay in the file. (GH-2099)
* Bugfix: thirdpartylibs.xml no longer declares third-party libraries that are not actually bundled in the package. (GH-2098)
* Bugfix: The legacy AJAX rating endpoint (rating_rest.php) was replaced by the proper webservice mod_booking_rate_option. (GH-2097)
* Bugfix: CI workflow workaround to fix the "Unable to launch a new process" error.
* Bugfix: A course fullname created from a template can be a duplicate again. (GH-2074)
* Bugfix: The de_gs generator (cli/generate_de_gs_lang.php) produced mixed gender spellings like "eine:n Entwickler/in": it converted "Entwickler:in" to the slash form but had no rule for accusative articles/pronouns like "eine:n". A generic rule now rewrites any "...e:n" form (eine:n, keine:n, jede:n - also with * or _ separator) to "...e/n", replacing the narrow jede:n-only rule; lang/de_gs/booking.php was regenerated (this also picked up six privacy metadata strings whose regeneration had been missed).
* Bugfix: Privacy API (moodle.org approval blocker): the privacy provider now declares ALL user-related tables. Newly declared with all fields: booking_slot_moves (pending/committed slot rebookings of a user incl. price difference), booking_slot_student_teacher (teacher assigned per student for a slot option), booking_sync_attempts (per-user enrol/unenrol sync log) and booking_teacher_unavailability (teacher absence periods - flagged proactively: its user reference is called teacherid, so the reviewer's userid scan missed it). The four tables are also wired into the request handlers: get_users_in_context lists their users (incl. teacherid columns), delete_data_for_user and delete_data_for_users remove the rows, and delete_data_for_all_users_in_context clears them per instance via the option ids. Where a deleted user is only the ASSIGNED teacher of somebody else's slot booking, the student's row survives with the teacher reference blanked instead of destroying the student's data. Lang strings for every declared field in en and de.
* Bugfix: Privacy API (moodle.org approval blocker): the privacy provider now declares the plugin's only transfer of personal data to an external system via add_external_location_link(). The booking action "Execute REST script" sends - depending on its configuration - the booking user's profile data (first name, last name, e-mail, username), their custom booking form answers and placeholder values of the configured JSON body to the admin-defined REST endpoint; the declaration and a code comment in the provider document this (metadata lang strings in en and de). The only other external call candidate, classes/GoogleUrlApi.php (the retired Google URL shortener), was dead code - the whole class body had been commented out for years and nothing referenced it - and has been removed entirely. The vestigial booking_options.shorturl DB column (only writable via the addbookingoption webservice, never read or displayed) stays untouched to keep the webservice signature and backups stable.
* Bugfix: Security hardening (moodle.org approval blocker): sesskey (CSRF) validation on all state-changing action handlers of the page scripts. Deleting a tag template (tagtemplates.php), an option template (optiontemplatessettings.php) and a booking instance template (bookinginstancetemplatessettings.php as well as the equivalent admin page instancetemplatessettings.php) now requires a valid sesskey, which the delete buttons pass along. The e-mail unsubscribe link (unsubscribe.php) cannot carry a sesskey, so it now shows a confirmation page first and only removes the notification list entry on the sesskey-protected continue request (new lang string unsubscribe:confirmnotification). Two missing authorization checks were closed along the way: deleting an option template now requires mod/booking:manageoptiontemplates (the same capability that gates creating one), and bookinginstancetemplatessettings.php - which had no capability check at all, so any course participant could list and delete instance templates - now requires mod/booking:updatebooking or mod/booking:addeditownoption like the equivalent admin page. The remaining action handlers were audited: report.php (deletebookingoption) and slotrules.php already validate the sesskey, and the join action of link.php is a read-only redirect.
* Bugfix: Security hardening (moodle.org approval blocker): the webservice signatures no longer declare PARAM_RAW where a strict type exists. Inputs: 16 lookup and plain-text parameters of mod_booking_addbookingoption (identifiers, idnumbers, shortnames, location/institution/address, username, responsible contact, comma-separated condition lists, opening/closing time strings) are PARAM_TEXT; the area parameter of mod_booking_bookit is PARAM_ALPHANUMEXT (values are "option", "subbooking" or "subbooking-<id>"); the sessionkey of get_submission_mobile is PARAM_ALPHANUM and the submitted custom form field names/values are PARAM_ALPHANUMEXT/PARAM_TEXT. Returns with a scalar meaning got scalar types too: toggle_notify_user error and get_submission_mobile message are PARAM_TEXT, bookings points is PARAM_FLOAT, get_parent_categories item name and load_pre_booking_page template name are PARAM_TEXT. The remaining PARAM_RAW declarations are genuine JSON payloads/returns or HTML content where no stricter type exists; every such input documents its server-side validation in the signature (slot selection/release keys and teacher maps are cast to int server-side, the bookit data payload is reduced to positive int override ids, the option form config payload is gated by mod/booking:editoptionformconfig), and HTML returns (intro, descriptions, before/after booked texts) follow the core convention of cleaning on display via format_text.
* Bugfix: Security hardening (moodle.org approval blocker): page scripts no longer read request parameters as PARAM_RAW where a strict type exists. The encodedtable parameter of the three table download scripts is cleaned as PARAM_ALPHANUM (it is an md5 hash referencing the cached table definition), sendmessage.php now receives the selected user ids as a comma-separated PARAM_SEQUENCE list instead of raw JSON (report.php builds the link accordingly, the hidden form field is typed PARAM_SEQUENCE and every id is still cleaned to int server-side), report2.php cleans viewtype as PARAM_ALPHA, the sesskey of bulk_book_handler.php is PARAM_ALPHANUM, the switchfield no-submit button of managecustomfieldoptions.php is PARAM_TEXT, the cmid fallbacks of the dynamic optiondate/teacher forms are PARAM_INT and the customfield options form reads the submitted labels as PARAM_TEXT and the repeat counter as PARAM_INT. editoptions.php dropped two parameters it never used (mode, and a sesskey that was even cleaned with the wrong type). The only remaining PARAM_RAW read is the JSON list of the elective credits calculation, which is documented in the code and covered by tests: every element is cleaned to an int option id before it reaches the database (a flat PARAM_SEQUENCE list would merge the digits of injection payloads into wrong ids instead of discarding them).
* Bugfix: Security hardening (moodle.org approval blocker): capability checks on page scripts. download_report2.php now re-checks mod/booking:downloadresponses server-side in the context of the requested scope (before, only the download BUTTON was gated and any logged-in user could call the endpoint and export the booked users incl. personal data); unknown scopes are rejected before any table is instantiated. viewconfirmation.php requires mod/booking:view like view.php (it only ever shows the current user's own confirmation). unsubscribe.php works on the module context of the booking instance instead of the system context; the notification unsubscribe stays deliberately capability-free as a self-service action which only ever removes the current user's own entry (documented in the code).
* Bugfix: Upgrade hardening (moodle.org approval blocker): db/upgrade.php no longer contains operations that could time out on big production sites when the upgrade runs through the admin interface. The customfields deduplication of step 2017112101 re-scanned the whole booking_customfields table once per deleted duplicate row (an unbounded while loop); it now runs as one set-based pass with chunked bulk deletes (new testable helper booking_delete_duplicate_customfields_2017112101 in db/upgradelib.php, same result: the oldest row of each optionid/cfgname group is kept) and the step calls upgrade_set_timeout(). Step 2024121600 loaded every booking option with empty availability into memory and rewrote each row one by one; it now sets availability = '[]' in a single set_field_select statement.
* Bugfix: Security hardening (moodle.org approval blocker): SQL queries no longer interpolate variables directly into the statement, all values are bound as parameter placeholders: coursecategories::return_course_categories (category id; also fixes an undefined $where notice when called without restriction), elective::return_credits_booked and return_credits_left (userid/bookingid) and booking::get_all_optionids_of_teacher (userid/bookingid). The dynamic query in booking_option_settings::set_values already bound all values via the $params of get_options_filter_sql - a comment now documents that the select/from/where fragments are internal SQL, not values.
* Bugfix: Security hardening (moodle.org approval blocker): every external webservice function now validates its execution context (validate_context, which enforces login and course/module access) and the required capabilities before processing the request. In particular: the raw option record service (optiontemplate) now requires mod/booking:manageoptiontemplates instead of being readable by anyone; the bookings API only exposes the booked users (personal data incl. e-mails) with mod/booking:readresponses in the instance and requires access to the requested course; toggle_notify_user, bookit, allow_add_item_to_cart, load_pre_booking_page, get_booking_option_description and get_submission_mobile validate the module context of the option and gate acting for other users behind the book-for-others/cashier rights; all autocomplete search backends (users, teachers, courses, templates, booking options, EvaSys forms/periods, Respond parent keywords) require one of the option editing capabilities anywhere (new helper permissions::require_any_booking_editing_capability); the performance tool services require view/editperformance; the option form config read service requires mod/booking:editoptionformconfig like the save service.
* Bugfix: Security hardening (moodle.org approval blocker): no more direct superglobal access ($_GET/$_POST/$_REQUEST) anywhere in the plugin - all user input now goes through Moodle's cleaning layer. report.php reads its submit buttons and form values via optional_param() and parses the nested user[][id] checkbox array through the new booking_get_selected_userids() helper, which cleans every user id (locallib.php); the elective credits calculation cleans the JSON list parameter per option id; dates_handler::add_values_from_post_to_form() cleans the dynamic coursetime-* values, semesterid and dayofweektime; the ajax request detection in modechecker uses optional_param() with PARAM_BOOL.
* Bugfix: An expired/missing PRO license no longer wipes stored PRO configuration when options or instance settings are saved. The PRO-only form sections are not rendered without a license, and the save code interpreted the missing fields as "cleared by the user": saving a booking option deleted the shared places configuration (sharedplaceswithoptions/sharedplacespriority), the booking actions (boactions, also affected by showsubbookings-style toggle showboactions being off) and the certificate configuration incl. expiry settings (also affected by certificateon being off) from the option JSON; saving the instance settings switched off the template switcher (incl. its selection) and the elective mode. A missing form key now preserves the stored value, while submitting an empty value with an active license still clears it as before.
* Bugfix: The elective checkboxes (iselective, enforceorder, consumeatonce) are now advcheckboxes: they always submit 0 or 1 when rendered, so a missing key unambiguously means "not part of the form" (see above). As plain checkboxes they submitted nothing when unchecked, which also meant that enforceorder and consumeatonce could never be switched off again through the instance form (the missing key never wrote a 0 to the DB).
* Bugfix: Slot booking — booking an additional slot (while still below max_slots_per_user) through the booking modal silently created no answer although the confirmation page reported success; the booked-state gate in the prepage flow now honours remaining slot capacity. (GH-2053)
* Bugfix: Slot booking — the "Booked slots" shown in the booking options table now aggregate the slots of all of a user's active answers instead of only the newest one. (GH-2053)
* Bugfix: The placeholder help list (booking rules mail actions, e-mail modals, mod_form) silently swallowed entries whenever two placeholders share the same translation in the current language - e.g. in German {pollurl} was hidden by {evasyssurveylink} (both "Link zur Umfrage"). The list is now keyed by the unique placeholder classname instead of the localized description. Note: the format of the public placeholders_info::$localizedplaceholders array flipped accordingly (classname => localized description).
* Bugfix: Sign-in sheet (HTML template mode) — the [[dates]] placeholder rendered multiple sessions directly next to each other without separation; the newline separators are now converted to line breaks, so each session gets its own line (as in classic mode). For the Word download this additionally needs the wunderbyte_table fix that wraps line breaks in a valid run (Word ignored the schema-invalid bare <w:br/> of the bundled PhpWord).
* Bugfix: Sign-in sheet download (HTML template mode) failed with "Could not load image [[logourl]]" when no header logo was configured — the img tag is now removed in that case; a configured logo is embedded as a base64 data URI, so PDF/Word generation no longer depends on fetching a pluginfile URL without a login session.
* Test: New tripwire test guards against exit()/die() in library code.
* Test: Agent skill tests are skipped when the optional bookingextension_agent subplugin is absent, so a standalone installation can run the test suite.
* Test: New PHPUnit tests (privacy/provider_test.php) guard the privacy provider: a tripwire test parses install.xml and fails when any table with a userid/teacherid column is not declared in the metadata (so no user-related table can ship undeclared again), a second test asserts every referenced metadata lang string exists (it immediately caught one missing string), and two deletion tests prove delete_data_for_user/delete_data_for_users clear the slot/sync tables for the right users only - including the teacher-reference blanking.
* Test: The bookings tracker test suite covers the new server-side download gate: admins and non-editing teachers pass has_capability_in_scope for downloadresponses, students are rejected.
* Test: New PHPUnit tests (upgradelib_test.php) prove the deduplication keeps exactly the oldest row per group, leaves unique rows untouched and is idempotent.
* Test: New PHPUnit tests (sql_placeholders_test.php) pin down that the migrated queries still select exactly the intended rows (own user/instance scoping, parent category filter).
* Test: New PHPUnit tests (external_context_capability_test.php) prove that unenrolled users, users without the respective capability and users acting for somebody else are rejected by the external services, while the intended audiences keep working.
* Test: New PHPUnit tests (superglobal_input_cleaning_test.php) prove that SQL injection and XSS payloads in the report user selection, the elective list parameter and the dynamic optiondate form values are reduced to harmless cleaned values.
* Test: New PHPUnit tests cover the download endpoint URL/mapping helpers (incl. the checklist button target), the slot header links per role, the bulk enrol action (enrolment despite disabled autoenrol, missing course, capability recheck) and the rating modal (writes/deletes ratings, skips the rater's own answer, out-of-scale values write nothing, plugin permission and assessed gates).
* Test: The bookings tracker is now fully covered by PHPUnit tests: the presence and notes modals (option scope and per-session optiondate scope incl. their managebookedusers gate), the transfer modal (form layer incl. subscribeusers gate), the bulk table actions (completion toggle incl. gate, delete incl. deleteresponses gate, certificate trigger incl. tool/certificate:manage gate and disabled-config path), the info line data (incl. associated course - extracted into the testable helper report2_infobox), the action button visibility matrix of the option scope per role and responsesfields config, the download button gate and the per-status SQL of the side tables (waiting list, reserved, notify list, deleted). Writing these tests uncovered that the downloadresponses switch of the table export had only reached the scope base class - the ten scope-specific overrides still checked updatebooking; they are aligned now. A new behat feature (booking_report2_tracker.feature) covers the options/answers view switch of the system scope.
* Test: New PHPUnit tests simulate the option form and instance form roundtrip with and without PRO license and assert that PRO configuration survives non-PRO saves and can still be changed and cleared as before with an active license.
* Test: The behat delete scenario was switched to the new modal flow; new scenarios cover cancelling the modal and the "x users are booked" warning when deleting an option with booked users; new PHPUnit tests cover the delete_booking_option webservice (deletion incl. answers and event, required capability, refusing a foreign cmid).
* Test: Slotbooking behats updated for the capacity behaviour (row offers booking again until max_slots_per_user is exhausted, then locks to the booked state) and now book a second slot in calendar and list view; new PHPUnit regression test for the prepage repeat-purchase flow.
* Deprecation notice: report.php will be removed in a future release in favour of the bookings tracker (report2.php). The following report.php-only features will then be dropped without a tracker equivalent: sending the poll URL to users/teachers and the reminder e-mail (both replaced by custom e-mails with placeholders), booking users into a connected booking (booktootherbooking), record numbers (numrec column + generator incl. the numgenerator setting), the search form (booking date range/completed/waiting list) and the mailto link to all participants (replaced by the custom message modal).

## Version 9.6.3 (2026071600)
* Improvement: Slot booking — user-defined slot type with configurable duration granularity (slot_duration_step_minutes) and per-slot warmup/cooldown buffers with overlap or summed combination mode. (GH-2053)
* Improvement: Added show-only link into component view. (GH-176)
* Improvement: Booking agent create/update skills hardened — silently-coerced dates are refused with repair guidance, intuitive input keys (price alias, description) are accepted, and the constructor is grounded in the site's real price categories.
* Improvement: If a booking option supports enrolling multiple users (customform "enrol multiple users" field), report.php and the Bookings Tracker (report2.php, option scope) always show two enrollink columns (in the tables and in the downloads, independent of responsesfields/reportfields): the enrolment link a user has created or used, and "Enrolment link received from" linking to the profile of the user who made the original booking.
* Improvement: Bookings Tracker (report2.php): the separate answers view in the system, course and instance scopes now shows a fixed set of columns: prefix, booking option, first name, last name, email address, time booked and time modified.
* Improvement: Bookings Tracker (report2.php): the optiondate scope now shows a fixed set of columns: user picture (only if configured in responsesfields), first name, last name, email address, presence and notes.
* Improvement: Bookings Tracker (report2.php): the optiondate scope now shows a presence filter which is visible right away (including presence statuses no user has yet).
* Improvement: Booking agent rule skills resolve via the rule's own context instead of asking for an activity; preflight error causes split into user and repair channels.
* Bugfix: Booking option maxanswers defaults to unlimited (0); the agent never asks about capacity.
* Bugfix: Non-string query fields are coerced safely (no "Array to string conversion").
* Bugfix: A bulk update without a known change field no longer reports success.
* Bugfix: Person resolution refuses anonymization placeholders and never resolves the guest account.

## Version 9.6.3 (2026071500)
* New feature: New global plugin setting "customfieldsforview" as fallback for the booking instance setting of the same name: if an instance does not define customfields to be shown for each booking option in the options overview (view.php), the globally selected customfields are shown; if the instance defines its own customfields, only those are shown.
* Improvement: Trainer can now book again.
* Improvement: Optiondates now accept dateparseformat on import.
* Test: New unit tests making sure the plugin settings page loads without errors on a plain installation.

## Version 9.6.2 (2026071001)
* New feature: New bulk operations page in the Booking plugin settings.
* New feature: AI wizard — new read-only skill list_instance_settings returns the configurable instance fields with current values; configure_booking_instance is write-only now.
* Improvement: AI wizard — diagnose_user_booking resolves a named option from any context (like the other diagnose skills) and flags an unresolvable optionquery instead of silently degrading to the instance-wide overview; every reported option carries its host course and booking instance.
* Improvement: AI wizard — the no-instance scope observation no longer reads as a site-wide "no booking activities" state in later turns and points to the target-parameter retry path.
* Improvement: AI wizard — search_options, list_option_properties and the two diagnose skills resolve their booking activity from any context (optionid or activityquery), instead of dead-ending outside a booking module context.
* Improvement: AI wizard — mutation previews always name the target activity and course, bulk previews list the affected options, and every changed field is shown.
* Improvement: AI wizard — failed mutations report per-option postcondition failures and which fields were actually persisted.
* Bugfix: booking_add_instance/booking_update_instance no longer crash on records loaded from the DB (count() on comma-separated string fields).
* Bugfix: Fix enrolmultipleusers via cashier (wrong number of items). Wunderbyte-GmbH/Wunderbyte-GmbH#1974
* Bugfix: Fix several enrollink bugs. Wunderbyte-GmbH/Wunderbyte-GmbH#1535, Wunderbyte-GmbH/Wunderbyte-GmbH#2057, Wunderbyte-GmbH/Wunderbyte-GmbH#2058, Wunderbyte-GmbH/Wunderbyte-GmbH#1558

## Version 9.6.1 (2026070901)
* New feature: Booking agent — an AI assistant (bookingextension_agent) that creates, updates and manages booking options and answers questions from natural language, reachable from a global navbar entry point.
* New feature: Entities treefilter — the location filter now shows the entity parent/child hierarchy as a searchable tree (requires local_wunderbyte_table 2026070800 or newer).
* New feature: The location cell shows deep entity hierarchies as an accessible hover card; its entries link to the entity view pages and hover-card images are opt-in.
* New feature: Entity cross-option availability and capacity/equipment booking — an option can require and consume the capacity of an entity or equipment across options.
* New feature: After-booking actions can trigger a REST call (executerestscript, with optional JSON body, custom HTTP headers, TLS verification and optional JWT signing of the outgoing request) and can now also run on cancellation, not only on booking.
* New feature: Read-only CLI cli/audit_booking_invariants.php to audit booking-answer DB invariants (overbooking, waiting list, duplicate answers, orphans, enrolment).
* Improvement: bookingextension settings are now available regardless of the Booking PRO license.
* Improvement: Better colour contrast for improved accessibility.
* Improvement: Performance — a per-option capacity lock closes the overbooking race; system-wide cache broadcasts are deferred and reduced during waiting-list sync, bulk operations and single bookings; category lookups are batched; the MariaDB/MySQL version check is cached; and slot booking hoists option-wide queries out of the per-slot loop.
* Bugfix: Refresh the shopping cart display whenever the prepage booking modal is closed - also via ESC or a backdrop click, not only via the close button.
* Bugfix: Cashiers without 'mod/booking:bookforothers' could not load the customform prepage when booking for another user, so multi-user bookings (enrolusersaction) were silently booked with quantity 1. The 'local/shopping_cart:cashier' capability is now accepted for acting on behalf of another user, and the prepage continue button stays blocked if the customform fails to load (fail closed).
* Bugfix: Availability SQL filter — tolerate NULL availability and make the userprofilefield &lt; and &gt; operators numeric and DB-agnostic (MariaDB and PostgreSQL).
* Bugfix: REST after-booking action JSON-body placeholders are resolved per token, with new {baid} and {userid} placeholders.
* Bugfix: The "user affected by event" option is gated by the selected event.
* Bugfix: The scheduled mails page resolves its context like edit_rules.php and lists scheduled mails context-specifically.
* Bugfix: Read the entitytreefilter setting from the correct component.
* Bugfix: Fix error on settings.php when no customfields exist yet.

## Version 9.6.0 (2026070900)
* New feature: New booking instance setting "customfieldsforview" to display booking option customfields for each booking option in the options overview (view.php) — in list view (footer area, right next to institution) and cards view (card list, one customfield per line, right above the dates), styled like the other info entries (e.g. institution). The icons configured in the plugin settings (customfieldicon_<shortname>) are shown in front of the values, just like on the option detail page; if no icon is configured, the default icon fa-puzzle-piece is used.
* New feature: Add individual columns and customfields to fulltext search.
* New feature: Add a new toggle filter with shortcode arg 'filterbookablenextdays' to filter for all bookable options within the next N days, e.g. [courselist filter=1 filterbookablenextdays=28].
* Improvement: Shortcode argument includecustomfields: if no region is given (e.g. includecustomfields="shortname1,shortname2"), the customfields are now rendered in the standard region of the rendered template (footer in list view, card list in cards view) with the standard styling, instead of the cardbody region which is only visible in the cards view. Explicitly given regions are unchanged.
* Improvement: customfields in cards and optiondescription can now be assigned icons.
* Bugfix: Don't change time modified for waitinglist confirmation.
* Bugfix: Display waitinglist column for unlimited waitinglist.
* Bugfix: Display enrolledincourse condition independly to usesqlfilteravailability condition.

## Version 9.5.1 (2026070301)
* Bugfix: Make sure no classes from shopping cart are required in booking.

## Version 9.5.0 (2026070300)
* Improvement: The full text search on booking customfields (via shortcode argument or instance setting fulltextsearchcolumns) now also searches the display value resolved by the wbt_field_controller (e.g. select labels or the data returned by the SQL of a dynamicformat field), not only the stored key.
* New feature: New booking instance setting "Columns to add to the full text search" to add columns of booking options or booking customfields to the full text search of the booking options table.
* New feature: New shortcode argument fulltextsearchcolumns (e.g. [courselist cmid="123" fulltextsearchcolumns="description,customfieldshortname"]) to add columns of booking options or booking customfields (by shortname) to the full text search of the table. Setting the argument implicitly enables the search.
* New feature: New "Bulk operations" tab on the booking instance view page. It is enabled via the "Views to show" instance setting, requires the 'mod/booking:executebulkoperations' capability in module context and only shows booking options of the current instance. Users without 'mod/booking:canseeinvisibleoptions' in the module context only see visible options there. Also, the "Send mail to teachers" functionality of bulk operations now needs the 'mod/booking:communicate' capability.
* New feature: Add setting 'eventslogtimefilter' to limit recent changes in booking option and booking instance form for better performance.
* New feature: Include Booking Rules on instance duplication.
* New feature: New interface for improved feature to transfer any user(s) from one booking option to another.
* Improvement: All tabs on the booking instance view now show a fitting icon.
* Improvement: The capability 'mod/booking:executebulkoperations' is now assignable in module context (system-level assignments keep working).
* Improvement: Bulk operation forms now check capabilities on submission ('mod/booking:executebulkoperations' for bulk editing, 'mod/booking:communicate' for sending mail to teachers).
* Improvement: Bulk operations now run in adhoc task to avoid site crash.
* Improvement: Supervisors can book and confirm their own subordinates to a booking option.
* Improvement: Unify german gender notation
* Improvement: Use regex to unify german gender slash
* Improvement: Add genderslash lang package
* Improvement: Add PRO badge for setting 'duplicationrestorerules'.
* Improvement: Add new capability to allow duplication of courses without acces
* Improvement: visibility is shown
* Improvement: added instance to certificate condition and overwrite for multiple certificate issiuing
* Improvement: checkbox for multiselect
* Improvement: added customfield hierarchy_manager
* Improvement: hierachical filters in booking
* Improvement: first steps customfields in card
* Improvement: openbookingdetailinsametab with additional option
* Improvement: Possibility to place freeze warning underneath availability element
* Improvement: Persist all option-form header collapse states across no-submit
* Bugfix: The English and German 'bulkoperations' language strings were swapped.
* Bugfix: Allow messaging for booking (e-mails and notifications) by default so Booking Rules will work on new Booking installations.
* Bugfix: Add filter_multilang2 to CI workflow so test will work.
* Bugfix: Another fix for wrong page context fix.
* Bugfix: Fix page context for localized customfields and add unit test for mlang in customfields.
* Bugfix: Fix coding exception on bookings tracker (report2.php).
* Bugfix: Show countlabel of tables also when filters find records.
* Bugfix: Fix behats for github action so they do not fail at first run.
* Bugfix: Disable subscribeusers for slotbooking options
* Bugfix: Fix unit test (removed unnecessary fallback to alloptionstable which also needs to be removed in unit test).
* Bugfix: Moodle 4.5 accessibility fixes and revert to use phpunit's teardown() to ensure clean up of booking cache
* Bugfix: Correctly use user & relateduser in message provider
* Bugfix: only display header when option is of type slotbooking
* New feature: Booking AI agent integration for mod_booking (agent skills, providers, diagnostics).
* Improvement: Performance — memoise the DB-server version check; defer system-wide cache broadcasts during bulk booking, single-booking and waiting-list sync; batch category lookups.
* Improvement: Slotbooking — hoist option-wide queries out of the per-slot loop.
* Bugfix: Availability SQL filter — tolerate NULL availability; make user-profile-field </> operators numeric and DB-agnostic (MariaDB/PostgreSQL).
* Bugfix: Add a per-option capacity lock to close an overbooking race.
* Bugfix: Resolve REST after-booking action JSON-body placeholders per token; gate "user affected by event" by the selected event.
* Improvement: After booking actions — REST (executerestscript, cancel trigger).
* Improvement: Load bookingextension settings regardless of the Booking PRO license.
* Improvement: Scheduled mails page — align context resolution with edit_rules.php.
* Improvement: Entity cross-option availability and capacity/equipment booking (with behat coverage).
* Tests: gated concurrency/overbooking benchmark for booking capacity; further test improvements.

## Version 9.4.0 (2026062201)
* New feature: Slot booking - book and manage time slots inside a booking option: slot calendar picker and report, self-service move/cancel of booked slots, a unified "update booking" editor (move + cancel + change in one dynamic form), optional move-with-payment via shopping_cart, and per-slot booking rules (Wunderbyte-GmbH/Wunderbyte-GmbH#1596).
* New feature: Booking AI agent integration for mod_booking (skills, providers, diagnostics).

## Version 9.3.8 (2026062200)
* Improvement: Display specific countlabel for messages event table
* Improvement: Implement strings for upload
* Bugfix: Waitinglist confirmation task handle late joiners
* Bugfix: Display customfields in correct language

## Version 9.3.7 (2026061601)
* Improvement: implement showpagination argument in booking shortcodes
* Improvement: New capability 'booking:canseenumberofbookings'
* Improvement: Display reload button in eventslist table (report)
* Accessibility: fix - remove "settings" text (expected to be invisible but shown)
* Bugfix: Teacher Overview Moodle 5
* Bugfix: Signinsheet no logo if config empty
## Version 9.3.6 (2026060900)
* Improvement: Several accessibility improvements.
* Bugfix: Certificate Condition form not loading correctly.
* Bugfix: Pass module context to courselist shortcode to make invisible booking options work.
* Bugfix: For placeholders inside URLs we need to re-decode curly brackets.

## Version 9.3.5 (2026060100)
* New feature: Add possibility to synchronize users from global groups into booking options.
* Improvement: Link settings sections.
* Improvement: Extendable availabilityconditionsettings.
* Bugfix: Timebooked shows wrong timestamp.
* Bugfix: Fix wrong campaign limits time field - use timebooked instead of timecreated.

## Version 9.3.4 (2026051900)
* Improvement: Booking option templates can now be edited via bulk operations.
* Bugfix: Remove exception when legacymailremovalacknowledged is not checked.

## Version 9.3.3 (2026051300)
* New Feature: Booking time relative to coursestart.
* Improvement: Add possibility to check auto-apply fields separately.
* Improvement: Show warning on view.php instead of exception when uselegacymailtemplates is active but legacymailremovalacknowledged has not been set yet.
* Improvement: New confirmation setting to confirm that legacy emails will soon be not supported anymore.
* Improvement: Enable detailed changes for special classes like price.
* Improvement: Setting if teachers see own invisible options in teachers.php
* Bugfix: Create warning only once per condition.
* Bugfix: Disable all possible elements of conditions with skippableconditions setting applied.
* Bugfix: Setting skippableconditions also applies to select of nooverlappingcondition.
* Bugfix: fix for: confirmcancel::is_available() hides the confirmation condition for priced options in most “booked” cases.
* Bugfix: Allow cancelling with new price category.
* Bugfix: Do not block view.php in behat tests.
* Bugfix: Fix error on upgrade when plugin tool_certificate is missing.
* Bugfix: Disable legacy mail templates directly to avoid JS timeout from TinyMCE editors (Bootstrap 5 / Moodle 5.1+).
* Bugfix: Fix failing behats for Bootstrap 5 (Moodle 5+).
* Bugfix: When a booking option can be booked again, notification list should not block (also add new unit test).
* Bugfix: correctly retrieve and format values on bookingoption description via field controlle.
* Bugfix: SQL error when user try to create a rule ("days before", "specific time") for installment data field.
* Bugfix: Fix behat - previously booked warning now contains title of booking option.
* Bugfix: Show booking option name in description of previouslybooked condition.
* Bugfix: Correctly record price for changes.
* Bugfix: Handling of price changes.
* Bugfix: Catch error for 0 user when executing customfield placeholders.

## Version 9.3.2 (2026043000)
* New feature: Add direct messaging with attachments to bookings tracker.
* Improvement: Show info texts on shortcode myfavorites if PRO license or setting not enabled.
* Improvement: Add German certificate documentation (CERTIFICATES_DE.md)
* Improvement: Check conditions for enrollinks and add possibility to skip them.
* Improvement: When booking via enrollink always skip some conditions, improve defaults.
* Improvement: Add bookingstracker URL to booking option settings.
* Bugfix: Fix exception when waiting list was set to unlimited ("-1").
* Bugfix: Fix some strings and wrong naming of bulk operations button.
* Bugfix: Fix string in unit test.
* Bugfix: Guests should not see "my booked options" in booking instance.
* Bugfix: Make sure that enrolmultipleusers checks booking limits and improve validation and tests.
* Bugfix: On enrolmultipleusers via form, make sure it's not possible to increase in shopping cart to a number higher than the available free places.

## Version 9.3.1 (2026042400)
* New feature: My favorites (added possibility to mark booking option as favorites)
* New feature: Add setting to choose default behavior of enrolmultipleusers, improve strings and add tests
* New feature: Show custom fields of related person (person affected by event) by adding "-related" to the placeholder, e.g. {myuserprofilefield-related}.
* New feature: New {emailrelated} placeholder to show e-mail of the related user (person affected by event).
* Improvement: Possibility to define default for nooverlapping availability condition
* Improvement: Details about shoppingcart changes in booking option updated event
* Improvement: Make sure that template name does not get lost when editing template and that it can be removed
* Improvement: Add status check to new scheduledmails table
* Improvement: Importer overhaul
* Improvement: Major improvements for field customfield handling and custom field performance.
* Improvement: Make sure we also add custom fields with empty value to customfieldsfortemplates array.
* Bugfix: No reminder mails for selflearningcourse, also check on task execution
* Bugfix: Nooverlapping not blocking when no dates given
* Bugfix: When instance title changes, we also rebuild course cache
* Bugfix: Service Period for selflearning courses depends on booking time
* Bugfix: Possibility to use custom user profile field twice for availability condition.
* Bugfix: Fix permission check in search_users web service.

## Version 9.3.0 (2026040800)
* New feature: Add possibility to save booking option templates without title and use template name instead.
* New feature: Add possibility for users with addeditownoption capability to actually add and edit their own option. Add new usercreated and usermodified fields to booking options and display them.
* New feature: Create new setting to issue certificates only manually.
* Improvement: Treat elements that need special format directly in definition_after_data of template.php.
* Improvement: Make sure copytotemplate uses set_data of field classes and creates new booking option correctly with the booking_option::update function.
* Improvement: Move booking option template creation from report.php to optiontemplatesettings.php and add new entry to dropdown menu.
* Improvement: Make sure addeditownoption is an edit-only capability (wrongly named for legacy reasons). To create booking options we introduce a new mod/booking:adoption capability.
* Improvement: handle empty teachers.
* Improvement: adapt certificate shortcode to requirements.
* Improvement: make editsemesters a capability.
* Improvement: Updated packages for vue.
* Improvement: Show real form values instead of just keys for form field selects.
* Improvement: Show name of booking instance when recreating option dates with change semesters form.
* Improvement: Better icon in bookings tracker.
* Improvement: Design improvements of Bookings tracker (report2.php).
* Improvement: Improve dates placeholders and templates and remove redundancies.
* Bugfix: Also set 0 value of selflearningcourse in duration class.
* Bugfix: Fix date_time_selectors in booking option templates.
* Bugfix: Make sure option dates can also be saved within template.
* Bugfix: Fix form submission in mobile app.
* Bugfix: fix empty temp values.
* Bugfix: delete_conditions_by_context function was never called because of typo.
* Bugfix: Fixed displaying empty booking option list.
* Bugfix: Fix NULL useridfrom when booking manager account is missing.
* Bugfix: Keep HTML in description placeholder by using format_text instead of format_string.
* Bugfix: Admin & all persons who have alwayscanapprove capability can confirm answers regardless of any other conditions.

## Version 9.2.1 (2026033000)
* Improvement: Make sure freetobookagain event is also triggered at campaign start/end if there are free places again because of campaign limits. Do this within the purge_campaign_caches task.
* Bugfix: Make sure specific time mails are not sent incorrectly.

## Version 9.2.0 (2026032700)
* New feature: Show custom fields of related person (person affected by event) by adding "-related" to the placeholder, e.g. {myuserprofilefield-related}.
* New feature: New {emailrelated} placeholder to show e-mail of the related user (person affected by event).
* New feature: Make all conditions skippable and hide or freeze them in form depending on capability.
* Improvement: Major improvements for field customfield handling and custom field performance.
* Improvement: Make sure we also add custom fields with empty value to customfieldsfortemplates array.
* Improvement: Task to check campaign start and end and check if freetobookagain event should be triggered.
* Improvement: Add certificate conditions.
* Improvement: Do not show certain buttons in wrong contexts (or when capability is missing).
* Improvement: Answers can be updated on import.
* Improvement: Add customfieldshortname-not functionality to shortcodes to exclude customfields.
* Improvement: Include Cohort and cohort selector into report.
* Improvement: Add a fallback on optionid when a rule event actually references a different table id.
* Improvement: When a user has completed a booking option, (s)he cannot cancel anymore.
* Improvement: Fix hardcoded supervisor logic.
* Improvement: Created years past filter.
* Improvement: Created a filter that checks if the value of a profilefield is the current user.
* Improvement: Divided datasource more broadly into answers and options.
* Improvement: Remove legacy code with field sport that does not exist in booking.
* Bugfix: Possibility to use custom user profile field twice for availability condition.
* Bugfix: Fix permission check in search_users web service.
* Bugfix: Selflearningcourse element is introduced in duration class, so move hidelf check for enrolmentstatus to duration class.
* Bugfix: Fix call of get_instance_fields_data (use static function in api).
* Bugfix: Fix reduced forms if elements depend on other non-present elements.
* Bugfix: Make sure reduced forms can be saved even if custom fields are missing.
* Bugfix: Only send reminder mails with correct runtime.
* Bugfix: Fix unit tests bug when timezone switches to daylight saving time (DST).
* Bugfix: Fix bug when 'fieldname' key in recurringoptions is not set.
* Bugfix: Customfield shortnames are not unique.
* Bugfix: Confirm not showing when user is booked.
* Bugfix: fix capability check when no shopping cart is used.
* Bugfix: When a field in a custom form must not be empty we also do not allow blanks.
* Bugfix: add missing booking instance settings on cancellation to the backup.
* Bugfix: Fix timezone bug that saved wrong dates when user had a different timezone than server timezone.
* Bugfix: Do not load any deleted, suspended or unconfirmed users.

## Version 9.1.6 (2026030900)
* New feature: Show custom fields of related person (person affected by event) by adding "-related" to the placeholder, e.g. {myuserprofilefield-related}.
* New feature: New {emailrelated} placeholder to show e-mail of the related user (person affected by event).
* Improvement: Move customfields info array functionality from wunderbyte_table to bookingoptions_wbtable for better code quality.
* Improvement: Allow restriction on specific instances when searching booking options via ajax.
* Improvement: Show actual values of customfields when using includecustomfields with shortcodes.
* Improvement: In booking_option_settings load all customfields using wbt_field_controllers to get actual values.
* Improvement: Improve book cohort feature by improved error message and override via bookanyone capability.
* Improvement: Major improvements for field customfield handling and custom field performance.
* Improvement: Make sure we also add custom fields with empty value to customfieldsfortemplates array.
* Bugfix: Possibility to use custom user profile field twice for availability condition.
* Bugfix: Fix permission check in search_users web service.
* Bugfix: Don't call shoppingcart js when it's not installed.
* Bugfix: Refactor bookit.js to work correctly with buttons with tags.
* Bugfix: Fix formatting (needed for mlang support) of customfields in details view (optionview.php).
* Bugfix: not saving empty formtype in customform.

## Version 9.1.5 (2026030200)
* New feature: Show groupid in option forms and add possibility to recreate groupid if it's wrong.
* Improvement: Do not delete SQL queries cache by campaign reset as it is not necessary.
* Improvement: Append timezone info to displayed time when shown in a different timezone than expected.
* Improvement: Use userdate instead of date to display the correct datetime.
* Improvement: Include the timezone in the cache key when generating and caching datetimes to prevent incorrect display across different time zones.
* Bugfix: Do not delete customfield values on shopping cart checkout for selflearning courses.
* Bugfix: Add German performance strings and change shortcode name dynamically.
* Bugfix: Only display certificate button when certificate config is enabled.
* Bugfix: Add fallback for missing name in price category.
* Bugfix: Apply format string to booking name in teachers list.
* Bugfix: Prevent pollurl from defaulting to 0 on non-pro booking versions.
* Bugfix: Only show previously booked button when records are found.
* Bugfix: Load new values if old ones are not loaded.
* Tests: Use set_config to set the timezone in importer tests to cover timezone information in displayed times.
* Tests: Fix expectations regarding appended timezone information.
* Tests: Create scenario to verify behavior when forcetimezone is set to a specific timezone.
* Tests: Add steps to cover appending timezone abbreviation or city name when user is in a different timezone.
* Tests: Extend unit and Behat tests to verify booking opening and closing times are rendered in the correct timezone.
* Tests: Fix Behat test steps that check the time of a booking option.
* Tests: Extend booking_time_zone_test scenario to verify sessions with same timezone and language use a single cache key.
* Tests: Create Behat and unit tests to verify option dates across different time zones.

## Version 9.1.4 (2026022400)
* Improvement: Better strings for the “selectusers” booking rule condition.
* Improvement: Add new shortcode to allow performance testing of webservices.
* Improvement: Update description for booking time SQL filtering.
* Improvement: Update booking time filter description in German.
* Improvement: Add new setting to restrict booking time SQL condition to future options only.
* Improvement: Allow manageusers table to translate custom field values.
* Improvement: Make Bootstrap 5 ready and improve usability.
* Improvement: Fix failing tests.
* Improvement: Link settings in alert string.
* Improvement: Slim down function implementation.
* Improvement: Rename fields and add warning to mform.
* Improvement: Add logic to freeze fields.
* Improvement: Implement visibility manager.
* Improvement: Add setting and refactor get_class method.
* Improvement: Implement skippable boolean and get_name function for all conditions.
* Improvement: Add German language strings.
* Bugfix: Add missing language strings.
* Bugfix: Do not show confirm button when there is no confirmation workflow.
* Bugfix: Fix spelling mistakes.
* Bugfix: Ensure ignored data on CVS import is handled correctly.
* Bugfix: Fix permission issues.
* Bugfix: Handle empty values in mustache template correctly.
* Bugfix: Fix empty navigation element issue.
* Tests: Add test case for each setting.

## Version 9.1.3 (2026021600)
* New feature: Add new description placeholder.
* Improvement: Check capability of a user anywhere in the system.
* Improvement: Add capabilities check for webservice.
* Improvement: Validate the sessionkey sent in the service.
* Improvement: Add capability check to update notes.
* Improvement: Add more useful help strings to description field settings.
* Improvement: Harden code for new description classes.
* Improvement: {title} placeholder now uses same function as {bookingoptionname} placeholder.
* Improvement: Also use class description_calendarevent in calendar constructor.
* Improvement: New option booking settings for custom description of calendar events.
* Improvement: Replace get_rendered_eventdescription with description_calendarevent.
* Improvement: Apply the user-defined template to description_ical & description_calendarevent.
* Improvement: Read the user-defined template from the custom field configured in the iCal settings.
* Improvement: New description classes for each type of context (ical, calendar event, mail, etc.).
* Improvement: New option in the iCal settings that allows the user to select a custom field as the description field for iCal.
* Improvement: Get rid of unnecessary settings (iCals are sent by rules now).
* Bugfix: Fix call of get_options_filter_sql in create_table_for_one_option in order to fix unit test.
* Bugfix: Make sure we have param4.
* Bugfix: Check capabilities properly.
* Bugfix: Dont declare writing service as read.
* Bugfix: Make sure to require capability for storing performance.
* Bugfix: Make sure to user proper and secure way of fetching Data.
* Bugfix: Don't render sql conditions when we only fetch one single option.
* Bugfix: Make sure invisible options are correctly instantiated.
* Bugfix: Add missing package tags.
* Bugfix: Rename behat to validate.
* Bugfix: Reverted deprecation fix as it is not yet supported by Moodle 4.5.
* Bugfix: Fix warnings and deprecations in unit test.
* Bugfix: Fix unit test and linting.
* Bugfix: Put the descriptions on the same line as their property name in the iCal file, following the PropertyName:PropertyValue rule.
* Bugfix: Set the correct name of option when reading config in description_calendarevent.
* Bugfix: Make sure unit test for ical attachments works also with cancelled icals sent with Booking rules.
* Tests: Improve previously booked test.
* Tests: Fix test by requiring used constant.
* Tests: Check access to invisible but previously booked options.
* Tests: Add unit test for calendar visibility changes.
* Tests: Clear the cache of the placeholder_info class during test initialization, as data from previous tests remains cached.
* Tests: Update the PHPUnit tests to reflect the latest changes.
* Tests: Add test coverage for both description_ical and description_calendarevent classes.
* Tests: Verify that the rendered description matches the expected output in different scenarios.

## Version 9.1.2 (2026021101)
* Improvement: When cache for booking option is purged, also purge entities cache for that option.
* Improvement: Put the interface names in alphabetical order.
* Improvement: completeddate as new column in bookinganswers.
* Improvement: Use user profile values directly instead of using queries.
* Improvement: backup and restore completeddate.
* Improvement: Use profile values only as sql params for security reason.
* Bugfix: Fix availability change check by making sure '[]' is always used as default value.
* Bugfix: Make sure users can instantiate connected options (eg previously booked) even when those are invisible.
* Bugfix: Fix mariadb error regarding the return_sql function.
* Tests: Update the Behat scenario to reflect the roundrefundamount setting.

## Version 9.1.1 (2026020500)
* New feature: Admin sees all options in listtoapprove.
* New feature: Implemented a mode to switch between one or all other options are required for certificate.
* New feature: Add new capability 'seealllisttoapprove'.
* Improvement: Display notes on hover.
* Improvement: Adding note, adding default hash, adding autocomplete.
* Improvement: Measurement points equally distributed, Measurements in run order, Actions enable check.
* Improvement: Add delete measurements for shortcodehash.
* Improvement: Add multiple measurements during one cycle.
* Improvement: Add Table for performance measuring.
* Improvement: Use lines instead of bars.
* Improvement: Move performance class to correct location.
* Improvement: Add capabilities view and edit performance.
* Improvement: Adding actions. Setup pipelines and singletons.
* Improvement: Setup performance dashboard.
* Improvement: Change seealllisttoapprove capability context & define new capability for confirmation.
* Improvement: Let person with seealllisttoapprove to see the answers.
* Improvement: Admin can see all the answers.
* Bugfix: Increase wunderbyte table dependency (for sql injection hotfix).
* Bugfix: Fix wrong parameters for check_for_changes in "easy" fields.
* Bugfix: Fix JS in dynamicoptionform and selectors for Moodle 5.1 (Bootstrap 5).
* Bugfix: Fix check_for_changes function to accept null as key.
* Bugfix: Fix version in upgrade.php after rebase conflicts.
* Tests: Added new testcase.

## Version 9.1.0 (2026013000)
* New feature: Demand more than one option completions for a certificate.
* New feature: Add previously completed functionality.
* Improvement: Better strings.
* Improvement: Possibility to trigger certificate in manage users table.
* Improvement: New certificate_issued event.
* Improvement: Rebase certificate logic into proper class.
* Improvement: New condition to select manager of booking to receive message.
* Improvement: Add more sql conditions.
* Improvement: General linting and codestyle updates.
* Bugfix: Use output buffer to fix failing test because of mtrace.
* Bugfix: Make sure mariadb dialect is correct.
* Bugfix: We need to call mtrace in unit tests too!
* Bugfix: use defined PHPUNIT_TEST instead of PHPUNIT_TEST.
* Bugfix: add missing parameter $nextruntime.
* Bugfix: Event not showing and certificates button triggering certificate although it is not passing checks.
* Bugfix: Suche im Angebot geht nicht.
* Bugfix: Update privacy functions to fix issue.
* Tests: Add new test to make sure mails are sent in relation to courseenddate, also after course has ended.
* Tests: extend shopping_cart_installment_test() to validate messages, sent by rule on installment.
* Tests: Fix tests for event.
* Tests: Extend test of mail.
* Tests: adjust behat Scenario "Booking rules" to support update booking manager and rule on uncompletion event.
* Tests: remove obsolete steps.
* Tests: adjust phpunit scenario on option completion to support uncompletion and update booking manager.
* Tests: new phpunit scenario 'Reminder to manager two hours before booking opening time'.

## Version 9.0.9 (2026012700)
* Improvement: Better handling of confirmation task if status has changed.
* Improvement: supervisorteamreduced can now delete booking answers from users
* Improvement: Templates are sorted alphabetically
* Bugfix: Fallback for bookingrule condition doesn't exist anymore
* Bugfix: String for name of task
* Bugfix: Only issue certificate when setting is on
* Bugfix: Fallback for empty mail message
* Bugfix: template should have unique identifier
* New behat Scenario: Booking option template: create one and use it to create new option
* Tests: phpunit: new class rule_cancellation_test with 4 scenarios

## Version 9.0.8 (2026012000)
* Improvement: Better wording for visibility.
* Improvement: added typefilter to mybookings.
* Improvement: Setting to send messages for invisible options.
* Improvement: Add placeholder optionid.
* Improvement: Add placeholder type to get bo type 0 normal, 1 selflearning.
* Improvement: Missing Placeholders do not send mails.
* Bugfix: Reverted logic for sending messages of invisible option setting.
* Bugfix: Allow external pollurls with placeholders.
* Bugfix: Empty cmid does not lead blocking site.

## Version 9.0.7 (2026011600)
* Improvement: Implement field controllers for customfield placeholders to support more field types (e.g. multiselect dynamic dropdown).
* Improvement: Optionstoconfirm reduced now show coursestarttime
* Improvement: Add checklist setting
* Improvement: Properly url encode everything
* Bugfix: Remove can_issue check as it fails when called from observer.
* Bugfix: Make sure optionstoconfirmreduced still work
* Bugfix: fureonly not working
* Bugfix: Correctly check for invisible options
* Bugfix: Fix pollurl collapsible for Bootstrap 5 and improve usability.
* Bugfix: With previouslybooked condition, if option isn't found block
* Bugfix: Correctly check for selflearningcourse in answers
* Bugfix: Make double sure that we could actually assign competency on completion

## Version 9.0.6 (2026011400)
* Bugfix: Make double sure that we could actually assign competency on completion
* Bugfix: Correctly check for selflearningcourse in answers
* Bugfix: With previouslybooked condition, if option isn't found block

## Version 9.0.5 (2026010900)
* Improvement: Don't wrap selflearningcourse information in placeholder in paragraph.
* Improvement: For better usability, we hide the message button on teacher page if messaging is impossible.
* Improvement: Backup shopping cart iteminfo if it exists.
* Bugfix: Fixed default booking image fallback to use the captured default image record instead of the last iterated image.
* Bugfix: Make sure rules are not executed for self-learning courses if the rule depends on option date(s).
* Bugfix: Make sure no icals are sent for selflearningcourses.
* Bugfix: Fix e-mails for self-learning courses.
* Bugfix: Fix layout for teacher page (should be full width in boost).
* Bugfix: Fix missing fields in backup stepslib for booking instance.

## Version 9.0.4 (2026010700)
* New feature: Introduce new booking option type and replace selflearningcourse flag from JSON.
* New feature: New booking rule for a specific time before or after a chosen date field.
* New feature: Scheduled emails page for debugging mode.
* Improvement: Separate booking event for moving up from the waiting list.
* Improvement: Get entity ID more efficiently.
* Improvement: Load image URL more efficiently.
* Improvement: Add placeholders to pollurl and pollurlteachers.
* Improvement: Use capital letters for labels of German words.
* Improvement: Define new identifier for actions on booking answer.
* Improvement: Set title and aria-label for action buttons.
* Improvement: Update actions column by adding text to buttons and increasing spacing.
* Improvement: Change column title of actions button.
* Improvement: Add search and filter functionality on my bookings page.
* Improvement: My certificates page now shows linked course.
* Improvement: Make mobile list more robust.
* Improvement: Cache custom fields.
* Improvement: Refactor options-to-confirm scope.
* Improvement: Set localized language strings.
* Bugfix: Fix image matching for arrays.
* Bugfix: Fix broken Behat by reverting SQL and using booking_handler for get_value.
* Bugfix: Remove unnecessary variable.
* Bugfix: Fix non-deterministic ordering for tied timemodified values causing waiting-list selection to vary.
* Bugfix: Do not assume that the last element in an array is the one needed.
* Bugfix: Missing string error.
* Bugfix: Custom fields of type textformat are supported for certificate creation.
* Bugfix: Invalidate event log table cache after message was sent.
* Bugfix: Fix error where cache definition requires simple keys.
* Bugfix: Unset mobile active tab.
* Bugfix: Fix wrong display of PRO license status.
* Bugfix: Adhoc task failed due to missing cache_helper class.
* Bugfix: Set correct string values for cached scheduled mails cache.
* Tests: Verify booking rules on specific time for self-learning course.
* Tests: Verify booking rules on specific time.
* Tests: Test booking answer moved up from waiting list event with rules.
* Tests: Modify expected values in Behat test due to refund value changes.
* Tests: Manually confirm users after confirm_bookinganswer_by_rule adhoc task.
* Tests: Modify expected values for user credits.
* Tests: New PHPUnit test for refund value with different cancellation fees.
* Tests: Reset static variables in PHPUnit tests.
* Tests: Create methods to reset instances of static variables.

## Version 9.0.3 (2025121200)
* Bugfix: Don't send mails when CMID of option has changed.
* Bugfix: Missing format_strings for booking rules.
* Bugfix: Fix reliability bugs reported by Sonarqube with high severity.

## Version 9.0.2 (2025121100)
* Bugfix: Fix bugs in Bookings tracker.

## Version 9.0.1 (2025121000)
* New feature: Create shortcode for altering a wb_table column.
* New feature: Add new 'includecustomfields' argument for shortcodes.
* New feature: Allow selecting the responsible contact as receiver of mails from rules.
* Improvement: Available places as a new class under filters directory.
* Improvement: Use available places filter.
* Improvement: Display the target user's name on the booking button.
* Improvement: Use format_text in customform condition to support HTML.
* Improvement: Better strings for course calendar.
* Improvement: Make functions accessible.
* Improvement: Add infinite scrolling to shortcodes in mod_booking.
* Improvement: Improve SQL performance.
* Improvement: Possibility to select responsible contact as mail receiver in rules.
* Bugfix: Avoid change of sorting order on booking a booking option.
* Bugfix: Check if class exists before checking for cashier capability.
* Bugfix: Bugfix: Preserve id of exisisting optiondate in addoptiondateseries.
* Bugfix: Bugfix: Compare optiondateids to check if rule still applies.
* Bugfix: Correctly set new booking description param.
* Bugfix: Correctly set progress via shortcodeparam progress.
* Bugfix: Call get_cart_items after modal close to load cashier items correctly.
* Bugfix: Ensure MySQL LATERAL queries work on MariaDB <10.6.
* Bugfix: Fix 'bo.responsiblecontact' unknown column issue.
* Bugfix: Fix concatenation operator issue in MySQL.
* Bugfix: Remove unused clean_string() to avoid redeclaration fatal error.
* Bugfix: Revert incorrect userid and relateduser handling in message event table.
* Bugfix: Get correct user's answer in alreadybooked.
* Bugfix: Send real buyforuserid in initFooterButtons payload.
* Bugfix: Fix calendar string in Behat tests.
* Bugfix: Fix linting issues.
* Tests: Set optiondateid to trigger correct behaviour.
* Tests: Make sure changing entity of an options doesn't trigger new task.
* Tests: Add PHPUnit test for sorting in infinite scrolling.
* Tests: Add PHPUnit test to cover available places filter.
* Tests: Extend tests to accept multiple shortcodes.
* Tests: Count booked and reserved answers to calculate available places.
* Tests: Add PHPUnit test test_rule_on_email_responsiblecontact_on_booking().
* Tests: Add scenario to verify correct items returned on second page with available places filter applied.

## Version 9.0.0 (2025120101)
* Improvement: Now supporting Moodle 4.5+ (skipped support for Moodle 4.1 - 4.4).

## Version 8.19.0 (2025120100)
* New feature: Introduce new rule template for adding/removing teachers for option dates.
* New feature: Add support for selecting custom fields as sortable/filterable fields in wunderbyte_table.
* New feature: Booking confirmation requirement for waitinglist bookings.
* New feature: Use book for user functionality in assignments in taskflow.
* New feature: Add capability to check user-defined optional parameters in booking/cart flow.
* Improvement: Execute new rules only on save to avoid unnecessary rule runs.
* Improvement: Add helper functions to execute rules at the correct runtime.
* Improvement: Add new rule update session reminders.
* Improvement: Add condition tests and improvements for waitinglist confirmation logic.
* Improvement: Add "previously booked" indicator to report pages.
* Improvement: Use customfieldfilter class when adding custom field filters in shortcodes.
* Improvement: Optimize booking options SQL (remove DISTINCT, improve filter logic).
* Improvement: Better handling of user ID injection in shortcodes and booking tables.
* Improvement: Ensure correct booking answer ID is selected in option confirmation.
* Improvement: Improve booking pages (better display, course start time formatting, etc.).
* Improvement: Add support for restoring duration and course restraints in option templates.
* Improvement: Improve behavior of get_options_filter_sql in wunderbyte_table.
* Improvement: Ensure sortable fields are selected only when required.
* Improvement: Show count label in reports only when explicitly enabled.
* Improvement: Improve shopping cart history retrieval.
* Improvement: Multiple refinements to customfieldfilter logic for booking options.
* Improvement: Filter added to get_render_all_options_table (implementations 1 & 2).
* Improvement: Support teachersforoptiondate_xx in generator functions.
* Bugfix: Fix missing pagination for cards view.
* Bugfix: Prevent using the same instance name during pagination on cashier page.
* Bugfix: Fix duplicate code errors in multiple test cases.
* Bugfix: Restore deleting course restraints and duration in booking option templates.
* Bugfix: Correct field type conversion in templates.
* Bugfix: Ensure fallback to $USER when table->forceruserid is missing.
* Bugfix: Fix restoring selected filters and sortable fields in wunderbyte_table.
* Bugfix: Fix wrong confirmation count needed to book.
* Bugfix: Prevent too many confirmation checks for waitinglist scenarios.
* Bugfix: Fix multiple Behat tests failing due to waitinglist or confirmation logic changes.
* Bugfix: Ensure correct bookingoptions_wbtable instance references inside shortcodes.
* Bugfix: Fix missing user ID retrieval in URL shortcodes.
* Bugfix: Fix ordering/sorting of custom fields.
* Bugfix: Correct behaviour when user is deleted—preserve previously booked entries.
* Bugfix: Fix import/export for duration and custom field values.
* Tests: New PHPUnit test for rules_template_on_optiondates_teacher_delete and teacher_added.
* Tests: Add Behat tests for booking confirmation and waitinglist logic.
* Tests: Add tests for restored custom fields in backup/restore process.
* Tests: Test user-injected options for available places filter.
* Tests: Test booking options using customfields in multiple scenarios.
* Tests: Add test scenarios for max answers and maxperuser waitinglist conditions.
* Tests: Fix failing tests for customfield existence checks.
* Tests: Add tests for session reminders rule.

## Version 8.18.4 (2025111802)
* Improvement: Add format_string to titleprefix, title (text) and institution.
* Improvement: Also apply format_string (needed for multi-lang filters) to customform condition.

## Version 8.18.3 (2025111801)
* Bugfix: Fallback for missing componentname key in event observer.
* Bugfix: Correctly check for similar tasks.

## Version 8.18.2 (2025111800)
* Improvement: Make past options available via shortcode (all=past)
* Improvement: Possibility to create new linked course in current category
* Bugfix: Limit get_record in booking_answers table to make sure it's unique
* Bugfix: Book the option immediately after confirming an answer when the option has a price but the user’s price is zero.
* Bugfix: Fix signinsheet top download button and default orientation (in instance settings).
* Bugfix: daystonotify can now be changed on update
* Bugfix: Fix SQL error of condition select user in shopping cart.
* Bugfix: Get rid of OpenTBS, TinyButStrong and legacy custom report templates
* Bugfix: Drop legacy table booking_customreport and field customtemplateid.

## Version 8.18.1 (2025111001)
* Improvement: Create test for session reminders via rules.
* Improvement: Delete booking answers cache for option after successful checkout.
* Improvement: Supervisorteamreduced only shows booked users.
* Improvement: Mycourseslist now supports "futureonly" param.
* Improvement: Enable import of competencies (value in string format).
* Improvement: Add debug event when option can't be created.
* Bugfix: For updated sessions send mail only once.
* Bugfix: Removed extra AND from the query.
* Bugfix: Limit get_record in booking_answers table to make sure it's unique.
* Bugfix: Book the option with a price for a student whose price category is 0.
* Bugfix: Futureonly triggered on the right point.
* Bugfix: Only schedule mail task for active users.
* Bugfix: Append certificate to bookingoption_booked event to enable correct placeholder.
* Bugfix: Wrong scope in supervisorteam shortcode.
* Bugfix: Add reduced property.
* Bugfix: Add missing variable counter.
* Bugfix: Fix reduced region in booking_answers table to make sure it's unique.

## Version 8.18.0 (2025110300)
* Improvement: New helper function in shortcodes handler to check if arguments are really true.
* Improvement: Default for uselegacymailtemplates setting should be turned off.
* Improvement: Correct strings for signinsheethtml description.
* Improvement: Purge or invalidate affected caches when booking answers or options are cancelled.
* Improvement: Reduced versions of optiontoconfirm and supervisorteam with the possibility to include customfields.
* Improvement: Store pricecategory in bookinganswer field and add tests.
* Improvement: New column pricecategory in booking_answers table.
* Improvement: Add test for creation of date series.
* Bugfix: Fix selector for download signinsheet shortcut button.
* Bugfix: Execute booking rule on cancel purchase shoppingcart.
* Bugfix: Signature in wrong function.
* Bugfix: Fallback for invisible change tracking.
* Bugfix: Certificate files are now created as files when issued.
* Bugfix: CSV import loses cmid when done twice in a row.
* Bugfix: Duplicate option without course correctly.
* Bugfix: Stop sending scheduled mails on rule change based on event.
* Bugfix: Only delete files if they exist.

## Version 8.17.8 (2025101600)
* Improvement: Test conditions of rule
* Improvement: More precise message for freetobookagain description
* Improvement: Better tracking of history status update un/confirmation via task
* Improvement: track changes for easy fields
* Improvement: Store changes in availability json in bookingoption_updated event
* Bugfix: Background color for booking button under Moodle 5
* Bugfix: Don't throw error on deselecting a template
* Bugfix: Correctly resolve "&" in subject of message provider
* Bugfix: Trigger waitingforconfirmation event correctly
* Bugfix: Confirmation entry in booking history contains userid

## Version 8.17.7 (2025101400)
* Improvement: Handle ICS attachment errors with try-catch and trigger booking debug event
* Improvement: Check the 'noemailever' global config when sending mails via PHPMailer for iCal emailing.
* Improvement: Check number of option dates and prevent use ical as inline data when grater than one.
* Bugfix: Don't block with waitinglist when waitinglist is unlimited
* Bugfix: show "unlimited" waitinglist for downloads as well
* Bugfix: select proper waitinglistplacesinfotext in case of unlimited waitinglist
* Bugfix: Optiontemplatesettings should not be sortable
* Bugfix: Reorganize order of execution in the completion chain
* Bugfix: supsended users are now ignored for mailings
* Bugfix: Correctly find context in user selector
* Bugfix: Fixed ical to send messages via PHPMailer
* Bugfix: Check if ICS file already exists and delete it before creation to prevent duplication errors.
* Bugfix: Add missing strings of capabilities
* Bugfix: Send mail to users from bookingoption_cancelled event
* Linting: Apply Moodle Standard Updates
* Tests: extend behat test for the .../admin/roles/define.php?action=edit&roleid=3 (teacher) to check missing strings in capabilities

## Version 8.17.6 (2025100700)
* New feature: Condition for rules to select deputies of supervisor (nested profile field logic) #1149
* Improvement: Display mail in sign-in sheet
* Improvement: Add bookingoptionimage to bulkoperations
* Improvement: Don't use static acceleration for bookingoptionsanswers cache
* Improvement: Add Ajax loading to shared places for speedup
* Improvement: Add Ajax loading to previously booked for speedup
* Bugfix: Don't delete previously booked records when deleting a user response
* Bugfix: treat both id and optionid identificators in case of new option
* Bugfix: Catch error when we can't delete stored file
* Bugfix: Correctly block booking with unlimited waitinglist
* Bugfix: Resolved query search in 'optionstoconfirm' search.
* Bugfix: Add timebooked col correctly to answers table
* Tests: phpunit: add waitinglist with maxperuser scenarios (#1145)

## Version 8.17.5 (2025100100)
* Improvement: Duplicate bookingoptions not a pro setting #1136
* Improvement: Improve strings for waitforconfirmation select
* Improvement: Accessibility: Remove role="alert" from bookit button
* Bugfix: Display names according to full class name
* Bugfix: Never put reserved on waitinglist instead of usersonlist
* Bugfix: Pass on param to only execute parts of sync waitinglist when we are updating option
* Bugfix: Add capability check when executing sync waitinglist with delete
* Bugfix: Add another check of existing setting keepusersbookedonreducingmaxanswers
* Bugfix: Default value of 'keepusersbookedonreducingmaxanswers' is on
* Bugfix: Execute booking rule on cancel purchase shoppingcart
* Tests: New behat Scenario: Booking option: cashier use list generated by shortcode to brough option for user

## Version 8.17.4 (2025092300)
* New Feature: Allow Multiple bookings
* New Feature: Show team bookings for supervisor (supervisorteam shortcode)
* New Feature: New hascompetency condition.
* Improvement: Add deputies via select modal
* Improvement: Add special string for waiting for confirmation
* Improvement: Confirm users on waitinglist and sync them only when allowed
* Improvement: Possibility to exclude booknow button in shortcodes
* Improvement: Allow for old bookings to be completed and issue certificates
* Improvment: Add argument statuswaitinglist to mycourselist shortcode to also show waitinglist options
* Improvement: Make the labels of the tables in booked_users.mustache dynamic.
* Improvement: New capability for importoptions
* Improvement: Setting to set toggle always to book anyone
* Improvement: Apply competency via task, if no moodle/competency:competencygrade capability
* Bugfix: Correctly apply old date for old certificates
* Bugfix: course completed observer has now an unique column
* Bugfix: Add booknow everywhere we need it
* Bugfix: Set timebooked to 0 where it is not set.
* Bugfix: Fix time comparison condition.
* Bugfix: fix vulnerabilities vue for display in dashboard
* Bugfix: Enable edit_rules on context sys for users with capability
* Bugfix: Correct description for duplicatebookingoptions
* Test: Created new test for coursecompletion triggers bookingoptioncompletion

## Version 8.17.3 (2025091901)
* Improvement: Introduce Bootstrap 5 and make adjustments to prepare for Moodle 5 version.
* Improvement: Fixes for ical (*.ics) files.

## Version 8.17.2 (2025091900)
* Bugfix: Don't use singleton pattern on bookforuser function.

## Version 8.17.1 (2025091800)
* Improvement: Check capability for recalculateprices.
* Improvement: Add contains-partially-option for circumvent condition.
* Tests: Improve and fix some phpunit and behat tests.

## Version 8.17.0 (2025091700)
* Feature: New hascompetency condition.
* Improvement: Restore singleton after purging cache.
* Improvement: Fixes for ical (*.ics) files.
* Performance: Invalidate cache on clicking on bookit.
* Performance: Better use of singleton patterns.
* Performance: Avoid unnecessary DB call.
* Performance: Don't render descriptions we don't need.
* Bugfix: In unsubscribe.php we need to purge answers cache, not options cache!
* Bugfix: Fix bug in selection of template courses.
* Bugfix: Fixed skipping of Booking Rules.
* Bugfix: Correct status for subbooking.
* Bugfix: Responsible contacts - Mustache does not like associative arrays, so we make sure, we have array values only.
* Bugfix: Fix exception when creating date series with empty text area.
* Bugfix: Course completed observer has now a unique column.
* Bugfix: Small typo completion.
* Bugfix: Added missing language string.
* Bugfix: Remove unnecessary PAGE context fix.
* Bugfix: Fix unit tests, linting and improve code quality.
* Bugfix: Subbookings create shortterm reservations in booking answers.
* Bugfix: Don't set idnumber of targetcourse (fixes indumbertaken error).
* Tests: Final fix for condition_hascompetency_test - enrol users as students to course.
* Tests: Add PHPUnit tests for ICS calendar generation in mod_booking.
* Tests: Check if message is sent on book event.

## Version 8.16.2 (2025091000)
* Feature: Added coursestarttime to shortcodes.
* Improvement: Add filteronloadaction param to shortcode allbookingoptions.
* Improvement: Better performance when showing description in table.
* Improvement: Better Javascript performance.
* Improvement: Delete unnecessary key confirmationnotificationoneatatime.
* Improvement: Fix description for bookingextension.
* Improvement: Increase the static acceleration size for better performance.
* Improvement: Better performance during availability checks.
* Improvement: Return image URL in bookings webservice.
* Improvement: Possibility to only show completed courses in mybookings.
* Improvement: New setting to show first teacher as responsible contact on teachers page.
* Improvement: Make links configurable in bookingtracker_helper for column text in manageusers_table.
* Improvement: Performance improvement for when there are many sessions – check output before production.
* Bugfix: Possible behat fix – wait until booking history is loaded.
* Bugfix: Replace report2option link with optionlink for col_text.
* Bugfix: Missing isset checks for change array.
* Bugfix: Cast to float for format_float.
* Bugfix: Fix campaign string.
* Bugfix: No format_float in apply_campaigns.
* Bugfix: Prepage modals work again normally with performance improved JS.
* Bugfix: Make sure we look for the bookingmanager only once per cache cycle.
* Bugfix: Fix image URL creation.
* Bugfix: Fix for case if $values->scope is not set or empty.
* Bugfix: Correctly use allowedtobookinstance singleton.
* Bugfix: Fix PHP 7.4 compatibility.
* Bugfix: Fix behat (invisible characters).
* Bugfix: Fix PHPUnit (invisible characters).
* Bugfix: Fix for the case if $boinfo['iamreserved'] is empty.
* Bugfix: Make sure to add subbooking persons to the right user answer.
* Bugfix: Validation for subbooking places.
* Bugfix: Don't proceed with sending mail if no user was found.
* Bugfix: Small fix for shopping cart errors display.
* Bugfix: No line break between price and currency.

## Version 8.16.1 (2025090401)
* Improvement: Better info string for enrol multiple users.
* Improvement: Localize prices with format_float.
* Improvement: Add possibility to add userid for mybookings.
* Improvement: Let any user with the 'bookbrothers' capability confirm booking answers.
* Improvement: Add warning when I have a deputy active.
* Improvement: Add assertions to check that approvers’ view of the table contains only allowed records.
* Improvement: Ensure an approver’s replacement cannot confirm if main approver is not allowed.
* Improvement: Add course:view and course:update capabilities to determine trainer and prevent bypassing supervisor when confirmation_supervisor is off.
* Improvement: Add deputy to confirmation_test.
* Improvement: Skip test_confirmation_supervisor when confirmation_supervisor plugin is not available.
* Improvement: Use course ID from booking settings instead of booking option settings instance.
* Bugfix: Moodle 5 not yet supported on Branch MOODLE_401_DEV.
* Bugfix: Pass user ID as integer.
* Bugfix: Use course ID from booking settings instance instead of booking option settings instance.
* Feature: New PHPUnit test to cover confirmation trainer & confirmation supervisor.
* Feature: New property in booking used class key to be exposed in confirm.
* Test: Add new unit test for confirmation trainer & confirmation supervisor.

## Version 8.16.0 (2025090200)
* Improvement: Add support for time awarded for certificate.
* Improvement: Reorder buttons for improved UX.
* Improvement: Improve scope logic for bookings tracker and fix download problems.
* Improvement: Separate activitycompletion and optioncompletion; add timebooked key on import.
* Improvement: Refactor scope handling for better maintainability.
* Improvement: bookingoptioncustomfields are now usable in certificates.
* Improvement: Add list to approve shortcode.
* Improvement: Add Booking Extensions in Git.
* Improvement: Restrict optionstoconfirm to users with capability in booking instance.
* Improvement: Add filteronloadactive argument to courselist shortcode.
* Improvement: Add new helper function to check if cmid belongs to booking instance.
* Improvement: Add new function return_last_completion to booking_answers.
* Improvement: Add new booking_answers function to retrieve all completed answers.
* Bugfix: Deal with empty competencies in booking options.
* Bugfix: Fix in col_availableplaces class that broke [allbookingoptions] shortcode.
* Bugfix: Fix booking option enrolllink creation to match updated proceeding logic.
* Bugfix: Revert deleted lines to fix PHPUnit tests.
* Bugfix: Use proper debugging in booking_delete_instance to avoid false returns.
* Bugfix: Ignore bookingextension changes for duplicated/recurring options.
* Bugfix: Don't include templates in allbookingoptions shortcode.
* Bugfix: Certificate now triggers correctly on course completion.
* Bugfix: Handle error when accessing usersonlist in booking_answers.
* Update: Allow for higher confirmation count than necessary to be allowed to book.
* Update: Convert confirmwaitinglist_modifieduserid and _timemodified to array. #1057
* Update: Add new event bookinganswer_denied. #1057
* Update: Add logic to handle confirmation with confirmation supervisor plugin. #1057
* Update: Add plugin setting to control visibility of confirmation enable checkbox. #1057
* Refactor: booking_answers class (#1069).
* Feature: Certificates can now use bookingoptioncustomfields.
* Feature: Add temporary settings array for shortcodes in certificates.
* Test: Add new test for booking_answer class (#1069).

## Version 8.15.3 (2025082000)
* Feature: New setting to hide Booking Rules section in booking option edit form.
* Improvement: Better strings for activity completion.
* Improvement: Improvements for feature to show free instead of booked places.
* Bugfix: Fix activity completion and make it less confusing.
* Bugfix: Make sure price modifier for custom form also works without pricecategories set.
* Accessibility: Role "alert" on button.

## Version 8.15.2 (2025081200)
* Feature: Added possibility to replace booking option description
with the value of a defined booking option customfield.
* Improvement: If no signinsheethtml is provided, use default HTML template.
* Bugfix: Fix bugs for new changedescriptionfield setting.
* Bugfix: Fix broken activity completion #1095.
* Bugfix: Hardcode suffix "_booking" as get_suffix() is only supported from Moodle 4.3 onwards.

## Version 8.15.1 (2025080500)
* Improvement: Support up to 50 form elements in custom form condition.
* Bugfix: Checks if bookingextension classes exist.

## Version 8.15.0 (2025080400)
* New feature: New fields from booking option in Booking certificate feature.
* New feature: Booking now supports multiple dayofweektime strings to create date series for multiple weekdays.
* New feature: Add button to switch HTML/legacy view for new sign-in sheet (which now supports MS word export).
* Improvement: Better display of shopping cart bookings on mybookings.php.
* Improvement: New capability for managers to execute bulk operations.
* Improvement: Possibility to hide warning about rules.
* Improvement: Show booked places in common list.
* Improvement: Add possibility to export course shortname in options download.
* Improvement: Show warning when all teachers page is reduced and add a link to setting (only for admins and managers).
* Improvement: Show hint on how to use multiple dayofweektime strings for better usability.
* Improvement: Refactor and fix pro version logic.
* Bugfix: Don’t block price for subbookings with priceisalwayson setting.
* Bugfix: Responsible contact not existing anymore.
* Bugfix: Fallback for responsible user not existing anymore.
* Bugfix: Improve logic to also sync waiting list when only users on shared options are present.
* Bugfix: Fix SQL for MariaDB.

## Version 8.14.13 (20250730)
* New Feature: Confirm user only for waitinglist (#1050).
* New Feature: Enable multiple responsible contacts ()
* New Feature: Booking rule condition to select recieving users from profile field
* Bugfix: Correctly fetch price for multiple users in report.
* Bugfix: Remove HTML of menu items as it causes problems in aria-labels.
* Bugfix: Track changes in Entities, Competencies & Certificates

## Version 8.14.12 (2025072402)
* Improvement: Allow courseid in allbookings shortcode to fetch all options from instances in moodle course (#1080).
* Bugfix: Fetch price for multiple users in report.
* Bugfix: Possible bugfix for bookingoption_freetobookagain not being sent when maxanswers is increased.
* Bugfix: Fix sync waiting list and only sync if json setting useprice is turned off (#1073).
* Bugfix: Set cmid correctly in class booking_option.
* Bugfix: Fix for #1073 (check for json setting useprice at all checks for price).
* Bugfix: Fix logic for multiple responsible contacts.
* Bugfix: Fix broken setting to allow responsible contacts editing of booking options.
* Bugfix: Fix broken gear menu (dropdown menu) caused by add_options_to_col_actions.

## Version 8.14.11 (2025072100)
* Improvement: Possibility to select multiple users as responsible contact.
* Improvement: Possibility to display shoppingcarthistory in mybookings.php
* Improvement: add coursestarttime and courseendtime to optionimporter
* Improvement: Add anchor to link for selflearningcourse setting.
* Improvement: Better strings for enrolment checkbox options
* Bugfix: invalidate cache of customformcondition of option when item is put into cart
* Bugfix: Define cache for mycourselist (mybookings.php)
* Bugfix: Make sure we only return rules for existing booking instances.
* Bugfix: Use inline-block instead of inline for table list row
* Bugfix: Correctly display error message of enrollink

## Version 8.14.10 (2025071100)
* Improvement: Show warning when creating forbidden shortnames for customfields.
* Improvement: Choice of mulitple displays of free places
* Bugfix: Selflearningcourse inscription always starts with timecreated
* Bugfix: Correct sync waitinglist trigger

## Version 8.14.9 (2025070800)
* Improvement: Provide settings about display of selflearning courses in shortcode
* Improvement: Support customfield multiselect with multiple values
* Improvement: On competency attribution, also trigger corresponding event.
* Improvement: Add book for user logic
* Bugfix: Selected users availability not deleted properly
* Bugfix: Don't count deleted users in bookinganswers object
* Bugfix: Add missing presence status to fields and columns sections.
* Bugfix: Fix parenthesis typo which destroyed logic for multiselect.
* Bugfix: Integer grade_competency() expected
* Bugfix: Prevent empty teacherid
* Bugfix: prevent Error from empty PluginSettings
* Bugfix: Fixed incorrect booking location information is displayed.
* Bugfix: Fix delete competencies
* Tests: New behat "Booking settings: control presence of strings on all settings pages"

## Version 8.14.8 (2025062400)
* New feature: Possibility to easily integrate subplugins.
* New feature: New setting to hide specific booking instances from teacher pages and improved sorting.
* New feature: Show extra info (entity, custom fields, comments) of option dates in list of booking options.
* New feature: Teacher selector can now be reduced by profile field value.
* Improvement: Messages of bookingoption can only be view by users with viewreports permission
* Improvement: New default - stopp applying rule one day after end of bookingoption
* Improvement: Messages of bookingoption can only be view by users with viewreports permission
* Improvement: Finally fix mybookings
* Improvement: Trim value of user profile field.
* Bugfix: optionfield config
* Bugfix: user profile field pref fallback

## Version 8.14.7 (2025061201)
* Bugfix: Renamed setting to enable certificates to certificateon.

## Version 8.14.6 (2025061200)
* New feature: Create and issue certificates when booking option is completed.
* Bugfix: Don't throw an error when the teacherid is no valid user.
* Bugfix: When joining images, we need INNER JOINS for course_modules, modules and context to avoid duplicate rows.
* Bugfix: No error when there are no competencies.
* Bugfix: Fix SQL for joined images so it won't break option templates.

## Version 8.14.5 (2025061000)
* Improvement: Disable booking for user if others are on waitinglist.
* Bugfix: Fix enrolment confirmation.
* Tests: Fix behat Scenario. Booking option: Waiting list with prices when waitinglistshowplaceonwaitinglist is not set.

## Version 8.14.4 (2025060600)
* New Feature: courselist shortcode now supports cards view (type=cards).
* New Feature: Restore reserved items to the cart of the user
* New Feature: Add new availability condition which checks booking instance access restriction availabiltiy.
* New Feature: Assign competency evidence to user.
* New Feature: Competencies can be assigned to and viewed by users.
* New Feature: Filter for regular columns in shortcodes.
* Improvement: Also add format_string to values in report.php to support mlang filters.
* Improvement: Better description for shortcodes passwords.
* Improvement: Adjustments for sync_waiting_list().
* Improvement: Apply instanceavailability condition only if setting is activated.
* Improvement: Show error message to admins when shortcode fails and debug mode is on.
* Improvement: Improve user evidence event.
* Improvement: Add button to option view and trigger filter for competencies.
* Improvement: Reload entire table container to make sure filter checkboxes are checked correctly.
* Improvement: Add columnfilter to shortcode and enable display of similar options in optionview
* Bugfix: Add format_string to customfield headers when booking answers of report.php are downloaded.
* Bugfix: Bugfix: Fix CSV export of Bookings tracker.
* Bugfix: Deleted users were shown as booked in some cases.
* Bugfix: Allow override also when shopping cart is not installed
* Bugfix: If price is always on or we want to display empty prices, we show '0' as price value even if it's missing.
* Bugfix: Correct behaviour without shopping cart installed and adapt corresponding test.
* Bugfix: Avoid error when json column of booking option is NULL.
* Tests: Add unit test for new instanceavailability condition.

## Version 8.14.3 (2025052700)
* Improvement: Add time() to strtotime to make it overrideable in tests
* Improvement: Harden security of shortcodes
* Improvement: Add explanation how to change order of customfields on detail page
* Bugfix: Add tearDown and setUp functions to all tests
* Bugfix: Wrong context in optionformconfig_info
* Bugfix: Fix working of n days test
* Bugfix: Assure compatibility with mariadb
* Bugfix: JSON_TABLE is only supported starting from MariaDB 10.6 and MySQL 8.
* Bugfix: JSON_TABLE is only supported starting from MariaDB 10.6 and MySQL 8
* Test: Improve tests mocking time

## Version 8.14.2 (2025052300)
* Improvement: Move pricecategories to dynamic form with repeat elements
* Bugfix: Add missing error catching on wrong cmid.
* Bugfix: Don't create a new group when we already have an id
* BugFix: send_mail_interval waitinglist order and add tests
* Bugfix: Don't send reminder messages for cancelled booking options
* Bugfix: Fix strings of privacy providers (must not include underscores)

## Version 8.14.1 (2025052100)
* Bugfix: In Bookings tracker show unlimited instead of 0.
* Bugfix: Fix errors with price categories.

## Version 8.14.0 (2025052000)
* New feature: Curriculum profile field conditions via URL params.
* New feature: Add documentation and preferences for curriculum conditions and tests.
* Improvement: Add rowcountselect to bookinghistory.
* Improvement: Implemented mycourselist shortcode.
* Improvement: Refactored booking module.
* Improvement: Link in curriculum contains & equals conditions of userfield.
* Improvement: Override user field linked to booking instance.
* Improvement: Add default to mod_form.
* Improvement: Usability – show download button at correct place.
* Improvement: Specific string for teacherdescription in modal.
* Improvement: Refactor booking option with multiple customized settings.
* Improvement: Reuse ERPNext task workflow.
* Bugfix: Try/catch for list of saved rules.
* Bugfix: Fix requirelogin for courselist shortcode (and fix image context issues).
* Bugfix: Don't check changes in fields timecreated and timemodified.
* Bugfix: Fix SQL for joined image files.
* Bugfix: Fix phpunit issue "option has started".
* Bugfix: Revert delays for `booking_manage_waiting_list` and fix screen size for `booking_maxoptionforcategory`.
* Test: Many performance and editor fallback fixes.
* Test: Support for duplication, multi-session bookings, and refactoring.
* Test: Moodle 5.0 preparations and optimizations.
* Test: Minor fixes in booking price formula and subbooking features.
* Test: Improve handling of booking editor and tab views.

## Version 8.13.0 (2025051300)
* Bugfix: Rename rank to userrank because rank is a reserved function of MySQL.

## Version 8.12.9 (2025051200)
* New Feature: Competencies of booking options
* New feature: Booking rules now support session reminders
* Improvement: Usability improvements for bookings tracker
* Improvement: Got rid of enablepresence instance setting
* Improvement: booking time not overwritten by billboard
* Bugfix: enable maxoptionsforcategory with all types of customfields
* Bugfix: Fix requirelogin for courselist shortcode (and all other shortcodes too).
* Bugfix: Increase number of booked users on report.php
* Bugfix: Fix SQL for rank order of answers in waiting list so it'll work with any DB family (also MySQL).
* Bugfix: No validation for enrollink with empty course
* Bugfix: Fix rank order for setting waitinglistshowplaceonwaitinglist
* Bugfix: Catch non existing cmid error in shortcodes
* Bugfix: Move setting waitinglistshowplaceonwaitinglist to correct place (under waiting list header)
* Bugfix: Fix missing optiondateid in SQL which led to dates being duplicated
* Bugfix: Fix uniqueid for student
* Bugfix: Fix daystonotify override for session reminder rule
* Bugfix: Fix check_if_rule_still_applies
* Bugfix: Enable sorting for supplementary columns (customfields) in shortcodes
* Bugfix: remove unsubscribe button in mobile output
* Bugfix: missing tab in active nav tabs

## Version 8.12.8 (2025050100)
* New Feature: Create certificates for completing booking options. Also view and edit certificates in report and placeholders for rules.
* Improvement: Added new shortcodes allbookingoption and mybookingoptions.
* Improvement: Added bookotheroptions action.
* Improvement: Further improvements to the bookings tracker.
* Bugfix: Booking rules are now deleted correctly.
* Bugfix: Show error message in business card if the user ID of the organizer is missing.
* Bugfix: Removed default sorting by lastname, as it disrupted the rank order of the waiting list.
* Bugfix: Recurring booking opening and closing times now update correctly.
* Bugfix: Enabled setting unenrolfromgroupofcurrentcourse.
* Bugfix: Correct order of params of setting uselegacymails.
* Test: Added unit tests for shortcodes.
* Test: Added new Behat scenario: Booking actions – create settings for booking action via UI as a teacher and edit it.
* Test: Added new Behat scenario: Booking actions – create booking action via DB and book it as students.

## Version 8.12.7 (2025042400)
* New Feature: Link to optiondetails next to booked/cancelled alert for bookondetail
* Bugfix: Fix course sortorder after course creation via template
* Tests: refactoring of the backup_restore_test()

## Version 8.12.6 (2025042300)
* Improvement: for booking history and bookings tracker.
* Improvement: Implemented unsubscribe to moodle mobile
* Improvement: Add bookotheroptions action and condition to check if options are available.
* Improvement: Refactoring shortcodes.
* Bugfix: Do not hide columns via CSS but add them to sorting correctly, usability improvements
* Bugfix: No default sorting by lastname, as it destroys rank order of waiting list.
* Bugfix: Update recurring bookingopening and closingtime correctly
* Bugfix: Enable setting unenrolfromgroupofcurrentcourse
* Test: New behat Scenario: Booking actions: create settings for booking action via UI as a teacher and edit it
* Test: New behat Scenario: Booking actions: create booking action via DB and book it as students
* Test: New behat Scenario: Booking actions: create userprofilefield action via DB and book it as students

## Version 8.12.5 (2025041600)
* New feature: "What's new?" tab in Booking shows booking options made visible within a defined recent number of days.
* Improvement: Added setting 'redirectonlogintocourse'.
* Bugfix: Fixed that if user is not in course he won't be redirected to it.
* Bugfix: Restore correct version of commit on forced waitinglist.
* Bugfix: Avoid error when teacher from booking_teacher table doesn't correspond to actual user.
* Bugfix: Placed bookingrulestemplate setting correctly.
* Tests: Fixed several unit tests.

## Version 8.12.4 (2025041100)
* Improvement: Add sorting by timemodified for deleted bookings in bookings tracker.
* Improvement: Display statusdescription in bookingoption detailview #857.
* Bugfix: To avoid duplication of even triggered mails, set created date to full hour.
* Bugfix: Fix broken PHPUnit test for overlapping condition. #928
* Bugfix: Fix SQL for checkanswers task (avoid duplicates in id column, ignore already deleted answers).

## Version 8.12.3 (2025041000)
* Improvement: Display given enrollink in report.php
* Improvement: Add booking_history to course backup
* Improvement: Add search, sorting and filter to Bookings tracker and always enable presence.
* Improvement: Better distinction between availabilities.
* Bugfix: Check condition before booking users to waitinglist

## Version 8.12.2 (2025040900)
* Improvement: Multiple refinements for recurring options feature.
* Bugfix: Always enrol teachers into current course, not template

## Version 8.12.1 (2025040801)
* New feature: Default price category will be created on update (or new installation).
* Improvement: Unenrol from sourcecoursegroup if unenroled from bookingoption.
* Improvement: Refactored Pricecategories
* Improvement: Status and pricecategory changed to optionfields.
* Improvement: Usability improvements for bookings tracker.
* Improvement: On restoring, we use the old identifiers, if they are not yet used.
* Improvement: Back to course link works also for "visible with link" options
* Improvement: Use admin user for course duplication on template usage
* Improvement: Add Infotext for unlimited and don't show the number of booked places when it's on
* Improvement: In bookings tracker, show warning if no row is selected and bulk action is executed, remove col_actions (bulk actions are enough).
* Bugfix: Always remember templates in user preferences.
* Bugfix: Cancel button fallback on returnurl
* Tests: Extend tests.
* Tests: reset time_mock::set_mock_time(strtotime('now')); // Set "now"..

## Version 8.12.0 (2025040400)
* New feature: Switch between table templates (individually for each user).
* Improvement: Introduced a setting to activate preconfigured rule templates.
* Improvement: Enabled unlimited waiting list support.
* Improvement: Added multiple filter options to bulk operations.
* Improvement: Status description now displayed in the booking option detail view.
* Improvement: Add customfields to optionsdownloadfields.
* Improvement: Show all booking options in bookings tracker even if they contain no bookings (booking answers).
* Bugfix: Fixed issue where bookings could only occur after confirmation, affecting the waiting list behavior.
* Bugfix: Ensured that the responsible contact is enrolled in the correct course selected in the form (not in the old course from settings class).
* Bugfix: In sync_waiting_list we also need to purge answers cache before sending mails.
* Bugfix: maxperuser condition counted system-wide answers - it MUST be instance-specific.
* Tests: Extended test coverage to include recent changes.

## Version 8.11.3 (2025031803)
* Bugfix: Use has_set_url instead of catching error

## Version 8.11.2 (2025031802)
* New feature: Add setting to delete booking answers based on users losing access to
the booking instance (via course unenrolment or cm invisiblity).
* Improvement: Harden code for booking rules (fix problem with rules in other contexts).
* Improvement: Add callback to remove answers system-wide when checkbox unenroluserswithoutaccess is activated.
* Bugfix: Page URL got lost in fix_booking_page_context.

## Version 8.11.1 (2025031801)
* Improvement: New column "json" for booking_history table
* Bugfix: Check for mailtemplatessource check

## Version 8.11.0 (2025031700)
* New Feature: Recurring options
* New feature: Change status and checkboxes in bookings tracker on session level using checkboxes.
* Improvement: In case of an error when querying booking answers, catch the error if not in debug mode.
* Improvement: Show invisible options in bulkoperations and add visibility filter MUSI-678 #870
* Improvement: Notification list should never block for users with cashier capability.
* Bugfix: If param all=true is NOT set, we show all booking options ending today or later.
* Bugfix: Add args to bulkoperations table to make sure cache is built correctly
* Bugfix: Possibility to hide coursestarttime & showdates filter in shortcodes standardtable
* Bugfix: append coursestarttime to default optionfields
* Bugfix: config setting showbookingdetailstoall actually works
* Bugfix: Maxperuser must not block if user is not logged-in or guest user.
* Bugfix: Restore broken functionality for config settings maxperuserdontcountpassed, maxperuserdontcountcompleted, maxperuserdontcountnoshow.
* Bugfix: Recommendedin for multiple shortnames
* Bugfix: customfields placeholder not showing in rules placeholder overview
* Bugfix: Correct returnurl for isloggedin condition
* Tests: Extend tests

## Version 8.10.9 (2025031201)
* Bugfix: Link to Moodle course in Moodle Mobile App

## Version 8.10.8 (2025031200)
* New feature: Pre-configured rule templates - users can now replace
legacy mail templates with booking rules by using the new templates.
* Improvement: New price placeholder.
* Improvement: New place holder bookingconfirmationlink - link to booking receipt.
* Bugfix: If source of mail templates is global templates, we do not need to save instance mail templates.
* Bugfix: Wrong cmid for booking settings in applybookingrules
* Bugfix: Always use formdata['id'] instead of formdata['optionid']
* Tests: implemented test that triggers rules on payment_confirmed event
* Tests: created unittest for ruletemplate_paymentconfirmation

## Version 8.10.7 (2025031100)
* Improvement: Introducing new booking history table
* Improvement: Fix Link on course in Mobile App

## Version 8.10.6 (2025030700)
* Improvement: showdownloadbuttonatbottom needs to work in cards template too!
* Bugfix: Hardening when $optionid is 0.

## Version 8.10.5 (2025030700)
* Bugfix: moveoption didn't move all the data #865
* Bugfix: Make sure a lacking e-mail key wont destroy the mobile template
* Bugfix: maxanswers fallback

## Version 8.10.4 (2025030501)
* New Feature: Set maximum of bookable options per category (customfield) #818
* Bugfix: SQL errors for MariaDB

## Version 8.10.3 (2025030501)
* Bugfix: Fix SQL errors for MariaDB.
* Bugfix: Fix broken context for applybookingrules field.
* Bugfix: Fix unit test definitions.

## Version 8.10.2 (2025030500)
* New feature: Attach ical files to mails from Booking rules.
* Improvement: Don't show mails in mobile when we don’t want them.
* Improvement: More efficient way to skip selflearningcourse rules.
* Improvement: Move setting to configurefields section.
* Improvement: Save localized names of customfields to json for better performance.
* Improvement: Use site settings for teacher e-mail visibility also in mobile app.
* Improvement: Show options that are visible with direct link also in the mybooked options table.
* Improvement: SQL-based filtering by conditions now allows is bypassed for booked options.
* Improvement: Only output email key if email exists.
* Improvement: Add setting to json on add instance.
* Improvement: Add filter to table.
* Improvement: Add setting about customfield filter to instance.
* Improvement: Add moodle-customfield_dynamicformat to the list of required plugins in GitHub workflow.
* Bugfix: Add missing !empty checks for sendical attribute.
* Bugfix: Support array of values on data save to avoid Array to string conversion.
* Bugfix: Creation of dynamic property mod_booking\booking_settings::$customfieldsforfilter is deprecated.
* Bugfix: Fix cancelling icals and several improvements for new ical feature in rules.
* Bugfix: Fix issues with tracking, bulkoperations table, pollurl, pollunitteachers.
* Bugfix: Fix linting and improvements for new feature to add ical to rules mails.
* Bugfix: Settings to allow booking rules to send ics attachments.
* Tests: Add new behat test scenario for booking: configure customfield filter for booking instance and validate it as student.

## Version 8.10.1 (2025022601)
* Bugfix: Fallback for empty fields in rules.
* Bugfix: Add field places to DB if it's still missing for some reason.

## Version 8.10.0 (2025022600)
* New feature: Responsible contact persons can now be (un-)enrolled automatically to (from) the connected Moodle course.
* New feature: Include sessions in 'bookings' webservice.
* New feature: presence counter feature in report2
* New feature: Show tab on booking view.php with options where the logged-in user is a responsible contact.
* New feature: Add possibility to download booked users in bookings tracker in different scopes.
* Improvement: Use is_available of bo_info to check for actual condition results in function option_allows_booking_for_user.
* Improvement: Skip rules from option (opt in, opt out)
* Improvement: When PRO is active but selflearningcourse feature is not, we show a link to config settings (within help text)
* Improvement: Better capability checks for report2.
* Bugfix: Fix duplication for responsible contacts - moved it to POSTSAVE.
* Bugfix: Remove file that was duplicated by accident.
* Bugfix: Capability updatebooking should not be attributed to teachers by default as it would allow them to edit ALL booking options!
* Bugfix: Remove string concatenations as this causes AMOS to fail.
* Bugfix: Fix string for report reminders so bookingdetails placeholder will work again.
* Tests: Add new test for enrolled in cohort condition.

## Version 8.9.19 (2025021300)
* Improvement: Add prefix to display of bo in overlapping message
* Improvement: Use cached answers for `max_number_of_bookings` condition
* Improvement: If semester is removed from option, no fallback to booking instance semester
* Improvement: Use common function to generate possible presence statuses and harden code
* Improvement: Show an alert box if capability to edit option form is missing
* Improvement: Switch between report contexts within report and fix `require_login` in system scope
* Improvement: Add message about enrollment to waitlist
* Improvement: Enable book only after confirmation settings for enrolllink
* Improvement: Add info about no enrolllink triggered when user buys 1 seat for himself
* Improvement: Enrollbot user buying can choose if he wants to get enrolled
* Improvement: Booking mobile styling
* Improvement: Removed description and teacher from detail view
* Improvement: Write `erlid` into JSON of consuming answers to enable enrollment via confirmation
* Bugfix: Fix broken link
* Bugfix: Global booking rules could not be deleted anymore
* Bugfix: Manager archetype missing from `exportoptionform` capability
* Bugfix: Fix version number in `upgrade.php`
* Bugfix: Initial user after confirmation needs payment
* Bugfix: Block enrollment for guest users
* Bugfix: Use enrolllink param if given
* Bugfix: Status already enrolled
* Bugfix: Exception "Undefined variable $enwaitlist" in `managerusers_table.php`
* Bugfix: If user is enrolled add consumed item
* Bugfix: Require login before printing page
* Bugfix: Support sending teacher mails from mac/iOS system using a comma separator
* Bugfix: When previously booked referees to deleted option, webservices don’t work
* Tests: Refactoring and extend phpunit `test_rule_on_enrolllink_and_enroll()` to cover enrolllink usage by students
* Tests: Adjustments of the Behat Scenario: Booking option enrolllink: create and validate
* Tests: Adjust `test_rule_on_enrolllink_and_enroll_via_waitinglists()` test method
* Tests: Replace strings by constants in tests
* Tests: Extending of Behat scenario "Booking option enrolllink: create and validate" with rule and message validation

## Version 8.9.18 (2025013000)
* New feature: Turn shortcodes off globally. #810
* New Feature: New Rule to notify days before/after in relation to selflearningcourse. #823
* Improvement: Add possibility to invert sorting.
* Improvement: Remove unnecessary CSS for report2 as ist is also generated by a function.
* Improvement: Show warning if shortcodes are turned off and shortcode is used. #810
* Improvement: Add possibility to apply and change sortorder for pricecategories.
* Improvement: Possibility to turn on and off optionview for guests and logged out users. #822
* Improvement: Add booking_optiondates_answers to track sessionbased attendance. #721
* Improvement: Add optiondates class to handle presence status & attendance #721
* Improvement: Use adhoc task to recalculate prices
* Improvement: Possibility to show "more details" also for logged out users #828
* Bugfix: Setting was commented out.
* Bugfix: Go to course button rendered (mobile version).
* Bugfix: Collapsable description (mobile version).
* Bugfix: At the end booking of selflearningcourse, show correct message. #826
* Bugfix: Add tolerance to adhoc rule
* Bugfix: Add missing task strings
* Tests: Reactivate waitinglist with price behat test. #794

## Version 8.9.17 (2025012200)
* Improvement: If the user is logged-in, we check if (s)he has accepted the site policy.
* Improvement: Add results array (condition ids) to button template for better understanding (#807).
* Improvement: Delete unnecessary step in booking option creation (#807).
* Improvement: Allow testing of 0 price conditions (#807).
* Improvement: Support setting configs for each expected result.
* Improvement: Allow "optiondateid_0" etc. keys to upload sessions.
* Improvement: Add download and columns to bulkoperations.
* Improvement: Possibility to skip rules from current context.
* Bugfix: Make sure price is shown when askforconfirmation is blocking (#807).
* Bugfix: Use importing to correctly set price during option creation.
* Bugfix: Fix behat tests by correctly calling importer.
* Bugfix: Respect order of price categories when deciding which price category will actually be used #808.
* Bugfix: Fix behat tests by properly create the customfield.
* Bugfix: Correctly handle empty price category #778.
* Bugfix: Only display customfields with values.
* Bugfix: Fix pricecategory sort order.
* Tests: Add new test type with making use of data provider (#807).
* Tests: Fix behat and phpunit tests.

## Version 8.9.16 (2025011702)
* Bugfix: Only add setting optionviewcustomfields if custom fields exist.

## Version 8.9.15 (2025011700)
* Hotfix: Make sure missing rules_info in lib.php does not break the upgrade. (#805)

## Version 8.9.14 (2025011601)
* Improvement: Changed dependency of Wunderbyte Table to newer version fixing wbt_field_controllers.

## Version 8.9.13 (2025011600)
* New feature: Add possibility to display the values of any booking option customfields on detail page. (#774)
* Improvement: Add action delete button to new report2.
* Improvement: Fix string for duplicate booking option.
* Improvement: Remove underscores from links and use better divider in report2 nav.
* Improvement: Add back and edit button to details view (#773).
* Improvement: Fix margin for showheaderimagelefthalf.
* Improvement: Add class to identify card for imagelefthalf.
* Improvement: Better string for selflearningcoursedurationinfo.
* Improvement: Always generically use wbt field controllers to render customfields on detail page (#774).
* Improvement: Add multiselect for customfields to show on detail page. (#774)
* Improvement: Make sure empty price categories are deleted from singleton.
* Bugfix: Fix behat for new waiting list accordion (extra click necessary).
* Bugfix: Fix string for user calendar URL.
* Bugfix: Presence status still needs to work without PRO license!
* Bugfix: Fix merging errors.
* Bugfix: Fix "file is stale" problems.
* Bugfix: Fix string order issues (#648).
* Bugfix: Add icon class to fix behat.
* Bugfix: Add title and aria-label for settings dropdown to fix behat tests.
* Bugfix: Use fontawesome icon fa-cog instead of t/edit to fix Moodle 4.4 icon.
* Bugfix: Remove webkit-specific CSS to fix Safari layout.
* Bugfix: Dates placeholder returns dates (#756).
* Bugfix: Remove `<br>` tag for date display col starttime.
* Bugfix: Make sure to use cmid of type int (#572).
* Bugfix: Correctly handle empty price category (#778).
* Bugfix: Coding error completion `custom_completion` (#779).
* Test: New phpunit test `test_booking_cancellation_wiht_multiple_dates_and_consumption_enabled` (#777).
* Test: New phpunit test `test_booking_cancellation_wiht_consumption_enabled` (#777).
* Test: New phpunit test `test_booking_cancellation_wiht_fixed_consumption` (#777).
* Test: New phpunit test `test_booking_bookit_capabilitynotneeded` to cover `JSON_ALLOWEDTOBOOKININSTANCE` and `MOD_BOOKING_CONDPARAM_CANBEOVERRI`.
* Test: Adjust 6 phpunit tests.
* Test: Refactor and extend `test_booking_customform()` phpunit to support multiple form elements and validate response (#524).
* Test: Refactor 1 data provider and 1 phpunit test.
* Test: New behat scenario: Booking - cancellation of all users' purchases when price and consumption were set (#777).
* Test: New behat scenario: Configure availability with modal form and multiple elements (#524).
* Test: New behat scenario: Booking - cancellation of all user purchases by teacher when price was set (#777).

## Version 8.9.12 (2025011500)
* Improvement: Display teacherimage on bookingoption detailview #792
* Improvement: GH-784 go to course button
* Bugfix: Don't show currency labels on empty price
* Bugfix: Show price correctly
* Bugfix context check for rules deletion
* Bugfix: Avoid error on empty price element
* Bugfix: removed duplicate string
* Bugfix: default value get_options_filter_sql
* Bugfix: Display teacherimage only for teachers with image
* Bugfix: Track changes for dates and location correctly #796
* Bugfix: Allow cancellation on zero price booking options

## Version 8.9.11.1 (2025011001)
* Bugfix: Make sure no notification,completion,confirmation mails are sent anymore.
* Bugfix: Don't compare on dates to notify anymore
* Bugfix: Fix limit send notification for updated booking options

## Version 8.9.11 (2025011100)
* Improvement: Change datesandentties placeholder to deal with selflearningcourses.
* Improvement: Better datesandentities placeholder (especially with duration 0).
* Bugfix: Move setting for bookingmanager in global area of bo instance settings.

## Version 8.9.10 (2025010802)
Bugfix: replace empty placeholders correctly if tags are given
Bugfix: Use actual blank instead of nbsp as it might not be rendered in plaintext e-mail. #787

## Version 8.9.9 (2025010801)
Bugfix: don't format text for all event descriptions in event log table

## Version 8.9.8 (2025010800)
* Improvement: Case insensitive fetching of template courses
* Bugfix: Replace wrong usage of array_pop which destroyed our singleton. #777
* Bugfix: Fix regex for optiondate customfields so it doesn't match incorrectly. (#781)
* Bugfix: Deletion of other than shortterm reservations were not working anymore via booked_users class (#759)

## Version 8.9.3 (2025010300)
* Bugfix: Avoid unintentional deletion of all system rules (Important!)
* Bugfix: Add missing cachedef strings

## Version 8.9.2 (2024122000)
* New feature: Add shortcode arg to show the courselist filter on top (#752).
* Improvement: Rules can be set active/inactive #764
* Improvement: Convert bookingdetailslink overwritable string #767
* Improvement: Display links to other rules in system rules site #656
* Improvement: Better description for enrol in group function #635
* Improvement: Set rule property active default as true.
* Improvement: Add possibility to pre-filter shortcode for any customfield (#752).
* Improvement: add setting to hide duration for selflearning courses
* Improvement: Also hide duration on optionview.php if setting to hide duration for selflearningcourses is active.
* Bugfix: Correct strings #742
* Bugfix: Placeholder coursecalendar generates correct link #754
* Bugfix: Correctly check if rule is active #764
* Bugfix: Disable sorting of indexnumber in report.php #741
* Bugfix: Bugfix for "Unknown error type: Creation of dynamic property mod_booking\booking_rules\rules\rule_react_on_event::$ruleisactive is deprecated".
* Bugfix: Check capability on correct context (Wunderbyte-GmbH/Wunderbyte-GmbH#291)
* Bugfix: Test modcontext, not systemcontext for invisible options
* Bugfix: Use correct context and test on $settings-id, not optionid
* Test: Fix fieldname and message strings in behat.

## Version 8.9.1 (2024121800)
* Improvement: Add helper function to get a list of all cmids (of all booking instances).
* Improvement: GH-771 Show countlabel whenever filters are activated (to have the reset button).
* Improvement: Add "h" string also to htmlstring.
* Improvement: Truncate teacher description on overview page, add modal to view long description directly.
* Improvement: Add debug messages, so we can investigate broken download (Wunderbyte-GmbH/Wunderbyte-GmbH#283).
* Improvement: Improve settings for Moodle Mobile App.
* Improvement: Try catch for campaign application to make sure nothing breaks if campaign contains errors.
* Improvement: Codestyle remove duplicated function.
* Bugfix: GH-765 Make sure we don't encounter error with legacy booking answers.
* Bugfix: Display "hour" only once.
* Bugfix: Correctly create and delete user events (for each session) for teachers of booking options.
* Bugfix: Error when creating booking option templates with teachers, dates and addtocalendar active (fixes #766).
* Bugfix: strip_tags needs string value, null not allowed.
* Bugfix: Check for singleton of (extrabutton-)condition.
* Bugfix: Add link to booking rules for string deleteinfoscheckboxadminwarning.
* Bugfix: Correctly handle cancel of reservation in report.php (#759).
* Bugfix: Make sure rules of instance are deleted with booking instance (#764).
* Test: New phpunit test method test_backup_restore_bookings_with_options_quiz_into_other_course() (#518).
* Test: Extend phpunit test method test_backup_restore_bookings_with_options_quiz_into_other_course() to use custom fields too (#518).
* Test: Update phpunit test method test_backup_restore_bookings_with_options_quiz_into_other_course() to use few date sessions (#518).
* Test: Improve cache clean-up.
* Test: New phpunit test_rule_on_freeplace_on_intervals() (#467).

## Version 8.9.0 (2024121200)
* Improvement: Possibility to turn off prices for not logged in users #762.
* Improvement: Empty tabs (#709).
* Bugfix: Make campaigns backwards compatible (Wunderbyte-GmbH/Wunderbyte-GmbH#279).
* Bugfix: Correctly check overlapping for combination of two dates and one date (#757).
* Test: Fix custom behat step to use proper identificators.
* Test: New behat Scenario: Booking option: waiting list with prices (#457).

## Version 8.8.9 (2024121000)
* Improvement: Extend tests for campaign
* Bugfix: Pricedisplay with unknown identifier

## Version 8.8.8 (2024120900)
* Improvement: Add another option in booking settings to allow cancel without limit.
* Bugfix: Fix mlang first in event log table and in message body.
* Bugfix: Campaign feature.

## Version 8.8.7 (2024120501)
* New Feature: Add condition to block/warn overlapping of bookingoption dates.

## Version 8.8.6 (2024120500)
* Bugfix: format string in customfields only for string

## Version 8.8.5 (2024120400)
* Improvement: Nav tabs for mobile view
* Bugfix: Prevent booking rules from being sent on inactive configuration
* Bugfix: No price if fallback for default price is off
* Bugfix: Notification list only for logged in users & display price
* Bugfix: Several fixes for self-learning courses

## Version 8.8.4 (2024120300)
* Improvement: Add type=imageleft (or imageright) to shortcode 'courselist' to show header images.
* Improvement: Campaigns allow multiple profile fields
* Improvement: Set relative cancellation dates until midnight of selected day
* Improvement: Format string on changes values from customfields
* Bugfix: Apply campaigns correctly for users not logged in.
* Bugfix: check userprofilefield doesn't break view for users not logged in

## Version 8.8.3 (2024112800)
* New feature: List views with header image on left or right side. (#233)
* Improvement: Pass template data via Wunderbyte table. (#233)
* Improvement: Adjust template and CSS for new header images in list view. (#233)
* Improvement: Add alert about reference to Moodle course. (#711, #650)
* Improvement: Change name of option "multienrol" for clarity. (#650)
* Bugfix: Fix upgrade after version update due to rebase.
* Bugfix: Remove wrong indexing.
* Bugfix: Correctly trigger events for enrolment actions. (#650)
* Test: Finalize Behat scenario: Booking option enrollink creation and validation. (#711)
* Test: Add new PHPUnit test `test_rule_on_enrollink_and_enroll()`. (#711)
* Test: Extend PHPUnit test for placeholders in `test_rule_on_enrollink_and_enroll()`. (#711)

## Version 8.8.2 (2024112600)
* Bugfix: Wunderbyte-GmbH#240 - Fix localization on teacher description page.
* Bugfix: Fix warnings for self-learning courses and never show them if config setting is off.
* Bugfix: Do not hide but disable self-learning course checkbox, so users can understand behavior of form elements.
* Bugfix: Set notlast flag instead of last flag for comma in teachers list.

## Version 8.8.1 (2024112500)
* Improvement: Better strings for self-learning courses feature.
* Improvement: Add support for Moodle 4.5.
* Improvement: Move booking and cancelling settings into corresponding section.
* Improvement: Display static warning about 'deleteinfocheckbox' only for Moodle >= 4.3.
* Improvement: Adjust behat "Booking option availability: custom form with selection of prices" to cover even decimals in the additional prices.
* Bugfix: Fix missing strings and string order.
* Bugfix: Render 'enddatetime' with only one "h" for hour (#234).
* Bugfix: Correct string identifier and hide static warning for Moodle < 4.3 (#713).
* Bugfix: Fix booking page context for blockbooking campaign.
* Bugfix: Fix strings for self-learning courses (#713).
* Bugfix: Potential bugfix for self-learning courses.
* Bugfix: Fix behats on cancellation due to "Booking and Cancelling" settings group.
* Bugfix: Only modify price if given.
* Bugfix: Don't show legacy notification mail templates (#685).
* Bugfix: Ensure no legacy reminder mails are sent when they are turned off (#685).
* Bugfix: Use English placeholders only (#712).
* Bugfix: Append usernames with a comma in changes (#706).
* Test: New behat scenario for self-learning courses enrolment (#684).

## Version 8.8.0 (2024112000)
* Improvement: Updated wunderbyte table dependency to new version 2024112000.

## Version 8.7.9 (2024111900)
* Improvement: Enable price as 3rd arg for customform select (#669 MUSI-621)
* Improvement: Extend customform select limit to allowed users (#669 MUSI-621)
* Improvement: Display infos about select in customform (#669 MUSI-621)
* Improvement: user string price with fixed decimal points as elsewhere (#696)
* Improvement: Fixes and improvements for campaigns.
* Bugfix: Customform select specific usecases (#669 #650 MUSI-621)
* Bugfix: Fix of incorrect processing of pricecategory string
* Bugfix: small adjustment of the condition_bookingpolicy_test class.
* Bugfix: Fix zero price phpunit test (#654).
* Bugfix: Do not show zero price for students unless it forced

## Version 8.7.8 (2024111500)
* New feature: Booking option with a duration for self-learning courses:
Users will get enrolled when they book for the defined duration.
* New feature: Better display of PRO features and links to renew license and to new Booking Academy.
* Improvement: Placeholders for Semester & Name of instance (#660)
* Improvement: Select absolute canceluntil date in bookingsettings (#662)
* Improvement: Track detailed changes of customfields (#670).
* Improvement: Set flag for last teacher in array to be used in template (#695).
* Improvement: Better strings for absolute date (with adjusted behat).
* Improvement: Make courses with fixed duration a PRO feature.
* Improvement: When there are no dates, we simply don't show them. No reason to show a "No date set" string.
* Improvement: selector names, linting, fix pro-features UI etc.
* Improvement: Link to booking rules course in showroom #694.
* Bugfix: Display only meaningful data in shoppingcartplaceholder (#687)
* Bugfix: Do not clean shortname as some customers need the fullname even in the shortname (e.g. for placeholders) - fixes #688
* Bugfix: Fix potential cache issue in the test_delete_responses_activitycompletion()
* Bugfix: Fix for "assertObjectHasAttribute() is deprecated and will be removed in PHPUnit 10. Refactor your test to use assertObjectHasProperty() instead" in phpunit (#689).
* Bugfix: Fix generator method on rule creation.
* Bugfix: Explicit declaration of params to avoid "Creation of dynamic property booking_settings::$xxxxxx is deprecated" error.
* Bugfix: viewconfirmation render correct data.
* Bugfix: Correctly display price if user isn't logged in.
* Bugfix: Make sure date section does not collapse when adding dates.
* Bugfix: setType to PARAM_INT for selflearningcourseactive.
* Bugfix: When no license is set, we disable self-learning course checkbox.
* Bugfix: Fix behat for self-learning course enrolment. #684
* Bugfix: #703 - Recommendedin matches without wildcards to avoid false positives.
* Test: new behat scenario for Self-learning courses: duration and enrollment (#684).

## Version 8.7.6 (2024110600)
* Improvement: Tests for checkbox deleting infos from bookinganswers
* Improvement: Better tests for rules feature
* Improvement: Possibility to limit description length via server side validation
* Bugfix: Improve SQL to fetch bookinganswers
* Bugfix: Fetch bookinganswers from cache
* Bugfix: Add missing fields for booking options for backup and duplication.

## Version 8.7.5 (2024102500)
* New Feature: Billboard to overwrite warning messages blocking bookings
* Improvement: add campaign to enable extension of limit for overbooked places
* Improvement: better testing of booking option completed
* Improvement: refactoring of delete_responses_activitycompletion() method to use singleton calls
* Improvement: new behat Scenario: Configure availability with modal form and data deletion
* Improvement: Possibility to adjust description passed on to shopping cart via placeholders
* Improvement: if no price is set for user, allow booking
* Improvement: Add setting for displayemptyprice
* Improvement: New tests for rules
* Bugfix: User delete response
* Bugfix: String translations
* Bugfix: detailview of teacher working with only 2nd phone as well
* Bugfix: Search in template list
* Bugfix: Allow alerts for prepagemodals
* Bugfix: fallback for check on empty price

## Version 8.7.4 (2024101700)
* Improvement: improve filter of bulkoperations
* Improvement: swap main and top button in prepagemodal
* Improvement: update readme
* Improvement: Better information about teacher roles enrolment
* Improvement: Better informations for users regarding activitycompletion
* Improvement: Add 'Uhr' to german time
* Improvement: Improve Teams & bbb rendering in mails
* Improvement: Execute Rules and related events (cancellation) in the right order
* Improvement: Add field to db to check if overbooking is allowed
* Bugfix: really avoid breaking task
* Bugfix: Change infotext for changes of option fields
* Bugfix: Don't show message symbol on teachers page when messaging is deactivitated
* Bugfix: Better localization when sending mails
* Bugfix: Don't render prepage when we block with an alert
* Bugfix: fix link to price formula

## Version 8.7.3 (2024101100)
* Bugfix: Display deletecheckbox correctly
* Bugfix: Hide second customfield and operator correctly
* Bugfix: Behat Scenario: "Boooking option: add multiple session dates by editing booking option" in attempt to solve github issues
* Bugfix: adjustment for phpunit test to reduce false failures

## Version 8.7.2 (2024100800)
* Improvement: new generator method to create item prices via API
* Bugfix: Remove empty get_string mybookinglist from mobile.php
* Bugfix: html strings render
* Bugfix: separate processing of subbookings when prices has been added

## Version 8.7.1 (2024100700)
* Improvement: Add classes to old & new values in eventlist of booking option for better styling
* Improvement: Link from report.php to bookingoption -> showonlyone view
* Improvement: Trigger free to book again event on changing limit of maxanswers
* Improvement: Add relateduser firstname & relateduser lastname
* Improvement: Add checkbox to enable users or teachers to delete data (customfield formdata) from bookinganswer after end of bookingoption.
* Bugfix: correctly include booking_option class
* Bugfix: Correctly use force_current_language
* Bugfix: No message button when messages are deactivated on the site.
* Bugfix: Move mybookinoptionstable to session cache, as it only regards individual users.
* Bugfix: Fix varying columns width issue in custom fields
* Bugfix: Don't set wrong url on teacher.php

## Version 8.7.0 (2024100400)
* Feature: Add possibility to edit teacher description directly
* Improvement: Display Online Link for Dates and Entities Placeholder
* Improvement: Support buyforuser functionality in standard wbtable
* Bugfix: Revert to current_language instead of $SESSION->lang
* Bugfix: Make sure the teacher description is rendered with format_text (mlang filters!)

## Version 8.6.25 (2024100200)
* Improvement: Better feedback when deleting booking option
* Improvement: If there is an error in importing one custom field, we should not abort the whole process.
* Improvement: Use filters on return values of customform in placeholder
* Improvement: Make info about required login to book more important
* Bugfix: Make sure we don't multiply sessions on webservice import
* Bugfix: improve handling of array customfields
* Bugfix: Enable correct language switching
* Bugfix: Only hide link to course when linktomoodlecourseonbookedbutton and not booked
* Bugfix: Guest users are treated as not logged in

## Version 8.6.24 (2024100100)
* Improvement: Setting to display detailview in same tab
* Improvement: Show elements with validation errors
* Improvement: Possibility to load multiple fields for bulk operations
* Improvement: add timecreated to report download file
* Improvement: add price to responses in report.php
* Improvement: possibility to disable booking for all options in instance
* Improvement: Add second profile field to availability conditions
* Improvement: Extend unit and behat tests
* Bugfix: Open collapsible also on client side
* Bugfix: Correct handling of arrays for printing out customfields.
* Bugfix: fallback for empty returnurl

## Version 8.6.23 (2024092302)
* Improvement: add intrangefilter to bulkoperations table
* Improvement: Add filter for bookinginstance (Semester) to bulkoperations table
* Improvement: Add 0% to avoid adding classes on low percentage
* Improvement: don't show second link on course when link is on button
* Improvement: Add possibility to write mail for text (title) change of booking option
* Improvement: add possibility to turn off the duplication of booking options in the duplication of booking instances
* Bugfix: Treat guest users as not logged in
* Bugfix: use format_text on customfields with type textarea
* Bugfix: Apply default sorting to field of study
* Bugfix: Empty get_string mybookinglist mobile.php
* Bugfix: Listen to event to invalidate cache on updating course module

## Version 8.6.22 (2024092300)
* Improvement: Reload after using form on bookingdetails page
* Improvement: Open booking options template with returnurl -> go back to overview on save
* Improvement: Call format_string on title and column names for better localization possibilities
* Bugfix: No unnecessary cache invalidations
* Bugfix: Placeholders: QR Codes and fetching localized placeholders

## Version 8.6.21 (2024091901)
* Improvement: Display name of user in message_sent event descriptions
* Improvement: Encode pricegroup identifiers so we can use special characters
* Improvement: Use next full hour in add date.

## Version 8.6.20 (2024091900)
* Improvement: Add description for canceldependenton
* Bugfix: No unnecessary cache invalidations

## Version 8.6.19 (2024091700)
* Improvement: Shortname is same as fullname on create course fromtemplate
* Bugfix: use context_module in capability check of confirmcancel modal
* Bugfix: in unit tests

## Version 8.6.18 (2024091600)
* Improvement: Improvement: More flexible matching of price categories & possible fallback on default price.
* Improvement: New json condition allowedtobookininstance
* Improvement: Add bo condition cap booking choose
* Bugfix: PHP 7.4 ParseError

## Version 8.6.17 (2024091001)
* Improvement: Display isloggedinprice rather than info that booking is not yet available
* Improvement: hand over condition data to bookit button
* Improvement: Add format_string for customfield names
* Improvement: Change values of customfields via bulkoperations
* Improvement: add customfield filter for bulkoperations
* Improvement: Catch throwables for all event descriptions
* Bugfix: Fix handling in case urise is not installed.
* Bugfix: make field::set_data work in bulk operations
* Bugfix: Revert false language in string files
* Bugfix: cachedef lang files need underscore

## Version 8.6.16 (2024091001)
* Bugfix: type correction
* Bugfix: bookingoption_updated empty objects handling
* Bugfix: Fix try catch for bookingoption description

## Version 8.6.15 (2024091000)
* Improvmenet: Also count course status and return
* Improvement: Fixes for signinsheet generator
* Improvement: Allow up to 20 fields in customform
* Improvement: Add enrolmentstatus to tracked changes in bookingoption
* Improvement: Track changes for shoppingcart field, bookingopening- & -closingtime, canceluntil, desablebookingusers, disablecancel, customfields
* Improvement: Trigger event if prices are changed
* Improvement: purge event caches after bookingoption_updated event
* Improvement: Track changes in actions after booking, attachment, waitformconfirmation
* Improvement: Add / fix missing string
* Improvement: Track changes of availability, aftercompletedtext, notificationtext, removeafterminutes
* Improvement: Resolve 1/0 values as "on"/"off" in event description
* Improvement: Performance improvement of eventlist
* Improvement: In case of error in event description of bookingoption_updated, return default message
* Bugfix: If course does not exist anymore, on save, we delete the reference
* Bugfix: Book on detail can now handle cashier checkout
* Bugfix: Notification Task should not fail on deleted booking option
* Bugfix: Check for changes of all shoppingcart keys
* Bugfix: Fix changes tracking of pollurl (-teachers)
* Bugfix: Do not exclude classes from tracking of changes
* Bugfix: react on changes in bookingoption only for qualified updates
* Bugfix: Changes in bookingoptionimage

## Version 8.6.14 (2024090500)
* Bugfix: Don't send Mails to users that don't fullfill the condition anymore.

## Version 8.6.13 (2024090400)
* Improvement: Add changes handling to beforebookedtext & beforecompledtext
* Improvement: Don't use one session difference when displaying entites
* Improvement: Only show editurl when teacher or has capability updatebooking
* Improvement: Capability check
* Bugfix: Display simplified changes for placeholders
* Bugfix: bookingoption_updated event for subbookings
* Bugfix: fix rule n days before - IMPORTANT!
* Bugfix: Handle missing booking or option Id in dates handling
* Bugfix: return button on booking details page
* Bugfix: Still execute action based rules
* Bugfix: change string in feature test
* Bugfix: Fix behat test
* Bugfix: No error on creation global template

## Version 8.6.12 (2024090300)
* Improvement: Throw meaningful error when shortnames of booking option fields don't correspond to convention
* Improvement: New behat scenario
* Bugfix: Teacher will never be enrolled only for the semester, but will have full access to course.
* Bugfix: Small importer improvements
* Bugfix: Fix subbooking logic, especially in combination with bookafterconfirmation

## Version 8.6.10 (2024082901)
* Improvement: Not booked users will see beforehand if a date is online or not
* Bugfix: formt_text for beforebookedtext etc.
* Bugfix: Turn sororder for fieldofstudy
* Bugfix: Booking notes work again

## Version 8.6.9 (2024082900)
* Improvement: Save multiple places in booking_answers table
* Improvement: Count places, not answers
* Improvement: Render different types of subbookings in one modal
* Bugfix: Title is link to booking details page again
* Bugfix: Make sure we really don't execute the send mail by rule adhoc task
* Bugfix: Allow editing of option templates
* Feature: Add places to booking_answers table

## Version 8.6.8 (2024082700)
* Bugfix: More reliable test if page url is available or not
* Bugfix: Do not continue execution for Rule when it does not exist anymore.

## Version 8.6.7 (2024082601)
* Bugfix: Avoid destroying foreign placeholders
* Bugfix: Don't show detail page when not logged in

## Version 8.6.6 (2024082600)
* Improvement: new phpunit tests
* Improvement: Add warning when higher Moodle version is needed.
* Improvment: Include better description for a booking rule.
* Improvement: Use different icon for bookondetails page
* Improvement: Only semestersettings of individual booking option determines service period. No Semester means coursestarttime - courseendtime
* Bugfix: Shorten sql identifier because of possible length restriction
* Bugfix: Make sure task doesn't fail when rule is deleted
* Bugfix: Fix access to rulesform
* Bugfix: notsupported
* Bugfix: Improved mode checker with regards to cashier page
* Bugfix: Fix url to optionview page in placeholder
* Bugfix: Don't call rules after every event, but execute them only once at the last moment in lib.php

## Version 8.6.5 (2024081900)
* Improvement: Enhancements of rules and placeholders
* Improvement: Better book on detail page handling
* Improvement: #596 Better feedback for not logged in users
* Improvement: Use format_string instead of format text when advisable
* Improvement: Add booked AND on waitinglist selector to bookingoptionusers
* Improvement: Add deleted users to report.php
* Improvement: Show price also for admins when details page is on.
* Improvement: Add new operators for in_array coupled with "contains" in profilefields
* Improvement: Support localisation via mlang filter in settings
* Improvement: Support additional columns in coursecategories class.
* Improvment: Make sure that details of a booking option are visible if 'bookonlyondetailspage' is turned on
* Bugfix: Add div element for better displaying the deleted users
* Bugfix: Show price only when useprice is on
* Bugfix: Fix Outline report functionality
* Bugfix: Do not trigger bookingoption_booked event when we only book waitinglist
* Bugfix: {mlang} support for labels and values in customform
* Bugfix: Fix error null in trim function
* Feature: Possibility to send mail via booking rule on payment_confirmed event from shopping cart, including shoppingcart placeholder

## Version 8.6.4 (2024080900)
* Improvement: Integrate Entities plugin in tests
* Improvement: Add bookingreportlink to placeholders
* Improvement: Enable item_canceled event from shoppingcart
* Improvement: Add datesandentities placeholder
* Bugfix: Track changes of entities in dates correctly
* Bugfix: Revert setting to enable messaging for all teachers causing core errors
* Bugfix: Legacy errors of removing underscores from strings

## Version 8.6.3 (2024080500)
* Improvement: New automated tests
* Improvement: Allow coursecreators to update bookings
* Improvement: Add event for booking on waitinglist
* Improvement: choose between related user and user in more events
* Improvement: Rename bookingoption_confirmed event to bookinganwer_confirmed and always trigger on confirmation (no matter if price is set)
* Improvement: Revert order of options in rules select action
* Improvement: add new event for bookinganswers_waitingforconfirmations
* Bugfixes: Don't block booking via notifymelist for users already on waitinglist
* Bugfixes: Improvements of bulkoperations
* Bugfix: Serveral strings after refactoring legacy

## Version 8.6.2 (2024073000)
* Improvement: Alternative importfields for courseid
* Improvement: Enable item_bought event from shopping_cart plugin
* Improvement: Add "skip rule" functionality to booking rules
* Improvement: Show deleted users on report.php
* Improvement: Enable custom user profile fields in sign-in sheet
* Improvement: Use formated strings for config of bo fields and columns selects
* Improvement: Enable filter formated strings {mlang}
* Improvement: Add no shows for dashboard
* Bugfix: Bookingoption changed event containing only relevant data
* Bugfix: Display title prefix only once
* Bugfix: Move deleted users to the right place

## Version 8.6.1 (2024072900)
* Bugfix: Refactor underscores in strings
* Bugfix: remove false format_string
* Bugfix: Notificationlist and book only on waitinglist combination working.
* Bugfix: Cohort upload in booking

## Version 8.6.0 (2024072500)
* Improvement: Integrate Requirements for github workflow tests for Moodle 4.4
* Improvement: Add btn-primary to "Go to Moodle Course"
* Improvement: Customize rules reaction on change event as settings
* Improvement: Add bookingoption_cancelled event to rules list
* Improvement: Add possibility to add a sum for a customfield in category statistics
* Improvement: Possibility to select user affected by bookinganswer_cancelled event in rules.
* Bugfix: Changes tracking for entities
* Bugfix: Duplication is separated from templates
* Bugfix: Make sure newly created booking option fields are still shown in the configurations
* Bugfix: Fix linkbacktocourse shortcode
* Bugfix: Deleted course does not break the plattform.

## Version 8.5.0 (2024071801)
* Improvement: Enable up to 3 bookingrules for free version
* Improvement: Vue Dashboard

## Version 8.4.9 (2024071800)
* Bugfix: Bookingopening and bookingclosing in bulk operations
* Bugfix: Avoid unwanted moving of booking option

## Version 8.4.8 (2024071700)
* Improvement: Return configdata when fetching customfields via handler
* Improvement: Bulk Operations for bookingoption via shortcode [bulkoperations]
* Bugfix: Version supported uses new syntax
* Bugfix: Fix wrong use call of external_multiple_structure

## Version 8.4.7 (2024071500)
* Feature: Add feature to move booking option to different booking instance
* Feature: Add setting "bookondetail" to allow booking only on details page
* Improvment: Assign teacher of bookingoption to course and role according to settings
* Improvment: Add userpic to sign-in sheet
* Improvment: Add time of booking to sign-in sheet
* Improvment: Setting to enable messaging to all teachers
* Improvment: Only show move to for cms where there is the right capability
* Improvment: Skip empty records on import of bookingoptions
* Improvment: Add key to accepted datesfield for importer
* Improvement: Make sure to show linkt on moodle course for teachers, even when they are not booked
* Improvement: Take out coursevalidation
* Bugfix: Trigger bookingoption_updated event for imported bookingoption.
* Bugfix: Allow cancel when linkt to moodle course is present.
* Bugfix: Correct itemcount for imported records event
* Bugfix: Display header image in sign-in sheet
* Bugfix: Create new courses in the correct course categories
* Bugfix: Correctly delete tags of instance
* Bugfix: Fix create new course from template with limited rights.
* Bugfix: Don't take instance "daystonotify" value as optiondates value if there is only one session.
* Bugfixes: Add more unit & behat tests.

## Version 8.4.6 (2024070300)
* Improvement: Also fetch courses from within category in webservice
* Improvement: Check if the field has a categoryid as id, if so, use it
* Improvement: Make sure we don't depend on arbitrary row class when using prepage code.
* Improvement: Move mybookings to separate cache so we can invalidate on booking without big performance penality
* Bugfix: Deal with array in course creation.
* Bugfix: Avoid running into missing optionid

## Version 8.4.5 (2024070300)
* Feature: Add possibility to add "invisible" except for direct link.
* Improvement: Add more unit & behat tests.
* Improvement: Add Message body to custom messages
* Improvement: Add returnurl support for show only one option
* Improvement: Add maplink & mapembed to entitiy cached properties
* Improvment: Format description text to support mlang filter
* Bugfix: Sync waitinglist with timemodified instead of time created logic. (this enables the resorting)
* Bugfixes: Add more unit & behat tests.

## Version 8.4.4 (2024062700)
* Improvement: Additional information in teacher page.
* Improvement: Convert capital letters to lowercase and keep in tabname.
* Bugfix: Don't throw error when option was deleted.
* Bugfix: Autoenrolment in created course via bookingoption.

## Version 8.4.3 (2024061900)
* Improvement: Track changes of booking option and enable rule for it.
* Improvement: Display Login Button in bookingoption for users not logged in (config setting).
* Improvement: Expand userlist in booking option: add userpictures, indexnumber and change naming of bookingdate.
* Bugfix: Don't throw error when option was deleted.

## Version 8.4.2 (2024061400)
* Improvement: Bookingoption_confirmed event & rule for "Book only after confirmation" with price set.
* Improvement: Show "on waitinglist" in report php also when we just use the confirmation feature.
* Bugfix: Keep digits in tabnames.

## Version 8.4.1 (2024061200)
* Improvement: Add customform placeholder.
* Improvement: Trash icon in collapsable optiondate in bookingoption.
* Improvement: Enable enclosing placeholders ({#ph} {ph} {/ph}).
* Improvement: Failing rules trigger event not error (except in debug mode).
* Bugfix: Improve performance regarding attached files.
* Bugfix: Always use userlanguage for calendar entries.
* Bugfix: Smaller SQL fixes.

## Version 8.4.0 (2024060600)
* Improvement: Add rank number to waiting list.
* Improvement: New placeholder eventdescription.
* Improvement: Mobile customform extensions.
* Improvement: Individual campaigns, depending on user profile field.
* Improvement: Display messages sent for bookingoptions.
* Improvement: Add possibility to autmatically buy pro license.
* Bugfix: Subbookings moving through prepages.

## Version 8.3.9 (2024052900)
* Bugfix: Make sure deleted cohort does not break system.

## Version 8.3.8 (2024052800)
* Feature: New moodle course template handling
* Feature: New waitinglist handling & notifications (via booking rules)

## Version 8.3.6 (2024052400)
* Improvement: Upgrade fields pollurlteachers & pollurl up to 1000 chars.
* Improvement: Display sent messages in bo report.
* Improvement: Add coolingoffperiod to avoid unintentional double clicks.
* Bugfix: Avoid errors for restorement.
* Bugfix: Fieldofstudy Display.
* Bugfix: Fix prepage for subbooking.
* Bugfix: Fix filter display on view.php.

## Version 8.3.5 (2024052300)
* Bugfix: Look at cancel until date also for cancel purchase button

## Version 8.3.4 (2024052201)
* Bugfix: Update events on booking optiondate change (instead of insert).
* Bugfix: Don't impose dark text in bookingoption form.

## Version 8.3.3 (2024052200)
* Improvement: Add warning when exceeding max n of cohorts (set to 500).
* Improvement: Checkbox for booking instance.
* Bugfix: Check for berta settings.

## Version 8.3.1 (2024052101)
* Bugfix: Sorting of waitinglist in mysql dbfamily.

## Version 8.3.0 (2024052100)
* Improvement: Add placeholders for installments (local_shopping_cart)
* Improvement: Support moodle mobile app. Support for booking options and using custom forms.
* Improvement: Enable rule for timestamps (days) after dueday.
* Improvement: Enable sql filter for mariadb/mysql.
* Bugfix: For teachers responsible for a bookingoption, link to teacherpage instead of user profile.

## Version 8.2.9 (2024050800)
* Improvement: For teachers responsible for a bookingoption, link to teacherpage instead of user profile.
* Improvement: Allow confirmation when there is is no pre booking page.
* Bugfix: Users on notification list must not be enroled in moodle course.
* Bugfix: Check if already booked before booking again.
* Bugfix: Remove unnecessary inclusion of question/category from requirements.
* Bugfix: Create bookingcampaign via DB and view as teacher.

## Version 8.2.8 (2024042900)
* Bugfix: Cashiers can still overbook when waitinglist is full

## Version 8.2.7 (2024042600)
* Improvement: Clean up ical settings and remove deprecated handling of options with single-session.
* Improvement: Mark invisible optiondates in entity calendar (gray and with [invisible] prefix).
* Improvement: Make sure that only authorized users (with capability booking:canseeinvisibleoptions) are able to see invisible options in entity calendar.
* Improvement: Create method to destroy instance of user object (because of fails in phpunit tests).
* Improvement: Make sure entities are restored for optiondates when duplicating courses and kept when recreating new date series.
* Improvement: Always show title with prefix.
* Bugfix: Move context_system to context_module.
* Bugfix: Fix customform.
* Bugfix: Fix possible problem with missing titleprefix.
* Bugfix: Fix validation of course category when creating new Moodle course together with booking option.
* Bugfix: Fix credits when there is also a price.
* Bugfix: Fix deprecation warning.

## Version 8.2.6 (2024042200)
* Improvement: New php unit tests and behat tests and improvements for existing ones.
* Improvement: Add book anyone capability.
* Bugfix: Fix missing $bookingsettings in function after_successful_booking_routine of class booking_option.

## Version 8.2.5 (2024041700)
* New feature: Shortcode [courselist cmid=23]
* Bugfix: feature addtogroup working now
* Improvement: Add a lot of new phpunit tests

## Version 8.2.4 (2024041100)
* Improvement: Migrate placeholders in message controller to new placeholder classes.
* Improvement: Separate string params from placeholder param {changes}.
* Bugfix: Profile picture is destroyed by format_text so do not use it in placeholders_info but only directly where we need it.
* Bugfix: Try to fix strings for AMOS.
* Bugfix: Add missing !empty check for datafromevent property.

## Version 8.2.3 (2024041000)
* New feature: Show attachments right within booking options.
* New feature: New setting to also duplicate Moodle course when a booking option gets duplicated.
* New feature: Send copies of mails for custom messages or for bulk custom messages via booking rules.
* New feature: Context-based booking rules (e.g. rules for a specific Booking instance).
* Improvement: New event custom_message_sent.
* Improvement: New booking rule action send_copy_of_mail.
* Improvement: Allow search for ID without pattern matching. (Will also work with numeric last names in behat tests.)
* Improvement: Allow search for full course id and booking option id in autocompletes.
* Improvement: Purge bookingoptionstable cache when encodedtables are purged.
* Improvement: New send_copy_of_mail action will only be shown for compatible events.
* Improvement: Fix eventlog to better reflect booking of other users.
* Improvement: Allow waitinglist for paid options.
* Improvement: Get rid of outdated shorturl field.
* Improvement: Several improvements and fixes for the new placeholders.
* Improvement: Possibility to confirm users which are on waitinglist with price.
* Improvement: Show hint for new placeholder {eventdescription} and show optionid in event description.
* Bugfix: Some small bugs in editteachersforoptiondate form.
* Bugfix: Report.php (user bookings page) cannot use the same pagination value that is used for Booking view - fixes #439.
* Bugfix: Possible bugfix for strange nullpointer bug on name property of module.
* Bugfix: Avoid error if class does not exist in fields_info.php.
* Bugfix: Bugfixes for waitinglist with price.
* Bugfix: Nullpointer bug in notifymelist.
* Bugfix: Fix Exception - Warning: Undefined array key "freeonwaitinglist".
* Bugfix: Fix is_available of fullybooked.php.

## Version 8.2.2 (2024040200)
* New feature: New setting to allow responsible contacts to edit booking options.
* Improvement: Issue #407 blocks booking via moodle capability
* Improvement: Add cancel for bought items.
* Improvement: Allow Filter a users bookingoption for more than one booking status param
* Improvement: Better way to check for price.
* Improvement: Apply rules again after every time a user has booked (only for option & userid).
* Improvement: Make bookit button accessible via TAB - fixes #436.
* Bugfix: Cancel myself not shown on reserved items.
* Bugfix: Description is actually a necessary field
* Bugfix: Several fixes for missing cmid in formdata when creating context_module.
* Bugfix: Add missing empty check for capability string identifier.
* Bugfix: Fix some minor errors in subbookings - fixes #356.
* Bugfix: Debug Booking rules.
* Bugfix: Fix error "ERROR:  column u.userid does not exist" which affects booking rules #445.
* Bugfix: Fix CSV import for entities.
* Bugfix: In confirmcancel we need to check useprice from JSON. (Price item check is legacy.)
* Bugfix: Switch from counting priceitems to just check useprice.

## Version 8.2.1 (2024032700)
* Improvement: Show which form currently overrides the standard form definition on edit.
* Improvement: Usability improvements for option form config with and without PRO license.
* Improvement: Allow csv import with column username.
* Improvement: Add capability to edit option form config (mod/booking:editoptionformconfig).
* Improvement: Add more rights to manager role (manager should have the same rights as enrolled teacher).
* Bugfix: Add enrolmentstatus field again.
* Test: New behat tests for Booking rules.

## Version 8.2.0 (2024032500)
* New feature: Config Dashboard implementation.
* New feature: Add manually managed waitinglist.
* Improvement: New Webservice to save config forms - unfinished.
* Improvement: Adjust incompatibilities of option form fields.
* Improvement: Better treatment auf where array values.
* Improvement: Support for new configurable Wunderbyte Table filters.
* Improvement: Move to contextids instead of coursecategoryids.
* Improvement: Use capabilities to adjust option form.
* Improvement: Get rid of old expertform mode.
* Improvement: Issue #407 blocks booking via moodle capability.
* Improvement: Make config sortable & add delete functionality.
* Improvement: Add possibility to turn off single customfields.
* Improvement: Use new WB Table functionality for using filters.
* Improvement: Add optionformconfig to context 1 (systemwide).
* Improvement: Allow cachier to book users from waitinglist, if it's a "confirm waitinglist" setting.
* Improvement: New booked users information with wb table.
* Improvement: More efficient handling of actions.
* Improvement: Show booked users only if there are some.
* Improvement: Add edit component to tables.
* Improvement: New setting for Booking debug mode.
* Improvement: Add debug event for send_mail_by_rule_adhoc.
* Improvement: New language strings.
* Bugfix: Fix deprecation warning for usort.
* Bugfix: Make sure html tags won't destroy the functionality.
* Bugfix: Implement new WB Table API.
* Bugfix: Drag & drop only for waitinglist.
* Bugfix: Fix errors in datepickers.
* Bugfix: Crucial Bugfix for booking process.
* Bugfix: Fix askforconfirmation booking button.
* Bugfix: Confusion between optionid & id.
* Bugfix: Fix option config form.
* Bugfix: Add missing cache definitions.
* Bugfix: Fix #447.
* Bugfix: Don't try to create event if optiondatesid is 0.
* Bugfix: Only access waitforconfirmation if it is set.

## Version 8.1.40 (2024031801)
* Bugfix: If shoppingcarthistory already has a canceluntil date set it may not be overriden by the option's canceluntil date again!

## Version 8.1.39 (2024031800)
* Improvement: Make save and cancel buttons in edit forms sticky at bottom.

## Version 8.1.38 (2024031400)
* Improvement: Accelerate view page via lazy loading.
* Improvement: Meeting link buttons should have secondary color.
* Bugfix: Service period currently always needs to be courseendtime.
* Bugfix: Accelerate slow teacher page.
* Bugfix: don't render all tables to show teacher page.

## Version 8.1.37 (2024031300)
* Bugfix: Fix privacy provider.
* Bugfix: Fix special fields for optiondates (Teams meeting, Zoom meeting...).
* Improvement: Several improvements for sign-in sheet, including better display of e-mail addresses and line breaks for too long titles.
* Improvement: Better debugging for errors with availability json.
* Improvement: Setting to not count users with presence status "no show" for max. number of bookings per instance.

## Version 8.1.36 (2024031200)
* Improvement: New settings for max. per user and improvements to general settings.
* Tests: New phpunit tests for reminder mails and teacher reminders.

## Version 8.1.35 (2024031100)
* Bugfix: No need to destroy singleton when creating new booking instances.
* Bugfix: Add missing strings (assesstimestart, assesstimefinish).

## Version 8.1.34 (2024030801)
* Improvement: Only use cached data for enrolled in course check.
* Improvement: Make sure calendar events are always stored as optiondates.
* Improvement: Get rid of old form modes (toggle between simple and expert form).
* Improvement: New function to purge all booking instance caches and destroy booking instance singleton.
* Bugfix: Make sure institution stores only empty strings.
* Bugfix: Fix bugs with showlistoncoursepage field.

## Version 8.1.33 (2024030700)
* Improvement: Add possibility to format personal messages with HTML editor.
* Improvement: Make sure images in cards view always have the same height of 220px.

## Version 8.1.32 (2024030601)
* Improvement: Layout fix for cards.
* Improvement: Show "Choose..." string in autocompletes if value is missing.

## Version 8.1.31 (2024030500)
* New feature: New placeholder classes for better performance and maintainability.
* New feature: Show full entity name of each optiondate in optionview (booking option description).
* New feature: New setting for sync_waiting_list to keep users booked when reducing limits.
* Improvement: Import now works with "startdate" & "enddate" keys.
* Improvement: Inline modals (turn off modals functionality) will only work with list view.
With cards view, we always have modals.
* Improvement: Apply waitinglist on increasing maxanswers for booking option
* Improvement: Add string that modals cannot be turned off for new cards view.
* Improvement: When purging caches for option we also need to destroy singletons for booking option settings.
* Improvement: Show teachers emails to booked users only (with config setting).
* Improvement: Better strings.
* Bugfix: Add to Calendar needed to be in postsave mode.
* Bugfix: Set importing on true when noticing an import.
* Bugfix: Default boavenrolledincourse during import to OR, not AND, support for boavenrolledincourseoperator (Values OR, AND).
* Bugfix: Don't call add to calendar on template.
* Bugfix: Add isset check for addtocalendar.
* Bugfix: Don't block booking options without price with prepages.
* Bugfix: Destroy all instances of booking options when calling destroy_booking_option_singleton.
* Bugfix: Make sure we use correct context when creating booking option sql.
* Bugfix: Wrong settings were used on report.php.
* Bugfix: Use context_system if context_module can't be found (eg for template).
* Testing: Temporarily take out failing behat test - to be reintroduced.

## Version 8.1.30 (2024030400)
* Bugfix: Several fixes for indexes and foreign keys.

## Version 8.1.29 (2024030100)
* Bugfix: Fix for leap year bug.
* Bugfix: Pre- and Post-page conditions like "Bookingpolicy" should not block "allow_add_item_to_cart".
* Bugfix: Fix download.php of Booking view.

## Version 8.1.28 (2024022900)
* New feature: You may now switch between list and cards layout in Booking instance settings.
* Improvement: Change tab order an make all booking options tab the default.
* Improvement: showall should be the default tab - also in install.xml.
* Bugfix: Make sure menubar is always at correct position using CSS.
* Bugfix: We always want to see institution - regardless if entitity manager is installed or not.

## Version 8.1.27 (2024022800)
* Improvement: Better layout for new menu bar (we cannot show it at the top right, as this would lead to several layouting problems).

## Version 8.1.26 (2024022701)
* Improvement: In Booking, we show the edit button at the top right.
* New feature: New pencil button to directly edit booking options.

## Version 8.1.25 (2024022700)
* Improvement: Make alert to show which option is edited sticky at top.
* Bugfix: Missing cache definitions.
* Bugfix: Fix descriptionformat via upgrade.

## Version 8.1.24 (2024022600)
* Improvement: Better layout for table row.
* Improvement: Second sign-in sheet button for download only and layout improvements.
* Improvement: Linting and layout improvements for report.php and all_userbookings.php
* Bugfix: Fix language string for "general" in English language pack - closes #410.
* Bugfix: Also check for already reserved in allow_add_item_to_cart.

## Version 8.1.23 (2024022301)
* Bugfix: Save availability on newly created option as well.
* Bugfix: Notification list is NO hard block!
* Improvement: Throw exceptions on import for better quality.

## Version 8.1.22 (2024022300)
* Bugfix: Fix allow_add_item_to_cart => do not block is_available anymore with notifyme-list.

## Version 8.1.21 (2024022200)
* New feature: Add new possibility to create new option or stay in edit option form after submit.
* Improvement: Show sub-entities and location from entity in sign-in-sheet.
* Improvement: Show signin sheet download button and area at more prominent place.
* Improvement: Get name for filter and address from entity manager.
* Improvement: Show an info alert in option form with option title, so we always know which option we edit.
* Improvement: Make sure we can only fill new options with template data, so existing options won't get overwritten.
* Improvement: Add Event to see if and possibly why afteractions failed.
* Improvement: Add Event to see if and possibly why afteractions failed
* Bugfix: For config settings, we always use 'booking' as plugin string.
* Bugfix: Add missing logic to addtocalendar field, so course calendar events will be created and deleted when saving form.
* Bugfix: For plugin settings, we use 'booking' not 'mod_booking'.
* Bugfix: If maxanswers are 0 the option is unlimited, so is_fully_booked has to always return false in this case.
* Bugfix: Don't override address & location if entities exist.
* Bugfix: Fix Webservice importer (bookingopening & closingtime etc).
* Bugfix: Remove broken mobile app support.
* Bugfix: Fix behat (button "Save and go back" was renamed to "Save").

## Version 8.1.20 (2024021900)
* Improvement: priceisalwayson setting will always block booking now.
* Improvement: Slightly better caching policy.
* Bufix: New wunderbyte constructor rules implemented.
* Bugfix: No warning when user in selectuser condition is deleted.
* Bugfix: Save and display bookingoptionimages & attachments.
* Bugfix: Visibility has to be public on bookingoptiondescription.
* Bugfix: Revert "Save lowest entity in location (not parent)".

## Version 8.1.19 (2024021601)
* Bugfix: Special availability import fixed

## Version 8.1.18 (2024021600)
* Improvement: Adoption of new wb table constructor
* Bugfix: Download bookings on report.php fixed, also for exactly one instance
* Bugfix: Active Bookingoptions are not yet finished or have finished today

## Version 8.1.17 (2024021401)
* Improvement: Add easy option form functionality.
* Improvement: Add reduced optionforms capabilities.
* Improvement: Every editing teacher has the right to see the standard form (default setting).
* Improvement: Add new table to store configs for forms.
* Improvement: Add option form config webservice.
* Improvement: Add necessary json class to make sure we don't lose json values even when the classes are not there.
* Improvement: Add alternative import strings to instantiate classes.
* Improvement: Add Pro Flag to report over all booking options feature.
* Improvement: Add eventslist field.
* Improvement: Better handling of empty $PAGE.
* Bugfix: Make sure prices are not set involuntarily on import.
* Bugfix: Fix dates import on Webservice and mergeparams.
* Bugfix: Make sure not to delete unaffected availability conditions.
* Bugfix: Fix merge error on feature branch.
* Bugfix: On webservice & ajax, always use the standard fields.
* Bugfix: Save lowest entity in location (not parent).
* Bugfix: Fix CSV importer.
* Bugfix: Fix issue #405.
* Bugfix: Make new option form logic work in easy availability modal.
* Bugfix: Do not show elective settings in form if instance is no elective instance.
* Bufix: Fix check for $PAGE.
* Bugfix: Lots of little fixes for option form and CSV import.

## Version 8.1.16 (2024021300)
* Bugfix: Make sure price does not get lost when using the CSV importer.
* Bugfix: Fix update of price and canceluntil.
* Bugfix: Make sure settings class is instantiated during import.
* Bugfix: Make sure location can be saved again.
* Bugfix: Make sure bookingopeningtime and bookingclosingtime do not get lost on import.
* Bugfix: Fix set_data functions for bookingopeningtime, bookingclosingtime and responsiblecontact.

## Version 8.1.15 (2024021200)
* Bugfix: Fix bug with wrong usage of strpos with "~" and "!~" operators.
* Bugfix: Fix booking_navigation_setting behat scenarios to use precise navigation element selector.
* Bugfix: Fix behat test - add datesmarker field.

## Version 8.1.14 (2024020900)
* Improvement: Show updated string for send custom message button.
* Improvement: Use less space for availability condition notification warnings.
* Improvement: Slightly smaller Moodle course button.
* Improvement: Do not execute fullybooked check if item is already in cart or already booked.
* Improvement: Only show dates when dates exist in option view. Also get rid of string duplicates.
* Improvement: Show responsible contact in change logs.
* Bugfix: Fix an exception when creating date series with no semester set.
* Bugfix: Make sure, we respect module visibility and activity restrictions on the booking instance - closes #385.
* Bugfix: Fix bugs with entities and optiondates when called with different form.
* Bugfix: Fix a bug when price was null ins save_from_form of price.php.

## Version 8.1.13 (2024020601)
* Improvement: Get rid of startendtimeknown param as it is legacy code.
* Improvement: Collapse the full description and do not show it twice.
* Bugfix: Text depending on status was not shown anymore at all.

## Version 8.1.12 (2024020600)
* Improvement: Better feedback for import.
* Improvement: Report with all booking answers - closes #386.
* Bugfix: Fix import for canceluntil #401.
* Bugfix: Fix wrong variable bug.
* Bugfix: Fix course enrolement.
* Bugfix: Loosen to strict import rules.
* Bugfix: Catch error for task.
* Bugfix: fix elective enrolement.
* Bugfix: Remove unnecessary redundancy.

## Version 8.1.11 (2024020100)
* Improvement: Styling of booking description in musi_table.
* Improvement: Harmonize and restore save (create) and delete functions for optiondates and remove redundancies.
* Improvement: For new optiondates we use the entity of the parent option as default.
* Improvement: Don't use the ? typecast to null for functions, as it's not yet supported in PHP 7.4.
* Improvement: Add no semester option.
* Bugfix: Fix context bug in optiondate class.
* Bugfix: Don't access entities constant without actually having called the handler.
* Bugfix: Don't trigger events when cmid is empty (as for global templates)
* Bugfix: Load responsible contact.

## Version 8.1.10 (2024013001)
* Bugfix: Add missing isset check in booking_handler.
* Bugfix: Fixed a bug that sent status change notifications to ALL users on waiting list.

## Version 8.1.9 (2024013000)
**Bugfixes:**
* Bugfix: Fix strings in behat tests.

**Improvements:**
* Improvement: From calendar events we now link to optionview.php.

## Version 8.1.8 (2024012901)
**Improvements:**
* Improvement: Show more information of availability conditions to users and fix some strings.

**Bugfixes:**
* Bugfix: Fix legacy code in option_optiondate_update_event and bookingoption_updated and use singleton service.
* Bugfix: Fix deletion and recreation of course events (uuid is used to store optionid-optiondateid pattern).

## Version 8.1.7 (2024012900)
**New features:**
* New feature: Add setting to collapse descriptions of booking options in table.
* New feature: Add possibility to set canceluntil date for individual booking options.

**Improvements:**
* Improvement: Improve performance on instances with a lot of options.
* Improvement: Cache "showdates" for much better performance.
* Improvement: Store useprice flag in JSON so that it works correctly.

**Bugfixes:**
* Bugfix: Change semester adHoc task threw an error when non existing courseid was defined.
* Bugfix: Setting the active booking options filter on end of this day, not time() will improve cached working.
* Bugfix: Do not save custom form condition if checkbox is turned off.
* Bugfix: Fix and improve canceluntil functionality and make sure that it works with cancelmyself (for options without price).

## Version 8.1.6 (2024012400)
**Improvements:**
* Improvement: Fix layout bugs with signin sheet.

## Version 8.1.5 (2024012200)
**Bugfixes:**
* Bugfix: Fix save_data function of option field "elective".
* Bugfix: Fix bugs in option field "actions".
* Bugfix: Fix bug in option field "addtogroup".
* Bugfix: Fix wrong usage of cmid in booking_option class.
* Bugfix: Fix change semester functionality (reset and create new optiondates).
* Bugfix: Fix several bugs with fields classes.
* Bugfix: Fix for dynamic custom fields that allow multiple values (multiselect).

## Version 8.1.4 (2024011900)
**Improvements:**
* Improvement: Improve quality of sign-in sheets.
* Improvement: Speed-up performance by deleting the right caches (booking answers cache instead of whole booking option cache).

**Bugfixes:**
* Bugfix: Fix "showdates" misbehavior as well as template creation issue - both caused by TinyMCE - so disabled it.

## Version 8.1.3 (2024011700)
**Bugfixes:**
* Bugfix: Fix button to allow booking of users who are not enrolled in course.

## Version 8.1.2 (2024011600)
**Bugfixes:**
* Bugfix: No userid needed in option_allows_booking_for_user (we always use logged-in user here).
* Bugfix: Fix exception for old options with only one date stored in the booking option.
* Bugfix: Fix automatic creation of new Moodle courses with new option form.

## Version 8.1.1 (2024011500)
**Improvements:**
* Improvement: React on changes in new booking_option update function.
* Improvement: phpunittest - bring back "dayofweek" in csv and assertion.

**Bugfixes:**
* Bugfix: Collapsible not opened properly.
* Bugfix: Make sure constants are present when needing them.
* Bugfix: Fix collapsible for bootstrap 4 & 5.
* Bugfix: Store correct info in dayofweek column.
* Bugfix: Add missing string for booking:view capability.
* Bugfix: Submit buttons not working in new option form - we comment them out for now.
* Bugfix: Fix a bug in booking_option.php where optionid was retrieved incorrectly.
* Bugfix: Semester not used from booking settings for new option.
* Bugfix: Fix for undefined property: stdClass::$addtocalendar booking_utils.php.
* Bugfix: No "id" in csv file. So if no ID provided we threat record as new and set id to "0".
* Bugfix: Fix warning because of null in explode.
* Bugfix: Fix broken cancel button in option form.

## Version 8.1.0 (2024011000)
**New features:**
* New feature: In Booking 8.1.0, we completely re-wrote the booking option form in a more modern and object oriented way.
This will allow us, to individually adapt the booking option form for differenct clients and use cases dynamically and easily.
* New feature: In Booking 8.1.0, we also changed the way templates work in the option form.
They are no longer filled out using JavaScript (which was quite buggy and incomplete) but we use the new classes for templates and CSV import too.
* New feature: In Booking 8.1.0, optiondates (sessions of an option) are created using a new dynamic form.
So you can now add entities, custom fields, comments and the number of days for session notifications directly to each date.
Also, you will now always have optiondates, even if there is only one session (so there is no need to show coursestarttime and
courseendtime of the booking option anymore).

**Improvements:**
* Improvement: Logs of little UI, Usability and layout changes to make the booking option form cleaner and more beautiful.
* Improvement: Recommendedin show only options where coursesendtime is > $now. (arg 'all' to turn off).
* Improvement: Lots of code quality improvements and linting (e.g. PHPdoc).

## Version 8.0.56 (2023122000)
**New features:**
* New feature: Shortcode [recommendedin] - Better default settings and new params for configuration.

**Improvements:**
* Improvement: If we have dates with "entity outliers" we show an additional checkbox to confirm overwriting.
* Improvement: Add and remove teachers only from future dates, but keep them in past dates - so we have a valid history.
* Improvement: Change string for changed behavior (teachers only added/removed for FUTURE optiondates).
* Improvement: Recommendedin show only options where coursesendtime is > $now. (arg 'all' to turn off)
* Improvement: Remove RELEASENOTES as it is redundant to CHANGES.md.

**Bugfixes:**
* Bugfix: Also purge encoded tables (wunderbyte table cache) when purging cache for a specific option.
* Bugfix: Only purge wbtable cache when a booking option gets updated. Not generally.
* Bugfix: Fix some strings for booking instance action logs.
* Bugfix: Fix behat.

## Version 8.0.55 (2023121100)
**Bugfixes:**
* Bugfix: Add missing string 'semesterid'.
* Bugfix: Fix a bug that lead to teacher notifications not being sent anymore.

## Version 8.0.54 (2023120700)
**Improvements:**
* Improvement: Refactor action names for wbtable.
* Improvement: Make sure wbtable container is aligned left by adding left margin of 0 (ml-0).

**Bugfixes:**
* Bugfix: Fix bug with duplication of booking instances when optionid or userid of teacher is missing or cannot be mapped.

## Version 8.0.53 (2023120400)
**New features:**
* New feature: Show booking opening and closing time in all relevant views and add possibility to sort by them.
* New feature: Filters for booking time and course time.

**Improvements:**
* Improvement: No reload button on teacher page and no login required for table.
* Improvement: Links in entity calendar now point to preview page (optionview.php).
* Improvement: No entity shortname on booking option preview page (optionview.php).

**Bugfixes:**
* Bugfix: Fix {teachers} placeholder.
* Bugfix: Add some fixes for course calendar events and refactor some legacy code.

## Version 8.0.52 (2023112800)
**New features:**
* New feature: Add possibility to set default sort order for booking instances.
* New feature: Choose date field for cancellation period, new fields: bookingopeningtime, bookingclosingtime.

**Improvements:**
* Improvement: Make sure, we never send mails for invisible booking options.

**Bugfixes:**
* Bugfix: All plugin constants must start with uppercase frankenstyle prefix.
* Bugfix: Remove table prefix and use curly brackets.

## Version 8.0.51 (2023112700)
**Improvements:**
* Improvement: Add sortby and sortorder to recommendedin shortcode.
* Improvement: Stop hiding default Moodle menu entries.
* Improvement: Fixed and improved functionality to create new dates for a semester.
* Improvement: Add capability "viewreports" to manage responses.

**Bugfixes:**
* Bugfix: Recommended table doesn't lose sorting etc.
* Bugfix: Fix format_text so filters will work with text depending on option status.
* Bugfix: Refactor pass data to js.
* Bugfix: Pass JSON using base64 encoding.
* Bugfix: If a booking instance is hidden, we do not show it on teacher pages.

## Version 8.0.50 (2023112201)
**Bugfixes:**
* Bugfix: Fix potential empty arrays in settings.php.

## Version 8.0.49 (2023112200)
**New features:**
* New feature: Show unsubscribe link in notification mails.

**Improvements:**
* Improvement: Added support for Moodle 4.3 and PHP 8.2.
* Improvement: Do not send notification mails and remove user from notification list if booking option is already over.

**Bugfixes:**
* Bugfix: Cashier always has to be able to book options without prices - even when blocked by a condition.

## Version 8.0.48 (2023111300)
**New features:**
* New feature: Campaign Limits take into account overbooking at the time of campaign start and add overbooked places to limit.

**Improvements:**
* Improvement: Some improvements to new cost center feature.
* Improvement: Code quality: Always use int and bool - never integer or boolean.
* Improvement: Get rid of deprecated institutions autocomplete js.

**Bugfixes:**
* Bugfix: Make sure that booking and cancelling of options without a price is possible even when shopping cart is installed.
* Bugfix: Fix bugs with prepages (both modal and inline) in combination with new cost center feature.
* Bugfix: Fix behat tests and issues related to prepages (both modal and inline).
* Bugfix: Fix error "Exception - Warning: Undefined array key "serviceperiodstart".
* Bugfix: Fix Javascript for Prepage Modals.
* Bugfix: Add shoppingcartisinstalled to example json.
* Bugfix: Fix normal booking button js.
* Bugfix: fix prepage JS for multiple tables on one page.
* Bugfix: Fix namespaces.
* Bugfix: Fix param definition in external services.

## Version 8.0.47 (2023110200)
**New features:**
* New feature: Introduce a new setting to tell booking which booking option custom field is used to store the cost center for each booking option.
In shopping cart, a new setting can then be activated to avoid booking of items with different cost centers.

## Version 8.0.46 (2023102000)
**New features:**
* New feature: Add new blocking campaign which allows to block booking for students depending on booking status (e.g. half of places gone).
* New feature: Actions logs for booking options.
* New feature: Actions logs for booking instances.

**Improvements:**
* Improvement: Show users and teachers in autocomplete in one single line.
* Improvement: Better campaign strings.
* Improvement: Complete re-writing of sync_waiting_list with singleton, etc.
* Improvement: Missing hours and substitutions for teachers in instance report work better now.

**Bugfixes:**
* Bugfix: Booking of any users feature was broken - used user preferences to fix it.
* Bugfix: Fix broken automatic loading of custom field values in campaign modal.
* Bugfix: Fix some strings for github actions.
* Bugfix: Make sure we have a string to replace, for str_replace in message_controller.
* Bugfix: When we use format_text, we need to set $PAGE->context first!
* Bugfix: Empty select on settings.php.

## Version 8.0.45 (2023101300)
**Improvements:**
* Improvement: booking_check_if_teacher function can now be used with optionid too.
* Improvement: Better user selectors for teachers.
* Improvement: Availability info texts now work on optionview.php (booking option detail page) too.
* Improvement: Booking option detail page (optionview.php) can now be accessed without login.

**Code quality:**
* Linting: Example context for col_availableplaces and better param documentation for booking_check_if_teacher.
* Linting: Fix example context for col_availableplaces.
* Linting: No trailing comma allowed in JSON.
* Linting: Fix form-user-selector-suggestion.mustache for github actions.

## Version 8.0.44 (2023100900)
**New features:**
* New feature: Lock editing of substitution once the "reviewed" checkbox has been clicked.

**Improvements:**
* Improvement: New function to lazy load teacher list for autocomplete.
* Improvement: New template for smaller user suggestions in autocomplete.
* Improvement: Add responsible contact to booking option description.
* Improvement: Return educational units without label.
* Improvement: Access restrictions for "Go to Moodle course" now make more sense.
* Improvement: Add optiondatesteacherstable templates to mustache ignore list.
* Improvement: Make sure mailto link gets encoded correctly.
* Improvement: Fix signin sheets, only Lastname, Firstname, No profiletext anymore.

**Bugfixes:**
* Bugfix: Fixes for #325 (Pull request).
* Bugfix: Fix bug in event description.
* Bugfix: New teacher syntax.
* Bugfix: We need module context in the teacher substitutions form!
* Bugfix: Fix caching bug with substitutions table (optiondates teachers report).
* Bugfix: Fix some bugs with cmid and reloading of substitution report (optiondates teachers report).
* Bugfix: Fix broken behat tests (because of changed CSS selector).
* Bugfix: Fix warning if sendmail is not set.
* Bugfix: Use table row not table header in behat tests for substitutions.

## Version 8.0.43 (2023100300)
**Bugfixes:**
* Bugfix: Use semicolon in mailto function, not comma - for compatibility with some mail clients.
* Bugfix: Fix return type declaration for PHP7.4
* Bugfix: Linting: Switch to short array syntax [] instead of array().
* Bugfix: No more error message when a teacher substitution is reviewed.

## Version 8.0.42 (2023092700)
**Improvements:**
* Improvement: Make sure that cmid always is the one corresponding with the optionid for "showonlyone" links.

## Version 8.0.41 (2023092100)
**New features:**
* New feature: New tab "field of study" (PRO feature).

**Improvements:**
* Improvement: Add margins for bookit button areas.
* Improvement: Show countlabel for filter.

**Bugfixes:**
* Bugfix: No error on non existing option by because of callback.
* Bugfix: Do not use legacy get_user_status function anymore. We use the booking answers from singleton service now!
* Bugfix: Use right variablename ($itemid instead of $optionid) in is_available function call.

## Version 8.0.40 (2023091801)
**Bugfixes:**
* Bugfix: First tab in teachers table is active

## Version 8.0.39 (2023091800)
**Improvements:**
* Improvement: Add "fieldofstudy" tab & corresponding fucntionality.
* Improvement: Dont show hidden instances on teachers page.
* Improvement: Add operator to enrolled in courses condition to decide if at least one or all of them have to be met.
* Improvement: More behat tests.

## Version 8.0.38 (2023091500)
**Bugfixes:**
* Bugfix: Usernames were not shown correctly for some user because of missing rights in opiton form

## Version 8.0.37 (2023091401)
**Improvements:**
* Improvement: Use entity parent name in location, if existant.

## Version 8.0.36 (2023091400)
**New features:**
* New feature: It is now possible to turn off modals and book "inline".
* New feature: New shortcode [fieldofstudy].
* New feature: Disable cancellation for individual bookings.
* New feature: Disable cancellation for a whole booking instance.
* New feature: Disable cancellation of individual booking options or of the whole booking instance.

**Improvements:**
* Improvement: Create option date series via DB.
* Improvement: Some adjustments for PHP 8.2 and Moodle 4.2.
* Improvement: We add the price to every normal button when a) we can't book for others & b) when there is a price.
* Improvement: Style prices in subarea with h6.
* Improvement: Improve get_instance_of_booking_by functions (avoid db calls).
* Improvement: Speed up working of conditions.
* Improvement: Add singleton service for user price category to speed up things during a single call.
* Improvement: Code quality.

**Bugfixes:**
* Bugfix: Only call JS when records are found.
* Bugfix: Add missing JS and replace <a> with <div>.
* Bugfix: Fix prepage also for cashier.
* Bugfix: Shortcodes via webservices need the right imports.
* Bugfix: Fix errors when no user is found.
* Bugfix: Recreate build folder (grunt).

**Tests:**
* Test: Runtime optimizations and fixes for behat tests.

## Version 8.0.35 (2023090800)
**Bugfixes:**
* Bugfix: If boactions or jsonobject are not set, we set them to null.
* Bugfix: Before sending change notificaiton, we need to purge answer cache, so {status} placeholder will be updated correctly.
* Bugfix: Catch possible SMTP exceptions with email_to_user so send_confirmation_mails task does not fail anymore.

## Version 8.0.34 (2023090600)
**New features:**
* New feature: Calculate cancel until date from semester start instead of booking option start (coursestarttime).
* New feature: Use semester dates for service period in shopping cart.

**Improvements:**
* Improvement: Always gender using a colon (":").
* Improvement: Show tags for "PRO" and "Experimental" settings.

**Bugfixes:**
* Bugfix: Fix broken behat tests.
* Bugfix: Yet another fix for entity import via entity id - store entity name in location, NOT the entity ID (as this does not make sense).

## Version 8.0.32 (2023083000)
**Improvements:**
* Improvement: Teachers filter - Show lastname before firstname and separate with comma.
* Improvement: Show search, filter and sorting in wb-tables generated by shortcodes.

## Version 8.0.33 (2023083100)
**Improvements:**
* Improvement: Use singleton service to get users in autocompletes.
* Improvement: Better availability conditions update process (soft update - do not delete missing conditions).
  Only if checkbox (advcheckbox) is actually "0" they will be removed.
* Improvement: Add clean string function - in case we need it to remove special chars.

**Bugfixes:**
* Bugfix: Separate tablename with space so tests don't fail.
* Bugfix: Remove institution name from uniqueid of myinstitutiontable as it might contain special chars.
* Bugfix: Custom form cannot be overridable.

## Version 8.0.32 (2023083000)
**Improvements:**
* Improvement: Teachers filter - Show lastname before firstname and separate with comma.
* Improvement: Show search, filter and sorting in wb-tables generated by shortcodes.

**Bugfixes:**
* Bugfix: Use core function email_to_user instead of phpmailer_email_to_user and stop supporting multiple ical attachments.
* Bugfix: Fix potential caching problems with wbtables on view.
* Bugfix: Fix reload of my bookings table.
* Bugfix: Decode availability string instead of using strpos which is deprecated in PHP 8.1.
* Bugfix: Add !empty check for location value and add comment for issue #310 (re-write importer to support updates).
* Bugfix: If columns for download or view.php are missing we use all columns as fallback - closes #302.
* Bugfix: 'relateuserid' must be used with event::create().
* Bugfix: 'identifier' field added to pricecategories generator.
* Bugfix: Proper verification if option description has been set and trimming of it as well (empty string is valid).
* Bugfix: Fix get_options_filter_sql() method to really process searchtext parameter.
* Bugfix: Do not throw error message if location entity not found (like it IS in UI).

**Tests:**
* Test: New phpunit test to cover csv_import->process_data.
* Test: Add features to create booking semester for tests.

## Version 8.0.31 (2023082301)
**New features:**
* New feature: Custom forms for individual booking options (via availability condition) - e.g. for individual booking policies.

**Improvements:**
* Improvement: Better icon for "create options from optiondates" functionality.

**Bugfixes:**
* Bugfix: Fix add to cart when overbooking.
* Bugfix: Fix DB for new json column in table booking_options.

## Version 8.0.30 (2023082200)
**Improvements:**
* Improvement: Remove unused code artifacts for cleaner code.
* Improvement: Use singleton service for get_all_users_booked and make sure we always use the correct user id.
* Improvement: Create truly unique identifier and CSV import fixes for identifier.

**Bugfixes:**
* Bugfix: Make sure identifier of booking options is REALLY unique.
* Bugfix: Create entity relations for each optiondate with importer.
* Bugfix: Fix waiting list bug which deleted users if option was fully booked.
* Bugfix: Check if identifier is really unique in webservice importer.

## Version 8.0.29 (2023081600)
**Bugfixes:**
* Bugfix: Fix exception with $PAGE context modification and move function to new booking_context_helper class.

## Version 8.0.28 (2023081100)
**Improvements:**
* Improvement: Support mulitple teacheremails in csv import, separated by comma.
* Improvement: Always use singleton_service instead of instantiation for booking_option.
* Improvement: Always use singleton_service instead of direct instantiation for booking instances.
* Improvement: Better strings for feedback URL (pollurl) and teacher's feedback URL (pollurlteachers).

**Bugfixes:**
* Bugfix: Fix bug where customfields were not shown anymore.
* Bugfix: Fix page context modifications.

## Version 8.0.27 (2023080700)
**Bugfixes:**
* Bugfix: Allow loading of already loaded item (in case cache was invalidated)
* Bugfix: Fix semester caching and import of semester-based option date series.

## Version 8.0.24 (2023072101)
**Improvements:**
* Improvement: Cache a flag to check if we already have applied campaigns, so we don't do it several times.

**Bugfixes:**
* Bugfix: Closes #44 (local_shopping_cart bug) "Adhoc tasks fails on testing site".
* Bugfix: get_in_or_equal needs an array as input param.

## Version 8.0.23 (2023072100)
**New features:**
* New feature: Entity import now works with both full name or entity id.

**Improvements:**
* Improvement: Stop creating placeholder params from view.php for better performance and move the function to booking_option class.
* Improvement: Code quality: missing isset checks for iselective and maxcredits.
* Improvement: Decision: we only show entity full name in location field.
* Improvement: Renamed get_entity_by_id to get_entities_by_id (there can be more than one because of join with address table).

**Bugfixes:**
* Bugfix: Fixed initialization of pricecategoryfield setting if user profile fields were missing.
* Bugfix: Wrong check for is_elective().

## Version 8.0.22 (2023071700)
**Bugfixes:**
* Bugfix: Added string for message provider
* Bugfix: Fixed CSV Importer vor bookingopeningtime & bookingclosingtime

## Version 8.0.21 (2023071200)
**New features:**
* New feature: New settings to show teacher pages for not logged-in users and to show teacher e-mails to everyone.
* New feature: Turn off waiting list globally by config setting.
* New feature: New possibility to book with credits.
* New feature: Send direct mails via mail client to all booked users.

**Improvements:**
* Improvement: Cashier is now able to overbook booking options for other users (not herself).
* Improvement: Code quality: commented out deprecated functions.
* Improvement: Filter in Wunderbyte table inactive on loading.
* Improvement: Code quality: Rename col_text_link to musi_bookingoption_menu and move it to local_musi.
* Improvement: Use singleton service to retrieve users.
* Improvement: Better strings for book with credits settings.
* Improvement: Also allow access to connected Moodle course for teachers with 'mod/booking:limitededitownoption' capability.

**Bugfixes:**
* Bugfix: Fix error with missing username or email in message_controller.
* Bugfix: Fix wrong userid when cashier books for others with prepage modals.
* Bugfix: Fix the following error for subbooking: "Exception - Warning: Undefined property:
  stdClass::$id in [dirroot]/mod/booking/classes/subbookings/sb_types/subbooking_additionalperson.php on line 173"
* Bugfix: Fixed availability problem with subbookings that lead to unexpected errors with availability conditions.
* Bugfix: Fix prepage modal bug with subbookings and rename not_blocked to has_soft_subbookings.
* Bugfix: Normal subbookings are not overridable as they need to do a "soft block" so they appear in prepage modals.
* Bugfix: Make sure empty url does not trigger db request.
* Bugfix: Fix override conditions logic.
* Bugfix: With override conditions we need to check the ORIGINAL value!

**Tests:**
* Behat: 3 scenarios have been added to cover turning off branding and make teacher pages (teacher.php and teachers.php) available to not logged-in users and force the display of teacher e-mail addresses
* GitHub: fix of the Moodle CodeChecker errors.
* Behat: new scenario Add single subbooking option for a booking option as a teacher

## Version 8.0.20 (2023062600)
**Improvements:**
* Improvement: Some more funcationalities for webservice importer

## Version 8.0.19 (2023062200)
**Improvements:**
* Improvement: Fix deprecation warnings for PHP 8.1.
* Improvement: Moodle 4.2 has been added to the github workflow.
* Improvement: New PRO feature to turn off Wunderbyte logo and link.

**Bugfixes:**
* Bugfix: Fix for Moodle 4.2 compatibility - set userid in the event.
* Bugfix: Fix for Moodle 4.2 compatibility - legacy methods removed from event classes.
* Bugfix: When limiting to 0 participants sync_waiting_list() deleted answers.
* Bugfix: Notify list also needs to be an overridable condition.

## Version 8.0.18 (2023061600)
**Improvements:**
* Improvement: Code quality for elective.

**Bugfixes:**
* Bugfix: Missing check if instance is elective.
* Bugfix: Elective fix for DB: add necessary fields to install.xml
* Bugfix: If user is on notification list, we always need to show unsubscribe toggle bell.
* Bugfix: Fix error when not an elective.
* Bugfix: Fix missing $PAGE->context error.
* Bugfix: If an option gets deleted, we want option settings to return null - no debug message.
* Bugfix: Fixes for Github actions.
* Bugfix: elective modal - if cache expires, we need to reset it.

## Version 8.0.17 (2023061201)
**Bugfixes:**
* Bugfix: Fix elective combinations.

## Version 8.0.16 (2023061200)
**New features:**
* New feature: Elective functionality implemented

## Version 8.0.15 (2023060901)
**Bugfixes:**
* Bugfix: Context in booking_bookit was set incorrectly!

## Version 8.0.14 (2023060900)
**Improvements:**
* Improvement: Code quality, and new timespan filter on view.php

## Version 8.0.13 (2023060500)
**Improvements:**
* Improvement: Code quality, behat tests, mustache linting, PHPunit fixes and more.

## Version 8.0.12 (2023052400)
**Bugfixes:**
* Bugfix: Add require_once to avoid warning from campaign_info with shortcodes use.

## Version 8.0.11 (2023052200)
**Improvements:**
* Improvmenet: Add failed booking event when using shopping cart

## Version 8.0.10 (2023051700)
**Improvements:**
* Improvement: Adjustment of capabilities for better finetuning

## Version 8.0.9 (2023051200)
**New features:**
* New feature: Recommandation feature via shortcodes, to 'push' booking options in selected Moodle courses.

## Version 8.0.8 (2023042400)
**New features:**
* New feature: Booking campaigns - Reduce booking prices and increase booking limit for a specified time period for specific booking options.

**Improvements:**
* Improvement: Mustache linting for github actions.
* Improvement: New tabs for visible/invisible booking options. (Tabs will only be shown to users with 'canseeinvisibleoptions' capability.)
* Improvement: Added duplication and backup of subbooking options.

**Bugfixes:**
* Bugfix: Small SQL fixes for teachers instance report.
* Bugfix: Fix several bugs with subbookings and prepage modals.
* Bugfix: Fix broken entity backup.
* Bugfix: Fix bugs with continue button and prepage modals.

## Version 8.0.7 (2023040602)
**New features:**
* New feature: Additional person subbooking (still an experimental feature).
* New feature: New possibility to react on changes on teachers report via booking rules (e.g. to send e-mails).
* New feature: Introduce new {journal} placeholder to directly link to "substitutions / cancelled dates" (training journal).
* New feature: New config setting to force prices to be always turned on. Also added price validation.
* New feature: New possibility to review changes teachers report (substitutions / missing hours) via checkbox.
  Introduced new capability 'mod/booking:canreviewsubstitutions'.

**Improvements:**
* Improvement: Add help button for select users condition.
* Improvement: Added get_renderer function to singleton_service for improved performance.
* Improvement: Lots of little improvements to additional person subbooking.
* Improvement: Use new way to instantiate table from wunderbyte_table.
* Improvement: Migrated teachers report from table_sql to wunderbyte_table.
* Improvement: New behat tests.

**Bugfixes:**
* Bugfix: Lots of little bugfixes to additional person subbooking.
* Bugfix: Fixed an exception that occurred on self-cancellation of students.
* Bugfix: Undefined status for "confirm cancel" condition.
* Bugfix: Fix error in delete_item_task if no subbooking is found.
* Bugfix: German and English strings were mixed up for 'allowoverbooking'.

## Version 8.0.6 (2023032700)
**New features:**
* New feature: New "select users" availability condition.
* New feature: New possibilities for override conditions (e.g.: "fullybooked" can now be overriden if combined with "OR").
* New feature: Introduced a new setting to allow overbooking of booking options if a user has the "mod/booking:canoverbook" capability.

**Improvements:**
* Improvement: Define default pagination setting and use it.
* Improvement: Remove intro description from business card. It's now part of the new activity header.
* Improvement: Usability improvements for price formula and make price formula a PRO feature.
* Improvement: Added a helper function to check if a user is allowed to overbook an option.

**Bugfixes:**
* Bugfix: Fix 2 behat navigations' tests to use aria-label="Page" string obtained from Moodle core.
* Bugfix: Add default string to transform_msgparam function if msgparam is not found.
* Bugfix: MSGPARAM constants were not found in message_sent.php because of missing lib.php inclusion - closes #265
* Bugfix: Support both two-letter (German) and three-letter (English) abbreviations for date strings (date series).
* Bugfix: JS was lost on extra button conditions.
* Bugfix: Make sure import via CSV works.

## Version 8.0.5 (2023032100)
**Improvements:**
* Improvement: Differentiate between checkout and booking complete confirmation in header.
* Improvement: the $booking->get_pagination_setting() method introduced to get number of booking options per page for rendering.

**Bugfixes:**
* Bugfix: Add missing isset checks.
* Bugfix: Mustache's HTML validation fixes and little github styling.

**Testing:**
* Test: 2 behat scenarios have been added for testing settings.
* Test: 2 behat scenarios have been added for testing navigation - paging and filtering.

## Version 8.0.4 (2023032000)
**Improvements:**
* Improvement: Hide activity header on view confirmation page and show menu in full width.
* Improvement: Remove duration from bookingoption_description and put image into paragraph.
* Improvement: Remove unused attribute defaultdownloadformat.

**Bugfixes:**
* Bugfix: Fixed broken send reminder mails task.
* Bugfix: Remove wrong login function.

## Version 8.0.3 (2023031600)
**New features:**
* New feature: New placeholder {profilepicture} to add user profile picture to confirmation mails.

**Improvements:**
* Improvement: Added and updated behat tests.
* Improvement: Link to teachers page on report.php instead of user profile.

**Bugfixes:**
* Bugfix: Fix broken confirm activity functionality.
* Bugfix: Missing isset for $booking->bookingpolicy.
* Bugfix: Fixed errors found with behat tests.
* Bugfix: Fixed some mustache warnings.

## Version 8.0.2 (2023031500)
**New features:**
* New feature: Add possibility to book anyone - even if not enrolled (for site admins only).

**Improvements:**
* Improvement: Better invisibility label with eye icon.
* Improvement: Disable activity header in report.php.
* Improvement: Hide activity header on book other users page.

**Bugfixes:**
* Bugfix: Fix some bugs in automatic number generation of report.php.
* Bugfix: Add missing string 'nopriceisset'.
* Bugfix: Fix warning on deleting last item in shopping cart.
* Bugfix: Added isset check for missing bookingpolicy.

## Version 8.0.1 (2023031301)
**Improvements:**
* Improvement: If shopping cart plugin is not installed, but a price is set, we just show the price.

**Bugfixes:**
* Bugfix: Do not show attachments string if there are no attachments in booking instance.

## Version 8.0.0 (2023031300)
**New features:**
* New feature: New view.php now working with Wunderbyte Table (local_wunderbyte_table) with lots of improved features.
* New feature: Show text depending on status description right in new booking overview.
* New feature: Finished download for new view.php.
* New feature: Add possibility to configure fields for booking options download.
* New feature: Booking now supports prepagemodals with booking policy, a confirmation page and support for the "Book now" and "Add to cart" buttons.
* New feature: Re-implemented ratings, attachments and tag functionality for new view.php.
* New feature: Intelligent differntiation between price and no-price booking options.
* New feature: Implemented new "cancel myself" condition and settings.

**Improvements:**
* Improvement: Lots of improvements for the new view.php which now works with the local_wunderbyte_table plugin.
* Improvement: Set old features to DEPRECATED which will be removed (or replaced) in the future.
* Improvement: Remove deprecated JS stuff from view_actions.js - we only use it in report.php (as it breaks stuff in view).
* Improvement: Show Wunderbyte logo in footer.
* Improvement: Additional conditions now supporting booking, waiting list, confirmation of booking and cancelling and much more...
* Improvement: Harmonized and improved menus for Moodle 4.0 and higher.
* Improvement: Make fields of new view configurable.
* Improvement: Improved some strings.
* Improvement: Hide activity header using $PAGE->activityheader->disable() instead of CSS.

**Bugfixes:**
* Bugfix: Fix a bug where available places or minanswers were not shown correctly.
* Bugfix: Fixed broken ratings in report.php.
* Bugfix: Fix edit option link.
* Bugfix: Poll URL (feedback link) was never saved for booking options.
* Bugfix: Bookingid was missing in some tables because of incorrect array creation.
* Bugfix: Function booking_updatestartenddate was not called on CSV import.
* Bugfix: Fixed many tiny errors in the new prepagemodals.

## Version 7.9.0 (2023022000)
**New features:**
* New feature: Subbookings (not yet finished, but can be activated as preview).
* New feature: New overview page of booking options making use of Wunderbyte Table.
* New feature: Booking is now able to handle prices in combination with Wunderbyte Shopping Cart plugin.
* New feature: New teachers pages, teachers overview and teachers instance report now part of booking.
* New feature: Make cancelling of booking options work both the normal way as also the shopping cart way.
* New feature: Person sub-booking (still unfinished).
* New feature: New button linking to connected Moodle course (shown only, if user has booked or is admin).
* New feature: Turn off automatic moving up from waiting list after option has started.
* New feature: Sorting of booking options is now possible via new sorting feature (sorting options: prefix, title, start, location, institution).

**Improvements:**
* Improvement: Lots of layout and usability improvements, especially with menus.
* Improvement: New action menu.
* Improvement: If unlimited, we still want to see the number of bookings.
* Improvement: Better handling of the number of available bookings. Also including a manage responses link now.
* Improvement: Re-implemented lots of functionalities of the old view.php (some still missing, will be added in later versions).
* Improvement: Improved optionview.php and got rid of old info modal.
* Improvement: Behat tests.
* Improvement: Added pre- and postpage logic for subbookings (still unfinished).
* Improvement: Collapse dates only if there are at least 3, several fixes, layout improvements.
* Improvement: Layout improvements, bugfixes, better menus.
* Improvement: Temporarily removed "move to other instance" feature until we are sure, it works.
* Improvement: Code style and code quality improvements.
* Improvement: Better condition alert colors.
* Improvement: Waiting list places will now also be shown in new view.php.
* Improvement: As of Moodle 4.0 activity description will be shown automatically in header, so we remove it form business card.
* Improvement: Better display of minimum number of participants (minanswers).
* Improvement: Better styling of teacher icons.

**Bugfixes:**
* Bugfix: Fix and improve option templates, menu entries and checkbox for limit answers.
* Bugfix: Delete booking_teachers artifacts when a booking instance gets deleted.
* Bugfix: Fixed a bug where users could not be booked for unlimited options and a wrong error message was shown.
* Bugfix: waitinglist < 2 for booking answers in viewconfirmation.php
* Bugfix: Fixed an issue with external functions.
* Bugfix: Fix faulty upgrade of subbooking answer table.
* Bugfix: Fix booking_time condition.
* Bugfix: Avoid js execution for alert buttons in conditions.
* Bugfix: Fix override conditions in form (combine availability conditions).
* Bugfix: Fix available places in option view and also show manage respones link there (admins only).

## Version 7.8.7 (2023012700)
**Bugfixes:**
* Bugfix: Fix navigation menu entry to delete booking option and add an entry to manage responses.
* Bugfix: Fix and improve option templates, menu entries and checkbox for limit answers.

## Version 7.8.6 (2023012600)
**Bugfixes:**
* Bugfix: Sending mail copies to the booking manager feature has been fixed.

## Version 7.8.5 (2023012500)
**Bugfixes:**
* Bugfix: Remove old institutions from restoring stepslib and fix crash.
* Bugfix: Placeholder {address} was showing address of user instead of address of booking option.

## Version 7.8.4 (2023012000)
**Improvements:**
* Improvement: Better code quality.

**Bugfixes:**
* Bugfix: Fixed caching problem with {status} placeholder.

## Version 7.8.3 (2023011600)
**Improvements:**
* Improvement: Shorter string for unlimited places.
* Improvement: Old institution functionality removed, as it is not needed anymore.

**Bugfixes:**
* Bugfix: Some elements were not hidden in simple mode.

## Version 7.8.2 (2023011300)
**Improvements:**
* Improvement: Prepare process_booking_price function in restore_booking_stepslib for new price areas.

**Bugfixes:**
* Bugfix: Purge caches after a user is added to a booking option.
* Bugfix: Fix duplication of booking instances by removing 'area' from set_source_table function.

## Version 7.8.1 (2023011200)
**Improvements:**
* Improvement: Add warning when you can only add users from one institution.
* Improvement: Deleted old teachers.php (not needed anymore).
* Improvement: Design improvements and improved code quality.
* Improvement: Some layout improvements for buttons, alerts and prices.

**Bugfixes:**
* Bugfix: Remove wrong capability check for user events in order to fix "nopermissiontoupdatecalendar" bug.
* Bugfix: Fixed an error in upgrade.php.
* Bugfix: Fix php 8 deprecation warnings (optional before required param).
* Bugfix: Fixed a bug in dynamicoptiondateform where JS was not passed.
* Bugfix: Fixed broken report reminders (custom reminder from report.php).

## Version 7.8.0 (2022122300)
**New features:**
* New feature: Add teachers directly in option_form.
* New feature: New possibility to set sorting order for price categories.

**Improvements:**
* Improvement: Get rid of old way to edit teachers.
* Improvement: When an option gets duplicated, teachers will get duplicated too.
* Improvement: When an option gets duplicated and we choose a new course, teachers now get enrolled into the new course.

**Bugfixes:**
* Bugfix: Fix bug where optiondate series were not created (js param missing).

## Version 7.7.9 (2022122100)
**Improvements:**
* Improvement: Further improvements to event-based rules (only tested combinations are supported).

**Bugfixes:**
* Bugfix: If the whole option was cancelled, we do not want to send status change mails.

## Version 7.7.8 (2022122000)
**New features:**
* New feature: New progress bars feature (PRO) including configuration in plugin settings.
* New feature: New booking rule condition to select user directly from event (affected user / triggering user).

**Improvements:**
* Improvement: Show booked, reserved, etc. users of a booking option via template.
* Improvement: Show  reserved & waitinglist users of a booking option via template on the "book other users" page.
* Improvement: Rule combination check and rule validation.

**Bugfixes:**
* Bugfix: Consumed quota - if option has not yet started, the quota is 0.
* Bugfix: Fix adding of calendar events for options without sessions (but with a "fake" session).
* Bugfix: Fix and improve cancel / undo cancel of booking options

## Version 7.7.7 (2022121500)
**New features:**
* New feature: get back consumed quota of booking option to local_shopping_cart service provider
* New feature: Support areas for local_shopping_cart service provider

## Version 7.7.6 (2022121300)
**Bugfixes:**
* Bugfix: Fix bug where canceluntil date was wrongly calculated from $now instead of $coursestarttime.
* Bugfix: Fix auto enrolment of teachers, improve defaults and automatic course creation.

## Version 7.7.5 (2022120900)
**New features:**
* New feature: Add setting to turn off creation of user calendar events, if wanted.
* New feature: Better German language strings ("Buchungen" instead of "Antworten").
* New feature: Turn messages off by entering 0.

**Improvements:**
* Improvement: Optimized and improved DB performance (added keys, indexes etc.)
* Improvement: Use caching for booking option description.
* Improvement: Better settings for automatic course creation category custom field.

**Bugfixes:**
* Bugfix: Fix problem with static functions
* Bugfix: Do not trigger bookingoption_updated when a booking option is cancelled.
* Bugfix: Fixed some errors in prettify_datetime.
* Bugfix: Typo in {eventtype} of fieldmapping.
* Bugfix: Correctly retrieve sessions via singleton_service of booking_option_settings.
* Bugfix: Dates spanning over more than one day did not show second date.
* Bugfix: Calendar events were created twice on creation of booking options.
* Bugfix: We need to purge option settings cache after updating.
* Bugfix: Fix a bug were options without dates showed Jan 1st, 1970.
* Bugfix: Fixed some bugs with automatic course creation.
* Bugfix: Fixed some behat test (issue #217).
* Bugfix: Fixed error string in CSV import.
* Bugfix: Fix missing userid in send notification mails task (function return_all_booking_information) - issue #218
* Bugfix: Optionid was missing when creating new sessions in optiondates.php (multi-session manager).

## Version 7.7.4 (2022120200)
**New features:**
* New feature: New placeholders from user profile:
  username, firstname, lastname, department, address, city, country.

**Improvements:**
* Improvement: Fixed and renamed placeholders: {times} are now {dates},
  introduced {teachers} for list of teachers, and fixed {teacher} and {teacherN}
* Improvement: Introduced price areas to support subbookings in the future.
* Improvement: several changes to optiondates handler.
* Improvement: Add missing capability strings.
* Improvement: Improve performance by more extensive use of caching.
* Improvement: Better function for condition messages.
* Improvement: Performance improvements in answers and option (user_submit_response)
* Improvement: Reduce sql for performance. Booking_answers class has now no further
  information about the users, apart from the id.
* Improvement: Add resilience to booking_answers class
* Improvement: Show titleprefix on "book other users" page.

**Bugfixes:**
* Bugfix: Fix a lot of little bug with booking rules.
* Bugifx: Fixed a param in toggle_notify_user webservice.
* Bugfix: Use correct message providers.
* Bugfix: fixed call of rule->execute()
* Bugfix: catch potential error on user deletion.
* Bugfix: Add userid to check_if_limit function to fix caching problem with booking answers.
* Bugfix: Small fix with user status function.
* Bugfix: first column not unique.

## Version 7.7.3 (2022112300)
**Improvements:**
* Improvement: Correctly use availability conditions in optionview.php
* Improvement: Add indexes to tables where necessary
* Improvement: Delete user events when booking option is cancelled and more.
* Improvement: Show manage responses in menu.

**Bugfixes:**
* Bugfix: Invalidate caches when a booking option is deleted.
* Bugfix: Adhoc tasks failed when booking options were deleted.
* Bugfix: Adhoc tasks failed when booking options were deleted.

## Version 7.7.2 (2022111600)
**New features:**
* New feature: Cancel booking options

## Version 7.7.1 (2022111400)
**New features:**
* New feature: Bew booking rule condition to select specific users via autocomplete.

**Improvements:**
* Improvement: More efficient implementation of rule conditions.

## Version 7.7.0 (2022111001)
**New features:**
* New feature: New booking rules allowing to differentiate between rules, conditions and actions.
  This is really cool and will enable booking to do great things in the near future!
* New feature: New event-based rules allosing to react to any booking option event.
* New feature: Cancelling of booking options without deleting them, the reason will be stored into
  internal annotations. Cancelling of booking options can be undone too.
* New feature: New rule condition allowing to enter the text to be compared (contain/equal)
  with a custom user profile field.

**Improvements:**
* Improvement: Collapsible overview of placeholders like {bookingdetails} for "Send mail" action of booking rules.
* Improvement: More beautiful menu of booking options in view.php.
* Improvement: New event bookingoption_cancelled is triggered when a booking option gets cancelled.

**Bugfixes:**
* Bugfix: When all optiondates were removed in optionform, they were not deleted at all.
* Bugfix: Fix type error in payment service provider.
* Bugfix: Restored Moodle 3.11 compatibility for booking rules.
* Bugfix: Minor code quality fixes.

## Version 7.6.3 (2022110400)
**Improvements:**
* Improvement: Improved conflict handling for entities at same date.
* Improvement: Better styling for customdates button.
* Improvement: For new options automatically check the checkbox to save entities for all optiondates.

**Bugfixes:**
* Bugfix: Fix entity conflicts for different areas (option / optiondate).

## Version 7.6.2 (2022110200)
**Bugfixes:**
* Bugfix: Fixed issue #213 - privacy provider get_contexts_for_userid() - MariaDB, SQL doesn't work.

## Version 7.6.1 (2022103100)
**Improvements:**
* Improvement: Use caching for serving images.

**Bugfixes:**
* Bugfix: Fix formula calculation with non iterable custom fields.

## Version 7.6.0 (2022102700)
**New features:**
* New feature: Entities can now be set for sessions of booking options (a.k.a. optiondates) too.
* New feature: Entities can conflict with each other if on the same date.

**Improvements:**
* Improvement: Entity shortnames (abbreviations like WBO for Wunderbyte Office) are now supported.
* Improvement: If an entity is set, we show it (name + shortname) instead of the value stored in "location".
* Improvement: Better handling of entities associated with booking options.
* Improvement: Better interface for optiondate manager.

**Bugfixes:**
* Bugfix: Duplication with conditions caused an error (optionid: -1).
* Bugfix: Fix undefined index for blocked events (start and endtime cannot be retrieved from string).
* Bugfix: Fix undefined index for blocked events (start and endtime cannot be retrieved from string).
* Bugfix: Postgres fix for teachers instance report.

## Version 7.5.5 (2022101200)
**New features:**
* New feature: Min. number of participants can now be set (currently only shown, no logic).

**Improvements:**
* Improvement: Add support for new shopping cartitem functionality (serviceperiodstart & end).
* Improvement: Header for "actions" in booking option cards settings menu.
* Improvement: New price formula setting to apply unit factor (is now set via config setting,
  not needed in price formula anymore).
* Improvement: Show educational units in tables and cards too.

## Version 7.5.4 (2022100500)
**Improvements:**
* Improvement: Booking rules => use classic moodleform so we can use editor.

## Version 7.5.3 (2022100400)
**New features:**
* New feature: New teachers report for booking instances,
  including courses (booking options), missing hours and substitutions.

## Version 7.5.2 (2022092901)
**Bugfixes:**
* Bugfix: Fix issue #212 - upgrade script for field 'availability' had wrong version number.

## Version 7.5.1 (2022092900)
**Bugfixes:**
* Bugfix: Fix language strings.

## Version 7.5.0 (2022092800)
**New features:**
* New feature: Global Roles (PRO) - Rules can now be added globally.
  The rule 'Send e-mail n days before a certain date' now allows to define
  to send e-mails n days before a certain date within an option (e.g. coursestarttime,
  bookingopeningtime...) to all users who have a custom profile field matching (or
  containing) the same value as a certain field of an option. The mail templates also
  support placeholders (e.g. {bookingdetails}).

## Version 7.4.3 (2022092700)
**Improvements:**
* Improvement: Added notification when a semester is saved in form.

**Bugfixes:**
* Bugfix: Fix bug where error was shown in optionformconfig_form.

## Version 7.4.2 (2022091902)
**Improvements:**
* Improvement: Restored holiday names.

## Version 7.4.1 (2022091900)
**New features:**
* New feature: Add user profile fields to e-mail params.

**Improvements:**
* Improvement: PRO availability conditions and info texts (and fixed correct order).

**Bugfixes:**
* Bugfix: Cleaning override of override concept
* Bugfix: Deal with missing attachments.
* Bugfix: If user profile fields are missing, we need to load them correctly.

## Version 7.4.0 (2022091500)
**New features:**
* New feature: New availability condition for custom profile fields.
* New feature: New performance report for teachers (performed hours/units).
* New feature: CSV Import now works with "identifier" and "titleprefix".
* New feature:

**Improvements:**
* Improvement: New operators for user profile field availability condition.
* Improvement: Added German translations for availability condition strings.
* Improvement: Added titleprefix ("course number") for previously booked availability condition.
* Improvement: Migrate old option names containing separator and identifier and use new "identifier" field.
* Improvement: Better optiondates handling for quickfinder block (bookingoptions_simple_table).

**Bugfixes:**
* Bugfix: Do not show or count reserved and deleted bookings (view.php / coursepage_available_options).
* Bugfix: Fixed Moodle 3.9 compatibility issues.
* Bugfix: Missing titleprefix caused quickfinder block not to work.
* Bugfix: Fixed yet another waitinglist bug on view.php.
* Bugfix: Unique option names are not necessary anymore (we use identifier now).
* Bugfix: Better cachedef strings - closes #210
* Bugfix: Fixed an SQL bug.
* Bugfix: Fixed "isbookable" availability condition.

## Version 7.3.0 (2022090100)
**New features:**
* New feature: Booking availability conditions introduced.
* New feature: New report for teachers (performed units).
* New feature: Manage instance templates (from plugin settings).
* New feature: New setting to round prices after price formula application.

**Improvements:**
* Improvement: Price formula - add support for multiple custom fields.
* Improvement: get_options_filter_sql function now support userid and bookingparam (booked, waitinglist etc.)
* Improvement: More intuitive and simpler holidays interface.
* Improvement: Better displaying of prices.
* Improvement: Now allowing up to 100 option dates.
* Improvement: Search in view.php is now case-insensitive.
* Improvement: Correct feedback when teacher user does not exist (in CSV import).
* Improvement: New scheduled task to clean DB and better task names.
* Improvement: Better string for invalid link (for booked meetings, e.g. teams customfield).
* Improvement: Add possibility to fetch filtersql for special user with booked params.

**Bugfixes:**
* Bugfix: Fix mybookings view to not show reserved and deleted bookings.
* Bugfix: Fix issue #193 (stuck on settings page).
* Bugfix: Correctly delete entries in booking_optiondates_teachers for 'change semester' function.

## Version 7.2.7 (2022080900)
**New features:**
* New feature: Added booking opening time (can be used like booking closing time).

**Improvements:**
* Improvement: New event listener for price category identifier changes updates prices of booking options automatically.
* Improvement: Also delete header images from DB when deleting an instance.#
* Improvement: Added a warning text for semester change.
* Improvement: Better display of course duration (days, hours, minutes).
* Improvement: Better display of search button.

**Bugfixes:**
* Bugfix: Fixed 'book other users' feature of booking (broken since 'unreal' deletion of booking answers).
* Bugfix: Booked out courses may not be bookable.
* Bugfix: Fixed some bugs with simple / expert mode and showing entitities.
* Bugfix: Bugfix where canceluntil didn't work on negative values (after course started).
* Bugfix: Fix errors in create_option_from_optionid.

## Version 7.2.6 (2022072500)
**New features:**
* New feature: Prevent option from recalculating prices.
* New feature: Cancel for all participants.
* New feature: Image duplication (both for options and booking instance header images).

**Improvements:**
* Improvement: Correctly delete image files when deleting booking options.
* Improvement: Duplication of images for individual booking options now working wiht backup/restore.

**Bugfixes:**
* Bugfix: When duplicating or restoring options create new random unique identifiers.
* Bugfix: Fix sql problem in the book for others panel.
* Bugfix: Correct duplication, restoring and deleting of custom fields.
* Bugfix: Fix SQL bug for image files.
* Bugfix: Fix SQL comma bug with get_options_filter_sql.

## Version 7.2.5 (2022071801)
**Improvements:**
* New price calculations with entity factor from entity manager.

**Bugfixes:**
* Hotfix - Missing quote character in install.xml.
* Added missing "dayofweek" in backup.

## Version 7.2.4 (2022071800)
**New features:**
* Added automatic course creation.
* Added price calculation for all options of instance.

**Improvements:**
* Updated automated tests config for M4.
* Performance improvement for construction of booking_settings.
* Added missing language strings.

**Bugfixes:**
* Fixed unit testing fail in externallib.
* Fixed possible error with price on guest view.
* Fixed postgres errors.
* Fixed broken commenting feature for booking options.

## Version 7.2.3 (2022070500)
**New features:**
* Calculate prices for specific booking options using a sophisticated JSON formula.
* Direct connection between booking instances and semesters.
* If we have a semester, only enrol from semester start until semester end.

**Improvements:**
* New identifier field for booking options.
* New annotation field for booking options for internal remarks and comments.
* New title prefix field for booking options (e.g. for non-unique course number).
* Show collapsible optiondates in all_options.php.
* Several improvements for handling of semesters.
* Implement user data deletion requests for Privacy API - closes #197
* Better notification button (for observer list), fixed toggle and improved strings for notification mails.

**Bugfixes:**
* Fix bug where no invisible was provided in webservice.
* Also create optiondates for new booking options.
* Added strings for Privacy API - closes #198

## Version 7.2.2 (2022062900)
**New features:**
* Internal annotations for booking options.

**Improvements:**
* Moved 'description' up to a more prominent place in booking option form.

**Bugfixes:**
* When no teacher was set for a booking option, teacher notifications were sent to participants.
* Fixed broken duplication of booking options.

## Version 7.2.1 (2022062200)
**Bugfixes:**
* Fixed bug relating to invisible options.
* Fixed bugs relating to (missing) entitities (removed dependencies to local_entitities).
* Fixed missing JavaScript.

## Version 7.2.0 (2022062100)
**New features:**
* Possibility to reduce booking option form to necessary elements only (configure simple mode).
* Toggle between simple mode and expert mode for booking option form.
* Notification list (observer list) functionality.

**Improvements:**
* Add support for returnurl for the booking options form

**Bugfixes:**
* Fixed an error with image URL.
* Make sure entities are only used when they are installed
* Fix some unset properties.
* Fixed bug in shopping cart where wrong price was taken.
* Fixed JavaScript for Moodle 4.0.
* Fixed broken URLs for Moodle 4.0.
* Commented out helpbuttons in repeat_elements groups as they cause problems with Moodle 4.0.
* Fixed navigation nodes for Moodle 4.0.

## Version 7.1.5 (2022060700)
**New features:**
* Added possibility to backup/duplicate/restore entities relations.

**Improvements:**
* If entity is set, we use it to set location and address.

**Bugfixes:**
* Restored correct order of upgrades.
* Fixed issue #190 (Upgrade fails) - https://github.com/Wunderbyte-GmbH/moodle-mod_booking/issues/190

## Version 7.1.4 (2022060200)
**Bugfixes:**
* If there are multiple image files with the same name, the first one found will be used.

## Version 7.1.3 (2022060101)
**New features:**
* Added possibility to import entities via CSV.

**Improvements:**
* Better language strings.

## Version 7.1.2 (2022060100)
**New features:**
* New teaching report (teaching journal) - allowing to define different teachers for each session, including export functionality-
* Change the semester for a booking instance - all dates of booking options will be generated newly for the selected semester.
* Added possibility to turn duplication / restoring of prices on and off in plugin settings (if turned off, default prices will be used)-

**Improvements:**
* Better presentation of teachers and link to profiles.
* Added prices to the backup routine, so they will be duplicated and backed up (if turned on in the plugin settings).

**Bugfixes:**
* Do not show separator and unique id in bookingoption_description.
* Fix a bug where the mobile service didn't get all booking options.

## Version 7.1.1 (2022050501)
**Improvements:**
* Add entities relation handler.

**Bugfixes:**
* CSV-import: add default value for column 'invisible'.
* Fix table sort order for PostgreSQL.
* Fix a bug where users couldn't see the corresponding prices.

## Version 7.1.0 (2022050400)
**New features:**
* New possibility to make options invisible for users without permission.
* Add and edit holidays (dynamic form).
* Create date series and take care of holidays.
* Add custom dates to date series (and support blocked events).

**Improvements:**
* Do not show list of booking options on course page by default.

**Bugfixes:**
* Fixed a CSS bug which disabled scrolling possibility.
* Hide dates title in signin sheet did not work correctly.

## Version 7.0.30 (2022042100)
**New features:**
* Add new config setting to include/not-include teachers.
* New default setting for addtocalendar with locking possibility.

**Improvements:**
* New dynamic semesters form.
* Add collapsible option dates to booking option description.
* New edit button in listofbookings and listofbookingscards.
* Improved sign-in-sheet with possibility to add columns for every optiondate.
* Display all prices for users which are not logged in.
* Take out shortcodes default instance.

**Bugfixes:**
* Fix a bug where prices were not imported.
* use no-reply email if no booking manager was set.
* Fix nullpointer when saving booking instances.
* department still missing in SQL
* Excel download not working with special characters.
* Missing minified files for sign-in-sheet.
* Fixed broken sessions in sign-in-sheet.
* Fix issue #185 - Error enrol users in scheduled task
* Fix missing {bookingdetails}-placeholder on viewconfirmation.php
* Option menu hidden behind top of table (if there's only one option).
* Fixed teacher duplication.
* Show images for users which are not logged in.
* Fix bug where edioptionsurl was specific to user who generated cache.
* Small fix if addtocalendar is not found in config.

**Other:**
* Fixed typo: subecribeusersctivity => subecribeusersactivity.

## Version 7.0.28 (2022032800)
**New features:**
* Add new shortcode 'mybookings'.

**Improvements:**
* Improve booking creation via singleton service.

**Bugfixes:**
* Fix a typo in settings.php which led to an error.
* Fix fallback to default image.
* Fix auto enrolment.
* Show 'booked' string when booked in booking option description.

## Version 7.0.27 (2022032601)
**New features:**
* New interface to add and edit semesters.
* Create date series with a string for reoccurring dates (e.g. 'Mo, 18:00 - 19:30').
* Upload images to booking options and show them in bookingoption_description.
* Image fallbacks: define images for a certain category (defined by custom field) and define a default image for booking options.
* New possibility to show a list of bookings (also as cards) via shortcodes.
* Display a booking option on a separate page (including possibility to buy the option, see the price etc.)

**Improvements:**
* Show booked places (instead of free ones).
* Added import of custom fields, dayofweektime string and prices to CSV importer (identified by keys).
* Refactoring for better performance.
* New singleton_service for better performance.
* Nicer presentation of booking options.
* Improved caching.
* Added collapsible description in manager view of block_booking.
* Better descriptions of booking options.
* Better date interface.
* Don't show 'booked' instead of available places.
* Added price and price category to booking option description.
* Only show booking-specific custom fields.

**Bugfixes:**
* Fixed a bug which broke the instance duplication feature.
* Fixed several bugs in caching.
* Fixed several rendering bugs.
* Added missing department to responses fields.
* Fixed badge styling.
* Fixed JS for modal loading.
* Do not show sports badge if no value exists.
* Display correct price in modal in buyforuser scenario.
* Fixed cashier's checkout.
* Fix in CSV-importer: Only run through prices if default column is present.

## Version 7.0.26 (2022021601)
**New features:**
* Nicer presentation of available places.

## Version 7.0.25 (2022021600)
**New features:**
* New sports badge
* Caching of shortcodes table data
* Show description modal in shortcodes pages

**Improvements:**
* Implement shopping cart & transition towards "unreal" deletion of booking_answers
* Support shortcode without category (returns all options)

**Bugfixes:**
* Fix a bug with PostgreSQL

## Version 7.0.24 (2022021500)
**Improvements:**
* Use message_controller for custom messages.

**Bugfixes:**
* Cancel button now works correctly.
* Wrong index in message logs of bookingoption_completed.
* Missing string in message logs of custom messages.
* Closed #183 - Inconsistancy between install.xml and upgrades

## Version 7.0.23 (2022020300)
**New features:**
* New shortcodes class enables dynamic embedding of new bookingoptions_table (using wunderbyte_table).
* Added prices to booking options.
* Show prices and action button in shortcodes table.
* Implement shopping_cart service provider & template.
* Added shopping cart functionality.
* Use new wunderbyte table caching.
* Better message logging: Sent messages get logged by Moodle event logger.
* Add possibility to choose currency globally via plugin settings.
* Add price categories to booking settings (including default category).
* Define a user profile field where the price category for each user is stored.
* Disable price categories and add default values.

**Improvements:**
* New settings classes for booking instances and booking options.
* Refactoring: New message controller class in charge of all notification e-mails.
* Placeholder {optiontimes} now works for both single and multisessions
* Add function to booking_option_settings to get display-text instead of text with separator.
* Use new wunderbyte_table with mustache.js support.

**Bugfixes:**
* Fixed broken view.php.
* Updated deprecated code.
* Book other users: Fixed a bug where selected users where not shown anymore.
* Fixed a bug where we had a duplicated admin page name.
* Fixed a bug where empty prices led to an error.
* Fixed customfields page.
* Fixed an infinite loop caused by message controller.
* Fixed message data preparation.

**Other:**
* Added behat tests.

## Version 7.0.22 (2021112900)
**Bugfixes:**
* Fixed a broken SQL statement which caused an error in the Quickfinder Block.

## Version 7.0.21 (2021112600)
**Bugfixes:**
* Fixed broken phpunit tests.
* Use correct version number for Moodle 3.11 compatibility.
* Fix bug where custom fields where not shown in modal.
* Remove obsolete $plugin->cron.
* Fix datestring to interpret HTML in coursepage_available_options template.

## Version 7.0.20 (2021111602)
**Improvements:**
* Added better feedback for CSV importer.

## Version 7.0.19 (2021110200)
**Bugfixes:**
* Fixed a bug where wrong poll url messages where sent (to both participants and teachers).
* Fixed a function in observer.php which didn't make sense.
* Fixed wrong inclusion of config.php in several files.
* Fixed deprecation of user_picture::fields in Moodle 3.11 and kept compatibility for 3.10, 3.9 and earlier.
* Fixed a bug where poll URL message was not sent to teachers.

## Version 7.0.18 (2021102500)
**Bugfixes:**
* Displaying booking option name now without separator on course page.
* Description for booked users was rendered like for unbooked in calendar.
* Fixed a bug where new bookingmanager list led to error on instantiation.
* Fixed deprecation of user_pictures in Moodle 3.11 and kept compatibility for 3.10, 3.9 and earlier.

## Version 7.0.17 (2021101900)
**Improvements:**
* Added "Department" to "Fields to display in different contexts" for report download.
* Minor code quality improvements.

## Version 7.0.16 (2021101800)
**Improvements:**
* Generic booking_options_simple_table (currently used by Bookings Quickfinder block).

## Version 7.0.15 (2021101500)
**Bugfixes:**
* Fixed deprecated implode => switch params.

**Improvements:**
* Removed "institution" from bookingoptions_simple_table (for compatibility with Bookings Quickfinder block).

## Version 7.0.14 (2021101300)
**Bugfixes:**
* Webservice only targets booking instances which are not in deletion progress.
* Minor code fixes.
* If sort by is set to coursestarttime but coursestarttime column is missing, we still order by coursestarttime.

## Version 7.0.13 (2021100400)
**Bugfixes:**
* Fix bug where calendar event was not created when course was set.

**Improvements:**
* Code quality: More logical deletion sequence.

## Version 7.0.12 (2021092900)
**Improvements:**
* Improved calendar event descriptions.
* Send status change notifications when limits (max. answers, places on waiting list) change.
* Turn off change notifications by setting the template to "0".
* Allow setting of bookingclosingtime via webservice

**Bugfixes:**
* Fixed a bug where a deleted user got 2 mails.

## Version 7.0.11 (2021092800)
**Improvements:**
* Improved availability info texts when events lie in the past.
* Bookings Quickfinder Block: number of participants, waiting list and manage responses in bookingoptions_simple_table.

**Bugfixes:**
* Always send emails from booking manager if a valid booking manager (needs to be an admin user) was defined.
  (Please keep in mind that you still need to set an outgoing noreply-address, add the domain of the booking
   manager's email to the allowed domains in outgoing email settings and set the booking manager's email address
   visible to all users in the user profile.)

## Version 7.0.10 (2021092700)
**Improvements:**
* Webservice: Add possibility to distinguish between courseid & targetcourseid
* Use uniqe booking option name with key for group creation

**Bugfixes:**
* Fix some bugs & potential bugs
* Fixed unwanted group creation

## Version 7.0.9 (2021092200)
**Improvements:**
* Only show "already booked" or "on waiting list" text in modal but not inline.

**Bugfixes:**
* Added missing fields in backup (duplication) of booking instances
* Fixed context and deletion methods in provider.php (Privacy API)

**Other:**
* Added RELEASENOTES, CHANGES and updated README

## Version 7.0.8 (2021092100)
**New features:**
* Sending of mails can be disabled by leaving the message template empty (Known issue: Currently only
  working with mails using the task send_confirmation_mails).

**Improvements:**
* Added metadata to classes/privacy/provider.php

**Bugfixes:**
* Removed "All places are booked" - as we already have new explanation string functionality (PRO) for available
  places and waiting list.
* Only show points in business_card and instance_description if there are any.

## Version 7.0.7 (2021092000)
**Improvements:**
* Added ids to rows in booking options search, so they can be hidden via CSS if needed.
* Booking instance description and business card enhancements.

**Bugfixes:**
* Fixed a bug with unique option names (Offset issue: only do "explode" if separator is part of the option name.)

**Other:**
* Introduced new table bookingoptions_simple_table which will be used by the new Booking Quickfinder block.
* Introduced CHANGES.md

## Version 7.0.6 (2021091400)
**Bugfixes:**
* Fixed a bug where courseid was always set to 0 when adding new booking options.

## Version 7.0.5 (2021091000)
**New features:**
* New cohort and group subscription (within "Book other users") for booking options.
* Unique option names
  When using CSV import for booking options, option names need to be unique. If there are multiple options with the
  same name, a unique key will be added internally to the option name. In the plugin settings, you can now define the
  separator (default: #?#) between the option name and the key.

**New PRO features:**
* Availability info texts for booking places and waiting list
  Instead of showing the numbers of available booking places and waiting list places, you can now go to the plugin
  config and activate availability info texts (you can activate them separately for available places and waiting list
  places). You can also define a percentage for the places low message. If the available booking places reach or get
  below this percentage a booking places low message will be shown. (You need to activate this feature with a PRO
  license.)

**Bugfixes:**
* Hide list of custom fields in booking option description when there are none.

## Version 7.0.3 (2021090800)
**Improvements:**
* New redirect script which fixes links that didn't work before (e.g. links in MS Outlook event texts
  after importing via {usercalendarurl}).
* Add teachers to booking option description.

**Bugfixes:**
* Fixed a bug where $booking object was null.
* Fixed a bug where description was not shown whithout organizatorname.

## Version 7.0.1 (2021090600)
**Bugfixes:**
* Fixed a bug with the placeholders in the completion mails template.
* Completion mails will only be sent if setting for sending confirmation mails is active.
* Only update start end date (of booking options) depending on sessions IF there actually ARE sessions.

## Version 7.0 (2021090100)
**New features:**
* License key checker in plugin config to activate PRO version.
* New dropdown for calendar event types.
* Up to 3 individual custom fields for multiple date sessions with autocomplete functionality.
  (Including special functionality for "TeamsMeeting", "ZoomMeeting" and "BigBlueButtonMeeting").
* Show detailed description of booking option either via modal (little info button) or inline within the
  options table (can be configured in instance settings).
* Show a "business card" of the teacher who is defined via autocomplete "Organizer name" (instance setting).
* Send change notification mails (including new mail template and new placeholder {changes} which will
  create a summary of all changes made to the booking option. The summary includes explanation texts and
  "\[DELETED\]" and "\[NEW\]" strings for text-only mails.
* Links to video meetings will only redirect to the link of the video meeting 15 minutes before until
  the end of the session.
* Session reminder e-mails (Including new mail template and functionality to set the number of days before the
  session when the e-mail should be sent.)
* Show course name, short info and a button redirecting to the available booking options on course page.
  (Can be turned on in instance settings. Short info text is customizable.)
* New placeholders {usercalendarurl} and {coursecalendarurl} (can be used in e-mail templates) to enable
  subscription to Moodle calendar via Outlook or similar calendar tool. Subscription links are made not clickable
  (styled via CSS), because they should be copied and pasted.
* New placeholder {bookingdetails} for detailed booking description including session and custom field data.
* New placeholder {gotobookingoption} linking only to the booking option.
* Booking option completion e-mails
  When you change the completion status of a user on the "Manage responses" page to "completed", an automatically
  generated e-mail will be sent to the user(s) letting them know that they have completed the booking option.
  You can edit the template for this in booking instance settings.

**New PRO features:**
* Global mail templates - each booking instance can define its source of mail templates:
  (Option 1) From within the booking instance (default)
  (Option 2) Use global mail templates defined in plugin settings
  This feature allows you to define global mail templates within the plugin config and use them within every booking
  instance on the whole platform. (You need to activate this feature with a PRO license.)
* Teacher notification e-mails including a new mail template in booking instance settings, number of
  days before the event start to notify teachers and to new placeholders to include in the template:
  {numberparticipants}: The number of successfully booked participants for the option.
  {numberwaitinglist}: The number of people on the waiting list for the option. (You need to activate this feature
  with a PRO license.)
* Webservice importer - it is now possible to import a massive amount of booking options using a CSV file
  in combination with the new importer web service. (Web service will only work with a PRO license. Contact
  info@wunderbyte.at if you need support with that.)

**Improvements:**
* Added missing German localization strings.
* Improved calendar features - show events, booked events and multiple date sessions in Moodle calendar.
  Calendar events include detailed description (supporting multiple dates sessions) and a button linking to the
  booking option.
* Booking option is prefilled with "coursename - eventtype"-Scheme
* Added autocomplete dropdown for location, institution (in booking option settings)
  and event type, organizer name (in booking instance settings).
* It is now possible to add a list of available booking options to the course page (can be turned off
  in instance settings).
* Added classes to columns and buttons in order to enable individual CSS styling.
* Redirect to view.php instead of report.php after editing options or sessions.
* Added localized help buttons for organizer name, event type, institution and location.
* Add string when neither waitinglist nor booking is possible.
* New bookingoption_completed event gets triggered when completion status of a user changes.
* CSV importer now imports optiondates (multisession) & customfields for multisessions
* Show cancel button below booked button.
* Modal is showing the info if a user is already booked or on the waiting list for an option.
* When there are no multisessions defined, the {dates} parameter for notification e-mails will use the
  single date defined within the booking option.
* Added new fields to backup.
* Show button redirecting to the booking option at upper right of the calendar modal.
* iCal attachments including detailed summary of the booking option and improved session iCals.
  Known issue: Updating events still does not work as expected with Microsoft Outlook. If you rely on
  Outlook, please use calendar subscription with the e-mail placeholders {usercalendarurl} (or {coursecalendarurl})
  instead and turn iCal attachments off in the plugin settings.
* Also duplicate associated teachers on booking option duplication.

**Bugfixes:**
* Do not add option templates twice.
* Fixed wrong calculation of available places.
* Show "Save as template" only for new booking options, not for existing ones.
* Calculate duration if not set while saving.
* Update calendar events of sessions when a booking option is edited.
* Fix bug when addtogroup is not set on saving new instance templates.
* Fix bug where booking name (->text) was required unique not only in instance, but everywhere.
* Fixed autofill of option templates (JavaScript-based).
* Fixed autofill of instance templates (JavaScript-based).
* Fixed duplicate creation of option templates.
* Fixed missing link on {bookinglink} placeholder.
* Fixed issues in backup and duplication.
