// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @module     mod_booking/slotCalendarPicker
 * @copyright  Wunderbyte GmbH
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

import {createTimeFormatter, renderFixedSlotsEditor} from 'mod_booking/slotbooking/slot_day_renderers';
import {getString, getStrings} from 'core/str';

// Short weekday names in the viewer's locale, Monday first. Derived from Intl rather than a lang
// string, so they stay consistent with the month label (toMonthLabel below also uses Intl).
const buildWeekDays = () => {
    // 2024-01-01 was a Monday, so this walks Mon..Sun.
    const monday = new Date(2024, 0, 1);
    const formatter = new Intl.DateTimeFormat(undefined, {weekday: 'short'});
    return Array.from({length: 7}, (ignored, index) => {
        const day = new Date(monday);
        day.setDate(monday.getDate() + index);
        return formatter.format(day);
    });
};

const WEEK_DAYS = buildWeekDays();

// The picker builds its DOM synchronously, so labels start as English fallbacks and are swapped in
// once the string request resolves (usually instantly - core/str caches strings in the browser).
// The counting labels keep their placeholders, so a translation can put the numbers where its
// own word order needs them instead of forcing the English "3/5 selected" layout.
const DEFAULT_LABELS = {
    month: 'Month',
    week: 'Week',
    weekof: 'Week of {date}',
    pricelegend: 'Price legend:',
    slotcount: '{count} slots',
    selectedcount: '{selected}/{max} selected',
};

const LABELS_PROMISE = Promise.all([
    getString('slot_calendar_month', 'mod_booking'),
    getString('slot_calendar_week', 'mod_booking'),
    getString('slot_calendar_week_of', 'mod_booking', '{date}'),
    getString('slot_calendar_price_legend', 'mod_booking'),
    getString('slot_calendar_slot_count', 'mod_booking', '{count}'),
    getString('slot_calendar_selected_count', 'mod_booking', {selected: '{selected}', max: '{max}'}),
]).then(([month, week, weekof, pricelegend, slotcount, selectedcount]) => ({
    month,
    week,
    weekof,
    pricelegend,
    slotcount,
    selectedcount,
})).catch(() => ({...DEFAULT_LABELS}));

// Selection ring around a price dot: white inside so it stays visible on the active day's blue
// (btn-primary) cell, blue outside so it stays visible on the light cells. A box-shadow rather than
// a border: it is drawn outside the dot, so the dot keeps its full size.
const SELECTED_DOT_RING = '0 0 0 1.5px #ffffff, 0 0 0 3px #0d6efd';

const createDayKeyFormatter = (timezone) => {
    try {
        return new Intl.DateTimeFormat('en-CA', {
            timeZone: timezone || undefined,
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
        });
    } catch {
        return new Intl.DateTimeFormat('en-CA', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
        });
    }
};

const DEFAULT_DAY_KEY_FORMATTER = createDayKeyFormatter('');

const toDateKey = (timestamp, formatter = DEFAULT_DAY_KEY_FORMATTER) => {
    const parts = formatter.formatToParts(new Date(Number(timestamp) * 1000));
    const year = parts.find(part => part.type === 'year')?.value || '0000';
    const month = parts.find(part => part.type === 'month')?.value || '01';
    const day = parts.find(part => part.type === 'day')?.value || '01';
    return `${year}-${month}-${day}`;
};

const toDateKeyFromDate = (date) => {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
        return '';
    }

    const year = String(date.getFullYear());
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const toMonthLabel = (date) => {
    return date.toLocaleDateString(undefined, {month: 'long', year: 'numeric'});
};

const toMonthKey = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
};

const cloneDate = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
};

const getWeekStartDate = (date) => {
    const start = cloneDate(date);
    const weekday = (start.getDay() + 6) % 7;
    start.setDate(start.getDate() - weekday);
    return start;
};

const toWeekKey = (date) => {
    const weekStart = getWeekStartDate(date);
    const year = weekStart.getFullYear();
    const month = String(weekStart.getMonth() + 1).padStart(2, '0');
    const day = String(weekStart.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const noop = () => {
    return null;
};

export class SlotCalendarPicker {
    /**
     * @param {HTMLElement} root
     * @param {Object} options
     */
    constructor(root, options = {}) {
        this.root = root;
        this.slots = Array.isArray(options.slots) ? options.slots : [];
        this.maxSelection = Math.max(1, Number(options.maxSelection || 1));
        this.replaceWhenFull = Boolean(options.replaceWhenFull);
        this.onChange = typeof options.onChange === 'function' ? options.onChange : noop;
        this.onDayChange = typeof options.onDayChange === 'function' ? options.onDayChange : noop;
        this.dayCountFormatter = typeof options.dayCountFormatter === 'function' ? options.dayCountFormatter : null;
        this.slotFilter = typeof options.slotFilter === 'function' ? options.slotFilter : null;
        this.emptySlotListText = options.emptySlotListText === undefined
            ? 'No open slots on this day.'
            : String(options.emptySlotListText);
        this.showSlotList = options.showSlotList !== false;
        // Caller-supplied day ("YYYY-MM-DD", the same format toDayKey()/dayKeyFormatter produce) to
        // reopen on instead of the usual defaults (today/the first bookable day, or a day the user is
        // already booked on - see prepareData() below). Used to restore the previously viewed day
        // after this picker gets re-created from scratch (e.g. slotBooking.js re-running
        // setupInteractiveUi() after a server validation error) instead of silently jumping back to
        // whichever day the defaults would otherwise pick.
        this.initialActiveDay = options.initialActiveDay ? String(options.initialActiveDay) : null;
        this.showPriceLegend = Boolean(options.showPriceLegend);
        this.dayStateResolver = typeof options.dayStateResolver === 'function' ? options.dayStateResolver : null;
        this.resetSelectionOnDayChange = Boolean(options.resetSelectionOnDayChange);
        // Whether to render the built-in "x/N selected" counter line. True for callers that own
        // their selection through this.selected (the report and move flows), where it is
        // authoritative. The booking flow's calendar + fixed-grid mode passes false: there the
        // selection is owned by the hidden slot_selection input (see condition/slotBooking.js), and
        // the count is shown - translated - in the selected-slots summary below the calendar
        // instead, so it must not appear twice.
        this.showSelectionInfo = options.showSelectionInfo !== false;
        this.timezone = String(options.timezone || '').trim();


        // Per-day slot representation: 'list' (flat buttons, built-in) or 'timeline' (the shared
        // proportional renderer also used by the booking flow). Defaults to the list.
        this.slotView = options.slotView === 'timeline' ? 'timeline' : 'list';
        this.timeFormatter = createTimeFormatter(this.timezone);

        this.viewMode = 'month';
        this.dayKeyFormatter = createDayKeyFormatter(this.timezone);
        this.selected = new Set(Array.isArray(options.initialSelection) ? options.initialSelection : []);
        // Keys of the user's currently booked slot(s). Marked distinctly from the (mutable)
        // selection so the booked slot stays visible while the user picks a new one.
        this.currentKeys = new Set(Array.isArray(options.currentKeys) ? options.currentKeys : []);
        // Keys of booked slots past their relative deadline: they stay selected and cannot be removed.
        this.lockedKeys = new Set(Array.isArray(options.lockedKeys) ? options.lockedKeys : []);
        this.currentLabel = options.currentLabel === undefined ? '' : String(options.currentLabel);
        this.lockedLabel = options.lockedLabel === undefined ? '' : String(options.lockedLabel);
        this.selectedLabel = options.selectedLabel === undefined ? '' : String(options.selectedLabel);


        this.slotsByDay = new Map();
        this.allDayKeys = [];
        this.availableMonthKeys = [];
        this.availableWeekKeys = [];
        this.activeDay = null;
        this.currentDate = new Date();
        this.priceLevels = [];
        this.priceScaleMin = 0;
        this.priceScaleMax = 0;

        this.labels = {...DEFAULT_LABELS};

        // The legend's labels come from the language pack - see loadLegendStrings().
        this.legendStrings = null;
        this.loadLegendStrings();

        this.prepareData();
        this.buildLayout();
        this.render();
        this.emitChange();

        LABELS_PROMISE.then(labels => {
            this.labels = labels;
            this.applyLabels();
            return;
        }).catch(() => {
            // Keep the fallback labels - a failed string request must not break the picker.
            return;
        });

        if (this.activeDay) {
            const activeDaySlots = this.slotsByDay.get(this.activeDay) || [];
            this.onDayChange(this.activeDay, activeDaySlots);
        }

        this.handleResize = () => {
            this.applyResponsiveStyles();
        };
        window.addEventListener('resize', this.handleResize);
    }

    prepareData() {
        this.currentDayKeys = new Set();
        this.slots.forEach(slot => {
            const key = slot.key || `${slot.start}:${slot.end}`;
            // Identity used for selection. In a merged multi-option calendar 'key' is time-only
            // and therefore identical across every merged option, so selecting one slot would
            // select that time in all of them; slot_dto supplies an option-scoped 'uid' there.
            // Callers with a single option (move, report) send no uid and keep using the key.
            const uid = slot.uid || key;
            const dayKey = toDateKey(Number(slot.start), this.dayKeyFormatter);

            if (this.currentKeys.has(key)) {
                this.currentDayKeys.add(dayKey);
            }
            const entry = {
                ...slot,
                key,
                uid,
                start: Number(slot.start),
                end: Number(slot.end),
                daylabel: slot.daylabel || dayKey,
                timelabel: slot.timelabel || `${slot.start} - ${slot.end}`,
                teachers: Array.isArray(slot.teachers) ? slot.teachers : [],
                bookings: Number(slot.bookings || 0),
                capacity: Number(slot.capacity || 0),
                bookable: Boolean(slot.bookable),
                price: Number(slot.price || 0),
                currency: String(slot.currency || ''),
                priceformatted: String(slot.priceformatted || '').trim(),
                openfrom: Number(slot.openfrom || 0),
                openuntil: Number(slot.openuntil || 0),
                startintervalminutes: Number(slot.startintervalminutes || 0),
                bookedranges: Array.isArray(slot.bookedranges) ? slot.bookedranges : [],
            };

            if (!this.slotsByDay.has(dayKey)) {
                this.slotsByDay.set(dayKey, []);
            }
            this.slotsByDay.get(dayKey).push(entry);
        });

        this.allDayKeys = Array.from(this.slotsByDay.keys()).sort();
        this.availableMonthKeys = [];
        this.availableWeekKeys = [];

        const monthSet = new Set();
        const weekSet = new Set();

        this.allDayKeys.forEach(dayKey => {
            const date = new Date(`${dayKey}T00:00:00`);
            monthSet.add(toMonthKey(date));
            weekSet.add(toWeekKey(date));
        });

        this.availableMonthKeys = Array.from(monthSet).sort();
        this.availableWeekKeys = Array.from(weekSet).sort();

        const priceSet = new Set();
        this.slotsByDay.forEach(daySlots => {
            daySlots.forEach(slot => {
                if (Number.isFinite(slot.price)) {
                    priceSet.add(Number(slot.price));
                }
            });
        });
        this.priceLevels = Array.from(priceSet).sort((a, b) => a - b);

        const positivePriceLevels = this.priceLevels.filter(price => price > 0);
        this.priceScaleMin = positivePriceLevels.length ? Math.min(...positivePriceLevels) : 0;
        this.priceScaleMax = positivePriceLevels.length ? Math.max(...positivePriceLevels) : 0;

        if (this.allDayKeys.length > 0) {
            this.activeDay = this.allDayKeys[0];
            const firstDate = new Date(`${this.activeDay}T00:00:00`);
            this.currentDate = cloneDate(firstDate);
        }

        // If we know where the user is currently booked, open the calendar on that day.
        if (this.currentDayKeys.size > 0) {
            const bookedDayKey = Array.from(this.currentDayKeys).sort()[0];
            if (bookedDayKey) {
                this.activeDay = bookedDayKey;
                this.currentDate = cloneDate(new Date(`${bookedDayKey}T00:00:00`));
            }
        }

        // An explicitly requested day (see initialActiveDay above) wins over both defaults above -
        // only when it actually still has data, so a stale/no-longer-relevant day never leaves the
        // calendar looking blank.
        if (this.initialActiveDay && this.slotsByDay.has(this.initialActiveDay)) {
            this.activeDay = this.initialActiveDay;
            this.currentDate = cloneDate(new Date(`${this.initialActiveDay}T00:00:00`));
        }
    }

    buildLayout() {
        this.root.innerHTML = '';
        Object.assign(this.root.style, {
            width: '100%',
            maxWidth: '100%',
            minWidth: '0',
        });

        const modalDialog = this.root.closest('.modal-dialog');
        if (modalDialog) {
            Object.assign(modalDialog.style, {
                width: 'min(900px, calc(100vw - 1rem))',
                maxWidth: 'min(900px, calc(100vw - 1rem))',
            });
        }

        this.container = document.createElement('div');
        this.container.className = 'booking-slot-calendar-ui border rounded p-2';

        this.toolbar = document.createElement('div');
        this.toolbar.className = 'booking-slot-calendar-toolbar d-flex justify-content-between align-items-center mb-2';

        this.leftControls = document.createElement('div');
        this.leftControls.className = 'btn-group btn-group-sm';

        this.prevBtn = document.createElement('button');
        this.prevBtn.type = 'button';
        this.prevBtn.className = 'btn btn-outline-secondary';
        this.prevBtn.textContent = '‹';
        this.prevBtn.addEventListener('click', () => this.shift(-1));

        this.nextBtn = document.createElement('button');
        this.nextBtn.type = 'button';
        this.nextBtn.className = 'btn btn-outline-secondary';
        this.nextBtn.textContent = '›';
        this.nextBtn.addEventListener('click', () => this.shift(1));

        this.leftControls.appendChild(this.prevBtn);
        this.leftControls.appendChild(this.nextBtn);

        this.title = document.createElement('div');
        this.title.className = 'fw-bold';

        this.modeControls = document.createElement('div');
        this.modeControls.className = 'btn-group btn-group-sm';

        this.monthBtn = document.createElement('button');
        this.monthBtn.type = 'button';
        this.monthBtn.className = 'btn btn-outline-secondary';
        this.monthBtn.textContent = this.labels.month;
        this.monthBtn.addEventListener('click', () => {
            this.viewMode = 'month';
            this.alignCurrentDateToAvailableView();
            this.render();
        });

        this.weekBtn = document.createElement('button');
        this.weekBtn.type = 'button';
        this.weekBtn.className = 'btn btn-outline-secondary';
        this.weekBtn.textContent = this.labels.week;
        this.weekBtn.addEventListener('click', () => {
            this.viewMode = 'week';
            this.alignCurrentDateToAvailableView();
            this.render();
        });

        this.modeControls.appendChild(this.monthBtn);
        this.modeControls.appendChild(this.weekBtn);

        this.toolbar.appendChild(this.leftControls);
        this.toolbar.appendChild(this.title);
        this.toolbar.appendChild(this.modeControls);

        this.calendarGrid = document.createElement('div');
        this.calendarGrid.className = 'booking-slot-calendar-grid mb-3';

        this.slotList = document.createElement('div');
        this.slotList.className = 'booking-slot-calendar-slots';

        this.selectionInfo = document.createElement('div');
        this.selectionInfo.className = 'small text-muted mt-2';

        this.priceLegend = document.createElement('div');
        this.priceLegend.className = 'small text-muted mt-2';

        this.container.appendChild(this.toolbar);
        this.container.appendChild(this.calendarGrid);
        if (this.showPriceLegend) {
            this.container.appendChild(this.priceLegend);
        }
        if (this.showSlotList) {
            this.container.appendChild(this.slotList);
        }
        if (this.showSelectionInfo) {
            this.container.appendChild(this.selectionInfo);
        }
        this.root.appendChild(this.container);

        this.applyResponsiveStyles();
    }

    shift(direction) {
        const keys = this.viewMode === 'week' ? this.availableWeekKeys : this.availableMonthKeys;
        if (!keys.length) {
            return;
        }

        const currentKey = this.viewMode === 'week'
            ? toWeekKey(this.currentDate)
            : toMonthKey(this.currentDate);
        const index = keys.indexOf(currentKey);
        const targetIndex = index + direction;

        if (index === -1 || targetIndex < 0 || targetIndex >= keys.length) {
            return;
        }

        const targetKey = keys[targetIndex];
        if (this.viewMode === 'week') {
            this.currentDate = new Date(`${targetKey}T00:00:00`);
        } else {
            this.currentDate = new Date(`${targetKey}-01T00:00:00`);
        }

        this.render();
    }

    alignCurrentDateToAvailableView() {
        const keys = this.viewMode === 'week' ? this.availableWeekKeys : this.availableMonthKeys;
        if (!keys.length) {
            return;
        }

        const currentKey = this.viewMode === 'week'
            ? toWeekKey(this.currentDate)
            : toMonthKey(this.currentDate);

        if (keys.includes(currentKey)) {
            return;
        }

        const targetKey = keys[0];
        if (this.viewMode === 'week') {
            this.currentDate = new Date(`${targetKey}T00:00:00`);
        } else {
            this.currentDate = new Date(`${targetKey}-01T00:00:00`);
        }
    }

    updateNavigationState() {
        const keys = this.viewMode === 'week' ? this.availableWeekKeys : this.availableMonthKeys;
        if (!keys.length) {
            this.prevBtn.disabled = true;
            this.nextBtn.disabled = true;
            return;
        }

        const currentKey = this.viewMode === 'week'
            ? toWeekKey(this.currentDate)
            : toMonthKey(this.currentDate);
        const index = keys.indexOf(currentKey);

        this.prevBtn.disabled = index <= 0;
        this.nextBtn.disabled = index === -1 || index >= keys.length - 1;
    }

    getVisibleDays() {
        const days = [];
        const base = cloneDate(this.currentDate);

        if (this.viewMode === 'week') {
            const weekStart = getWeekStartDate(base);
            for (let i = 0; i < 7; i++) {
                const date = cloneDate(weekStart);
                date.setDate(weekStart.getDate() + i);
                days.push(date);
            }
            return days;
        }

        // Only render the days that actually belong to the current month. The leading
        // weekday alignment is handled with empty filler cells in renderCalendarGrid().
        const first = new Date(base.getFullYear(), base.getMonth(), 1);
        const daysInMonth = new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate();

        for (let i = 0; i < daysInMonth; i++) {
            const date = cloneDate(first);
            date.setDate(first.getDate() + i);
            days.push(date);
        }

        return days;
    }

    /**
     * Push the resolved labels into the already rendered DOM. The two view buttons are only
     * written in buildLayout(), so they are updated directly; everything else picks the new
     * labels up from the re-render.
     */
    applyLabels() {
        if (this.monthBtn) {
            this.monthBtn.textContent = this.labels.month;
        }
        if (this.weekBtn) {
            this.weekBtn.textContent = this.labels.week;
        }
        if (this.container) {
            this.render();
        }
    }

    render() {
        this.alignCurrentDateToAvailableView();

        this.title.textContent = this.viewMode === 'week'
            ? this.labels.weekof.replace('{date}', this.currentDate.toLocaleDateString())
            : toMonthLabel(this.currentDate);

        this.monthBtn.classList.toggle('btn-primary', this.viewMode === 'month');
        this.monthBtn.classList.toggle('btn-outline-secondary', this.viewMode !== 'month');
        this.weekBtn.classList.toggle('btn-primary', this.viewMode === 'week');
        this.weekBtn.classList.toggle('btn-outline-secondary', this.viewMode !== 'week');

        if (this.showPriceLegend) {
            this.renderPriceLegend();
        }

        this.renderCalendarGrid();
        if (this.showSlotList) {
            if (this.slotView === 'timeline') {
                this.renderSlotTimeline();
            } else {
                this.renderSlotList();
            }
        }
        this.renderSelectionInfo();
        this.updateNavigationState();
    }

    /**
     * Update the slot filter predicate and re-render from the already-loaded slot data.
     * Used by the multi-option sidebar to show/hide slots per option id without any new
     * webservice round-trip - every option's slots are already present in this.slotsByDay.
     *
     * @param {Function|null} fn predicate(slot) => boolean, or null to clear the filter
     */
    setSlotFilter(fn) {
        this.slotFilter = typeof fn === 'function' ? fn : null;
        this.render();

        // render() only refreshes the calendar grid and (when showSlotList is true) the picker's
        // own slot list/timeline. When showSlotList is false, an external region owns the day's
        // slot display via onDayChange (see condition/slotBooking.js's fixedEditorRoot branch) -
        // notify it too, or filtering an option out of the sidebar wouldn't remove its slots from
        // that region.
        if (!this.showSlotList && this.activeDay) {
            const daySlots = this.slotsByDay.get(this.activeDay) || [];
            const visibleSlots = this.slotFilter ? daySlots.filter(this.slotFilter) : daySlots;
            this.onDayChange(this.activeDay, visibleSlots);
        }
    }

    /**
     * Replace the picker's selection from an external owner and re-render.
     *
     * The booking flow's calendar + fixed-grid mode keeps the authoritative selection in the hidden
     * slot_selection input, not in this.selected (see condition/slotBooking.js: it passes
     * initialSelection: [] and a no-op onChange, because the day timeline rendered OUTSIDE the
     * picker owns the clicking). Without this, this.selected stayed permanently empty there, so the
     * day cells could not mark days carrying a selection and the built-in counter always read
     * "0/N selected" no matter what the user had actually picked.
     *
     * Deliberately does NOT fire onChange: the caller is the source of truth here, so echoing the
     * change back would just re-enter whatever wrote it.
     *
     * @param {Array<string>} keys currently selected slot keys
     */
    setSelectedKeys(keys) {
        this.selected = new Set(Array.isArray(keys) ? keys.map(key => String(key)) : []);
        this.render();
    }

    /**
     * Find which calendar day a slot key belongs to.
     *
     * Resolved from the picker's own slotsByDay rather than re-derived caller-side: day keys here
     * are built with the USER's timezone (toDateKey via this.dayKeyFormatter), while a caller
     * working from a Date object would use the BROWSER's (toDateKeyFromDate). The two can differ by
     * a day, which would send "jump to this slot's day" to the wrong day. Note also that the
     * server-side DTO's own "daykey" field is NOT usable here: slot_dto::build_picker_slots()
     * builds it with userdate('%Y-%m-%d'), which does not zero-pad ("2026-10-9"), while every day
     * key in this class is zero-padded.
     *
     * @param {string} slotKey slot key ("start:end")
     * @return {?string} "YYYY-MM-DD" day key, or null when the key is not among the loaded slots
     */
    findDayKeyForSlotKey(slotKey) {
        const needle = String(slotKey);
        const match = Array.from(this.slotsByDay.entries())
            .find(([, daySlots]) => daySlots.some(slot => String(slot.key) === needle));
        return match ? match[0] : null;
    }

    /**
     * Programmatically open a given day, bringing the month/week view along with it.
     *
     * Used by the selected-slots summary below the calendar (see condition/slotBooking.js) to jump
     * straight to the day a selected slot sits on - which may well be in a different month than the
     * one currently shown, hence moving this.currentDate too. Mirrors how prepareData() honours
     * initialActiveDay, so no new date handling is introduced.
     *
     * @param {string} dayKey "YYYY-MM-DD", as produced by findDayKeyForSlotKey()
     * @return {boolean} whether that day existed and was opened
     */
    goToDay(dayKey) {
        const targetDay = String(dayKey || '');
        if (!targetDay || !this.slotsByDay.has(targetDay)) {
            return false;
        }

        const changed = this.activeDay !== targetDay;
        this.activeDay = targetDay;
        this.currentDate = cloneDate(new Date(`${targetDay}T00:00:00`));
        this.render();

        // Only when the day actually changed, matching the day-cell click handler in
        // renderCalendarGrid() - re-notifying for the day already on screen would pointlessly
        // re-render the external day timeline (and flicker) on every summary click.
        if (changed) {
            const daySlots = this.slotsByDay.get(targetDay) || [];
            const visibleSlots = this.slotFilter ? daySlots.filter(this.slotFilter) : daySlots;
            this.onDayChange(targetDay, visibleSlots);
        }

        return true;
    }

    renderCalendarGrid() {
        this.calendarGrid.innerHTML = '';

        WEEK_DAYS.forEach(label => {
            const head = document.createElement('div');
            head.className = 'booking-slot-calendar-head text-center small fw-bold';
            head.textContent = label;
            this.calendarGrid.appendChild(head);
        });

        const days = this.getVisibleDays();
        const month = this.currentDate.getMonth();

        // In month view, pad the start of the grid so the first day lands under the
        // correct weekday column without rendering days from the previous month.
        if (this.viewMode === 'month' && days.length > 0) {
            const leading = (days[0].getDay() + 6) % 7;
            for (let i = 0; i < leading; i++) {
                const filler = document.createElement('div');
                filler.className = 'booking-slot-calendar-cell';
                this.calendarGrid.appendChild(filler);
            }
        }

        days.forEach(date => {
            const dayKey = toDateKeyFromDate(date);
            const rawDaySlots = this.slotsByDay.get(dayKey) || [];
            const daySlots = this.slotFilter ? rawDaySlots.filter(this.slotFilter) : rawDaySlots;

            const cell = document.createElement('div');
            cell.className = 'booking-slot-calendar-cell';

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-sm w-100 text-start booking-slot-calendar-day-btn';
            btn.style.minHeight = '3.75rem';

            const inCurrentMonth = date.getMonth() === month || this.viewMode === 'week';
            btn.classList.add(inCurrentMonth ? 'btn-light' : 'btn-outline-light');

            if (daySlots.length > 0) {
                btn.classList.add('border', 'border-success');
            }
            const dayHasCurrent = daySlots.some(slot => this.currentKeys.has(slot.key));
            if (dayHasCurrent) {
                // Distinct ring so the currently booked day stands out across months/weeks.
                btn.style.boxShadow = 'inset 0 0 0 2px #0d6efd';
            }
            if (this.activeDay === dayKey) {
                btn.classList.remove('btn-light');
                btn.classList.add('btn-primary', 'text-white');
            }

            const daystate = this.dayStateResolver ? String(this.dayStateResolver(daySlots) || '') : '';
            if (daystate === 'full' && this.activeDay !== dayKey) {
                btn.classList.remove('btn-light');
                btn.style.backgroundColor = '#f8d7da';
                btn.style.borderColor = '#f1aeb5';
                btn.style.color = '#58151c';
            }

            // Day number (top-left) and the "current" star (top-right) share one row so the
            // marked day stays the same height as its neighbours.
            const dayHeader = document.createElement('div');
            dayHeader.className = 'd-flex justify-content-between align-items-start';

            const dayNumber = document.createElement('div');
            dayNumber.className = 'small fw-bold';
            dayNumber.textContent = String(date.getDate());
            dayHeader.appendChild(dayNumber);

            if (dayHasCurrent) {
                const marker = document.createElement('span');
                marker.className = 'small fw-bold text-primary';
                marker.textContent = '★';
                if (this.currentLabel) {
                    marker.title = this.currentLabel;
                }
                dayHeader.appendChild(marker);
            }

            // Days holding part of the current selection get a count badge, so a slot picked on one
            // day stays discoverable while the user is looking at another - with max_slots_per_user
            // above 1 the selection spans days, but the day timeline only ever draws the active one.
            // Uses the same accent as the dayHasCurrent ring above rather than a Bootstrap badge
            // class, so both markers stay visually consistent under any theme.
            const daySelectedCount = daySlots.filter(slot => this.selected.has(slot.uid)).length;
            if (daySelectedCount > 0) {
                const selectedBadge = document.createElement('span');
                selectedBadge.className = 'small fw-bold text-white px-1 rounded';
                selectedBadge.style.backgroundColor = '#0d6efd';
                selectedBadge.textContent = String(daySelectedCount);
                if (this.selectedLabel) {
                    selectedBadge.title = this.selectedLabel;
                }
                dayHeader.appendChild(selectedBadge);
            }

            btn.appendChild(dayHeader);

            if (daySlots.length > 0) {
                const count = document.createElement('div');
                count.className = 'small';
                if (this.dayCountFormatter) {
                    count.textContent = String(this.dayCountFormatter(daySlots));
                } else {
                    count.textContent = this.labels.slotcount.replace('{count}', String(daySlots.length));
                }
                btn.appendChild(count);

                if (this.showPriceLegend && this.priceLevels.length > 0) {
                    const dayPriceDots = document.createElement('div');
                    dayPriceDots.className = 'mt-1 d-flex flex-wrap align-items-center';
                    dayPriceDots.style.gap = '0.3rem';

                    const daySelected = new Set(daySlots
                        .filter(slot => this.selected.has(slot.uid))
                        .map(slot => Number(slot.price || 0)));
                    const dayPrices = Array.from(new Set(daySlots.map(slot => Number(slot.price || 0))))
                        .sort((a, b) => a - b);

                    dayPrices.forEach(price => {
                        const dot = document.createElement('span');
                        dot.style.width = '0.5rem';
                        dot.style.height = '0.5rem';
                        dot.style.borderRadius = '999px';
                        dot.style.display = 'inline-block';
                        dot.style.backgroundColor = this.getPriceColor(price);
                        // Same thin outline for every dot, so a selected one keeps its full size -
                        // under Bootstrap's border-box sizing the old 2px ring was drawn INTO the
                        // 0.5rem dot and shrank its colour to a speck. The ring is a box-shadow.
                        dot.style.border = '1px solid rgba(0,0,0,0.15)';
                        if (daySelected.has(price)) {
                            dot.style.boxShadow = SELECTED_DOT_RING;
                        }
                        dot.title = this.getPriceLabel(price);
                        dayPriceDots.appendChild(dot);
                    });

                    btn.appendChild(dayPriceDots);
                }
            }

            btn.addEventListener('click', () => {
                const changed = this.activeDay !== dayKey;
                this.activeDay = dayKey;

                if (changed && this.resetSelectionOnDayChange && this.selected.size > 0) {
                    this.selected.clear();
                    this.emitChange();
                }

                this.render();

                if (changed) {
                    this.onDayChange(dayKey, daySlots);
                }
            });

            cell.appendChild(btn);
            this.calendarGrid.appendChild(cell);
        });
    }

    renderSlotList() {
        this.slotList.innerHTML = '';

        if (!this.activeDay) {
            return;
        }

        const slots = this.slotsByDay.get(this.activeDay) || [];
        const visibleSlots = this.slotFilter ? slots.filter(this.slotFilter) : slots;

        if (visibleSlots.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'small text-muted';
            empty.textContent = this.emptySlotListText;
            this.slotList.appendChild(empty);
            return;
        }

        const heading = document.createElement('div');
        heading.className = 'small fw-bold mb-2';
        heading.textContent = visibleSlots[0].daylabel;
        this.slotList.appendChild(heading);

        const list = document.createElement('div');
        list.className = 'booking-slot-calendar-slot-list';

        visibleSlots.forEach(slot => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-sm booking-slot-calendar-slot-btn';
            btn.textContent = slot.timelabel;

            if (Array.isArray(slot.teachers) && slot.teachers.length > 0) {
                btn.textContent = '';

                const timeLine = document.createElement('div');
                timeLine.className = 'fw-bold small';
                timeLine.textContent = slot.timelabel;
                btn.appendChild(timeLine);

                const teacherLine = document.createElement('div');
                teacherLine.className = 'small text-muted mt-1';

                slot.teachers.forEach((teacher, index) => {
                    const chip = document.createElement('span');
                    chip.className = 'me-1';
                    chip.textContent = String(teacher.initials || '').trim();
                    chip.title = String(teacher.fullname || '').trim();
                    chip.style.cursor = 'help';
                    teacherLine.appendChild(chip);

                    if (index < slot.teachers.length - 1) {
                        const separator = document.createElement('span');
                        separator.textContent = ' ';
                        teacherLine.appendChild(separator);
                    }
                });

                btn.appendChild(teacherLine);
            }

            if (slot.priceformatted) {
                if (btn.textContent !== '') {
                    btn.textContent = '';

                    const timeLine = document.createElement('div');
                    timeLine.className = 'fw-bold small';
                    timeLine.textContent = slot.timelabel;
                    btn.appendChild(timeLine);
                }

                const priceLine = document.createElement('div');
                priceLine.className = 'small text-muted mt-1';
                priceLine.textContent = slot.priceformatted;
                btn.appendChild(priceLine);
            }

            const selected = this.selected.has(slot.uid);
            // Color choice depending on mode: Unavailability = red, Availability = green.
            let markmode = 'unavailability';
            if (typeof this.root.closest === 'function') {
                const form = this.root.closest('form');
                if (form) {
                    const markmodeInput = form.querySelector('[name="markmode"]');
                    if (markmodeInput) {
                        markmode = markmodeInput.value;
                    }
                }
            }
            // First remove all btn-* color classes, so none remain duplicated.
            btn.classList.remove('btn-success', 'btn-danger', 'btn-outline-secondary');
            if (selected) {
                if (markmode === 'unavailability') {
                    btn.classList.add('btn-danger');
                } else {
                    btn.classList.add('btn-success');
                }
            } else {
                btn.classList.add('btn-outline-secondary');
            }

            if (this.currentKeys.has(slot.key)) {
                // Mark the user's current booking distinctly from the selection color.
                btn.classList.add('border', 'border-primary', 'border-2');
                if (this.currentLabel) {
                    const badge = document.createElement('div');
                    badge.className = 'badge bg-primary mt-1';
                    badge.textContent = this.currentLabel;
                    btn.appendChild(badge);
                }
            }

            const islocked = this.lockedKeys.has(slot.key);
            if (islocked) {
                // Locked booked slot (past its deadline): stays selected, cannot be given up.
                btn.classList.add('booking-slot-locked', 'disabled');
                btn.setAttribute('aria-disabled', 'true');
                btn.style.cursor = 'not-allowed';
                if (this.lockedLabel) {
                    const badge = document.createElement('div');
                    badge.className = 'badge bg-secondary mt-1';
                    badge.textContent = this.lockedLabel;
                    btn.appendChild(badge);
                }
            }

            btn.addEventListener('click', () => {
                if (islocked) {
                    // Past its deadline — cannot be moved or cancelled.
                    return;
                }
                if (this.selected.has(slot.uid)) {
                    this.selected.delete(slot.uid);
                    this.render();
                    this.emitChange();
                    return;
                }

                if (this.selected.size >= this.maxSelection) {
                    if (this.replaceWhenFull) {
                        this.selected.clear();
                    } else {
                        return;
                    }
                }

                if (this.selected.size >= this.maxSelection) {
                    return;
                }

                this.selected.add(slot.uid);
                this.render();
                this.emitChange();
            });

            list.appendChild(btn);
        });

        this.currentSlotList = list;
        this.applyResponsiveStyles();
        this.slotList.appendChild(list);
    }

    /**
     * Selection adapter over the picker's own state for the shared timeline renderer. Mirrors the
     * slot-list click logic (max / replaceWhenFull / locked) and triggers a full re-render +
     * onChange so the grid price dots and selection counter stay in sync, exactly like the list.
     *
     * @return {object} selection interface (see slot_day_renderers.createHiddenInputSelection)
     */
    buildTimelineSelection() {
        const picker = this;
        return {
            max: picker.maxSelection,
            isSelected: (key) => picker.selected.has(key),
            isLocked: (key) => picker.lockedKeys.has(key),
            isCurrent: (key) => picker.currentKeys.has(key),
            // The picker keeps booked keys out of `selected` already; nothing to drop on render.
            deselect: () => {},
            toggle(key) {
                if (picker.lockedKeys.has(key)) {
                    return;
                }
                if (picker.selected.has(key)) {
                    picker.selected.delete(key);
                } else {
                    if (picker.selected.size >= picker.maxSelection) {
                        if (picker.replaceWhenFull) {
                            picker.selected.clear();
                        } else {
                            return;
                        }
                    }
                    if (picker.selected.size >= picker.maxSelection) {
                        return;
                    }
                    picker.selected.add(key);
                }
                picker.render();
                picker.emitChange();
            },
        };
    }

    /**
     * Render the active day's slots as the shared proportional timeline (the 'timeline' slotView),
     * driven by the picker's own selection so current/locked slots are honoured.
     *
     * @return {Promise<void>}
     */
    async renderSlotTimeline() {
        this.slotList.innerHTML = '';

        if (!this.activeDay) {
            return;
        }

        const slots = this.slotsByDay.get(this.activeDay) || [];
        const visibleSlots = this.slotFilter ? slots.filter(this.slotFilter) : slots;

        if (visibleSlots.length === 0) {
            const empty = document.createElement('div');
            empty.className = 'small text-muted';
            empty.textContent = this.emptySlotListText;
            this.slotList.appendChild(empty);
            return;
        }

        const heading = document.createElement('div');
        heading.className = 'small fw-bold mb-2';
        heading.textContent = visibleSlots[0].daylabel;
        this.slotList.appendChild(heading);

        const region = document.createElement('div');
        region.className = 'booking-slot-fixed-editor';
        this.slotList.appendChild(region);

        await renderFixedSlotsEditor(region, visibleSlots, this.buildTimelineSelection(), this.timeFormatter);
    }

    renderSelectionInfo() {
        this.selectionInfo.textContent = this.labels.selectedcount
            .replace('{selected}', String(this.selected.size))
            .replace('{max}', String(this.maxSelection));
    }

    getPriceColor(price) {
        const numericPrice = Number(price || 0);
        if (numericPrice <= 0) {
            return '#198754';
        }

        if (this.priceScaleMax <= this.priceScaleMin) {
            return '#f59f00';
        }

        const ratio = Math.max(0, Math.min(1, (numericPrice - this.priceScaleMin) / (this.priceScaleMax - this.priceScaleMin)));
        const hue = Math.round(120 - (120 * ratio));
        return `hsl(${hue}, 75%, 45%)`;
    }

    getPriceLabel(price) {
        const numericPrice = Number(price || 0);
        if (numericPrice <= 0) {
            return 'Free';
        }

        const slotWithPrice = this.slots.find(slot => Number(slot.price || 0) === numericPrice);
        if (slotWithPrice && String(slotWithPrice.priceformatted || '').trim() !== '') {
            return String(slotWithPrice.priceformatted).trim();
        }

        return String(numericPrice);
    }

    /**
     * Load the price legend's labels from the language pack.
     *
     * Asynchronous, so the first (synchronous) render leaves the legend out and it is drawn once
     * the strings arrive. The promise settles only after the constructor has finished, so the
     * legend element built in buildLayout() exists by then. Kept out of the constructor, which is
     * already at the complexity limit.
     */
    loadLegendStrings() {
        if (!this.showPriceLegend) {
            return;
        }
        getStrings([
            {key: 'slot_price_legend', component: 'mod_booking'},
            {key: 'slot_price_legend_free', component: 'mod_booking'},
            {key: 'selected', component: 'mod_booking'},
        ]).then(([title, free, selected]) => {
            this.legendStrings = {title, free, selected};
            this.renderPriceLegend();
            return null;
        }).catch(() => null);
    }

    renderPriceLegend() {
        this.priceLegend.innerHTML = '';

        if (!this.showPriceLegend || this.priceLevels.length === 0 || !this.legendStrings) {
            return;
        }

        const row = document.createElement('div');
        row.className = 'd-flex flex-wrap align-items-center';
        row.style.gap = '0.5rem';

        const title = document.createElement('span');
        title.className = 'fw-bold';
        title.textContent = this.labels.pricelegend;
        row.appendChild(title);

        const addLegendItem = (color, label, selected = false) => {
            const item = document.createElement('span');
            item.className = 'd-inline-flex align-items-center';
            item.style.gap = '0.25rem';

            const dot = document.createElement('span');
            dot.style.width = '0.6rem';
            dot.style.height = '0.6rem';
            dot.style.borderRadius = '999px';
            dot.style.display = 'inline-block';
            dot.style.backgroundColor = color;
            dot.style.border = '1px solid rgba(0,0,0,0.2)';
            if (selected) {
                dot.style.boxShadow = SELECTED_DOT_RING;
            }

            const text = document.createElement('span');
            text.textContent = label;

            item.appendChild(dot);
            item.appendChild(text);
            row.appendChild(item);
        };

        // Only list "free" when a loaded slot actually costs nothing - a legend entry for a price
        // nobody can pick is simply wrong.
        if (this.priceLevels.some(price => price <= 0)) {
            addLegendItem('#198754', this.legendStrings.free);
        }
        this.priceLevels.filter(price => price > 0).forEach(price => {
            addLegendItem(this.getPriceColor(price), this.getPriceLabel(price));
        });
        addLegendItem('#ffffff', this.legendStrings.selected, true);

        this.priceLegend.appendChild(row);
    }

    emitChange() {
        this.onChange(Array.from(this.selected));
    }

    applyResponsiveStyles() {
        const width = window.innerWidth || 1024;

        if (this.toolbar) {
            this.toolbar.style.flexWrap = width < 768 ? 'wrap' : 'nowrap';
        }

        if (this.currentSlotList) {
            let columns = 3;
            if (width < 992) {
                columns = 2;
            }
            if (width < 576) {
                columns = 1;
            }
            this.currentSlotList.style.gridTemplateColumns = `repeat(${columns}, minmax(0, 1fr))`;
        }

        const dayButtons = this.calendarGrid
            ? this.calendarGrid.querySelectorAll('.booking-slot-calendar-day-btn')
            : [];
        dayButtons.forEach(button => {
            button.style.minHeight = width < 576 ? '3.1rem' : '3.75rem';
        });
    }
}

export const init = (root, options = {}) => {
    return new SlotCalendarPicker(root, options);
};
