<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External function declarations for format_simple.
 *
 * @package    format_simple
 * @copyright  2025 South African Theological Seminary <ict@sats.ac.za>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'format_simple_get_section0_content' => [
        'classname'     => 'format_simple\external\get_section0_content',
        'description'   => 'Returns rendered section 0 HTML for the Simple format overlay.',
        'type'          => 'read',
        'ajax'          => true,
        'loginrequired' => true,
    ],
    'format_simple_set_theme_preference' => [
        'classname'     => 'format_simple\external\set_theme_preference',
        'description'   => 'Saves the user\'s dark mode theme preference for the Simple format.',
        'type'          => 'write',
        'ajax'          => true,
        'loginrequired' => true,
    ],
];
