// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @module    local_wunderbyte_table
 * @copyright  Wunderbyte GmbH <info@wunderbyte.at>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
import Ajax from 'core/ajax';
import Templates from 'core/templates';
import Notification from 'core/notification';

import {
    initializeCheckboxes,
    getFilterObjects,
    initializeSearchInputListener,
    initializeFilterStatus
} from 'local_wunderbyte_table/filter';
import {initializeFilterKeyboard} from 'local_wunderbyte_table/filterkeyboard';
import {initializeSearch, getSearchInput} from 'local_wunderbyte_table/search';
import {initializeSort, getSortSelection} from 'local_wunderbyte_table/sort';
import {initializeReload, reloadAllTables, expiredReloadAllowed} from 'local_wunderbyte_table/reload';
import {initializeActionButton} from 'local_wunderbyte_table/actionbutton';
import {initializeEditTableButton} from 'local_wunderbyte_table/edittable';
import {initializeReordering} from 'local_wunderbyte_table/reordering';
import {initializeRowsSelect} from './rowsdisplayselect';
import {
    initializeResetFilterButton,
    updateUrlWithFilterSearchSort,
    updateDownloadUrlWithFilterSearchSort
} from './filter';
import {initializeFilterSearch} from './filtersearch';

import {get_string as getString} from 'core/str';

// All these variables will be objects with the idstring so their tables as identifiers.
var loadings = {};
export var queries = {};
var scrollpages = {};
var tablejss = {};
var scrollingelement = {};
// Monotonic request counter per table, bumped by every full (re)load. Responses carry the
// counter value from when they were issued; a response older than the counter is discarded,
// so a stale in-flight reload can never overwrite the result of a newer one.
var requestcounters = {};
// Per table: the load to re-run once an open modal inside the table is closed (see callLoadData).
var deferredloads = {};

var moreThanOneTable = false;
export const SELECTORS = {
    CONTAINER: ".wunderbyte_table_container_",
    FILTER: " .wunderbyteTableFilter",
    WBTABLE: "wunderbyte-table-",
    DOWNLOADELEMENT: "form.wb-table-download-buttons",
};

/**
 * Initialize automatic table reload on tab switch and browser back navigation.
 * This function sets up event listeners for visibility changes and popstate events.
 */
function initializeAutoReload() {
    // Reload tables when switching back to this tab
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            reloadAllTables(false);
        }
    });

    // Reload tables when using browser back button
    window.addEventListener('popstate', () => {
        reloadAllTables(false);
    });

    // Reload tables when switching between Bootstrap tabs so that tables
    // which were hidden (and therefore skipped by reloadAllTables) pick up
    // any data changes that happened while they were in an inactive tab.
    document.addEventListener('shown.bs.tab', () => {
        reloadAllTables(false);
    });
}

// Initialize auto-reload listeners when module loads
initializeAutoReload();

/**
 * Gets called from mustache template.
 * @param {string} idstring
 * @param {string} encodedtable
 */
export const init = (idstring, encodedtable) => {

    // eslint-disable-next-line no-console
    console.log('init booking ' + idstring, moreThanOneTable);

    if (!queries[idstring]) {
        checkInTable(idstring, encodedtable);
    }

    // Check if there is more than 1 tables, excluding tables created because of search.
    let counter = 0;
    counter = Object.entries(queries).length;

    if (counter > 1) {
        // Check if all have the same value for encodedtable.
        const firstEncodedTable = Object.values(queries)[0]?.encodedtable;
        const allSame = Object.entries(queries).every(obj => obj.encodedtable === firstEncodedTable);
        if (!allSame) {
            moreThanOneTable = true;
        }
    }

    if (idstring && encodedtable) {

        if (!scrollpages.hasOwnProperty(idstring)) {

            if (infinitescrollEnabled(idstring)) {
                scrollpages[idstring] = 0;
            } else {
                scrollpages[idstring] = -1;
            }

        }
        respondToVisibility(idstring, encodedtable, callLoadData);
    }

};

/**
 * Handle Click on Dropdown
 * @param {string} idstring
 */
const initHandleDropdown = (idstring) => {
    const buttons = document.querySelectorAll('.wunderbyte_table_container_' + idstring + ' .hierarchy .hierarchybutton');

    buttons.forEach(element => {

        if (element.dataset.collapseinitialized) {
            return;
        }
        element.dataset.collapseinitialized = true;

        // The panel is addressed via aria-controls, so the markup around the button can change
        // without breaking the toggle. The two older variants (button with and without a checkbox
        // next to it) are kept as a fallback.
        const controls = element.getAttribute('aria-controls');
        const panel = controls
            ? document.getElementById(controls)
            : (element.parentElement.classList.contains('d-flex')
                ? element.parentElement.nextElementSibling
                : element.nextElementSibling);

        if (!panel) {
            return;
        }

        element.setAttribute('aria-expanded', panel.classList.contains('show') ? 'true' : 'false');

        element.addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            const expanded = panel.classList.toggle("show");
            // Without this a screen reader never learns whether the category is open or closed.
            element.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        });
    });
};

/**
 * Handle Click on Dropdown
 *
 */
const initHandleDropdownFocusSearch = () => {

    const checkboxes = document.querySelectorAll('.filterelement.filterouter');
    if (checkboxes) {
        Array.from(checkboxes).forEach(cb => {
            cb.addEventListener('click', function(event) {
                event.currentTarget.parentElement.parentElement.parentElement.firstElementChild.style.display = 'none';
            });
        });
    }

    const elements = document.querySelectorAll('.wunderbyteTableFilter .dropdownMenuButton');
    if (elements) {
        Array.from(elements).forEach(element => {
            if (element.nextElementSibling.firstElementChild.children[1] &&
                element.nextElementSibling.firstElementChild.children[1].hidden !== true) {
                element.classList.add('hideFocus');
            }
            element.addEventListener('click', function(event) {
                if (event.currentTarget == element) {
                    setTimeout(() => {
                        if (!element.nextElementSibling.firstElementChild.children[1].hidden) {
                            element.nextElementSibling.firstElementChild.children[1].focus();
                            const buttonHeight = element.clientHeight;
                            element.nextElementSibling.firstElementChild.children[1].style.height = buttonHeight + 'px';
                            const heightWm = buttonHeight + 3;
                            if (element.nextElementSibling.firstElementChild.children[0].firstElementChild.innerHTML &&
                                element.nextElementSibling.firstElementChild.children[0].firstElementChild.innerHTML.length > 28) {
                                element.nextElementSibling.firstElementChild.children[0].firstElementChild.innerHTML =
                                    element.nextElementSibling.firstElementChild.children[0].firstElementChild.innerHTML
                                        .substring(0, 28);
                            }
                            element.nextElementSibling.firstElementChild.children[1].style.top = '-' + heightWm + 'px';
                            element.nextElementSibling.firstElementChild.children[0].style.display = 'block';
                            const posLabel = buttonHeight + 20;
                            element.nextElementSibling.firstElementChild.children[0].style.top = '-' + posLabel + 'px';
                        } else {
                            element.nextElementSibling.firstElementChild.children[0].style.display = 'none';
                        }
                    }, 0);
                }
            });
        });
    }
};

/**
 * Toggle aside block with filters.
 * @param {string} idstring
 */
const initToggleAside = (idstring) => {
    const togglebutton = document.querySelector('#asidecollapse_' + idstring);
    const wbtable = document.querySelector('.wunderbyte_table_container_' + idstring);

    if (wbtable && togglebutton) {
        const isInactiveFilter = wbtable.classList.contains('inactivefilter');
        togglebutton.setAttribute('aria-expanded', isInactiveFilter ? 'false' : 'true');
        togglebutton.addEventListener('click', () => {
            const aside = document.querySelector('.wunderbyte_table_container_' + idstring + ' aside');
            aside.classList.toggle('inactive');
            wbtable.classList.toggle('inactivefilter');
            const isExpanded = togglebutton.getAttribute('aria-expanded') === 'true';
            togglebutton.setAttribute('aria-expanded', !isExpanded);
            if (!aside.classList.contains('inactive')) {
            aside.childNodes[1].focus();
            }
        });
    }

};

/**
 * React on visibility change.
 * @param {string} idstring
 * @param {string} encodedtable
 * @param {function} callback
 */
function respondToVisibility(idstring, encodedtable, callback) {

    const identifier = 'a' + idstring;
    let element = document.querySelector('#' + identifier);

    // If we find the table element AND if it has the encoded table set, we abort this.
    // Hereby we avoid to run JS multiple times.
    if (element && !element.dataset.encodedtable) {
        element.dataset.encodedtable = encodedtable;
    } else {

        // We abort everything else, but we run again the components initialization.
        // important, as parts of the table might have been reloaded.
        initializeComponents(idstring, encodedtable);
        return;
    }

    // We only make this callback during init if there is the spinner running.
    // We don't want to run all of this if we don't use lazyloading.
    let spinner = document.querySelector("#" + identifier + 'spinner');

    if ((spinner !== null) && !isHidden(spinner)) {

        var observer = new MutationObserver(function() {
            if (!isHidden(element)) {
                this.disconnect();

                callback(idstring, encodedtable);
            }
        });

        const hiddenElement = returnHiddenElement(element);

        if (hiddenElement !== null) {

            observer.observe(hiddenElement, {attributes: true});
        } else {
            callback(idstring, encodedtable);
        }

    } else {

        const selector = ".wunderbyte_table_container_" + idstring;
        const container = document.querySelector(selector);

        if (container != undefined) {
            // This is what we do when we didn't lazyload.
            // replaceLinksInFrag(idstring, encodedtable, element, null);
            addLinksToPagination(idstring, encodedtable, element);

            initializeComponents(idstring, encodedtable);

            // Check to see if scrolling near bottom of page; load more photos
            // This shoiuld only be added once.

            // As this can only be here once per table, we mark the table.
            addScrollFunctionality(idstring, encodedtable, element);
            initToggleAside(idstring);

            initHandleDropdown(idstring);
            initHandleDropdownFocusSearch();
        }

    }
}

/**
 * Return the next scrollable element.
 * @param {*} node
 * @returns {*} node
 */
function getScrollParent(node) {
    if (node === null) {
        return null;
    }
    if (node.scrollHeight > node.clientHeight) {
        if (doublecheckScrollable(node)) {
            // In some cases (lazyouthtml table), we need to doublecheck if the element is scrollable.
            return node;
        } else {
            return getScrollParent(node.parentNode);
        }
    } else {
        return getScrollParent(node.parentNode);
    }
}

/**
 * Function to check if element is scrollable by checking overflow.
 * @param {*} node
 * @returns {boolean}
 */
function doublecheckScrollable(node) {
    const styles = window.getComputedStyle(node);
    const isScrollable = styles.overflow === 'scroll' || styles.overflow === 'auto';

    return isScrollable;
}

/**
 * Function to check visibility of element.
 * @param {*} el
 * @returns {boolean}
 */
export const isHidden = (el) => {
    var style = window.getComputedStyle(el);
    return ((style.display === 'none') || (style.visibility === 'hidden'));
};

/**
 * Reloads the rendered table and sets it to the div with the right identifier.
 * @param {string} idstring
 * @param {string} encodedtable
 * @param {null|int} page
 * @param {null|string} tsort
 * @param {null|string} thide
 * @param {null|string} tshow
 * @param {null|int} tdir
 * @param {null|int} treset
 * @param {null|string} filterobjects
 * @param {null|string} searchtext
 * @param {null|bool} replacerow
 * @param {null|bool} replacecomponentscontainer
 * @param {bool} scrolltotop
 * @param {bool} purgecache Asks the server to purge the cache of the table (reload button).
 */
export const callLoadData = (
    idstring,
    encodedtable,
    page = null,
    tsort = null,
    thide = null,
    tshow = null,
    tdir = null,
    treset = null,
    filterobjects = null,
    searchtext = null,
    replacerow = false,
    replacecomponentscontainer = false,
    scrolltotop = false,
    purgecache = false) => {

    // An infinite-scroll append must not fire while another load is running (the scroll
    // listener fires in bursts), but a full reload supersedes an in-flight request instead
    // of being dropped: otherwise the stale in-flight response would render last and a
    // caller-requested refresh (e.g. after booking) would silently never happen.
    const isappend = page !== null && page > 0 && infinitescrollEnabled(idstring) && !replacerow;
    if (loadings[idstring] && isappend) {
        return;
    }
    // Full reloads bump the counter and thereby invalidate every response still in flight.
    // Row replacements and appends only record the current value: they must not cancel a
    // running full reload, but their own response is discarded if a full reload started later.
    if (!replacerow && !isappend) {
        requestcounters[idstring] = (requestcounters[idstring] ?? 0) + 1;
    } else if (requestcounters[idstring] === undefined) {
        requestcounters[idstring] = 0;
    }
    const requestid = requestcounters[idstring];
    // We reset scrollpage with 0 when we come from the filter.
    if (page !== null) {

        if (infinitescrollEnabled(idstring)) {
            scrollpages[idstring] = page;
        } else {
            scrollpages[idstring] = -1;
        }
    }

    // We always have to see if we need to apply a filter. Reload might come from scroll, but filter has to be applied nevertheless.
    if (filterobjects === null) {
        filterobjects = getFilterObjects(idstring);
    }
    // We always have to see if we need to apply a searchtextfilter.
    if (searchtext === null) {
        searchtext = getSearchInput(idstring);
    }
    // We always have to see if we need to apply a sortorder.
    if (tsort === null) {
        tsort = getSortSelection(idstring);
    }

    const table = document.getElementById('a' + idstring);

    // We don't want to update URL for lazyout tables that be loaded (have childnodes) at this point.
    if (moreThanOneTable !== true && (typeof table === 'object' && table !== null)) {
        if (table.childNodes.length > 0) {
            updateUrlWithFilterSearchSort(filterobjects, searchtext, tsort, tdir);
        }
    }

    let container = document.querySelector(".wunderbyte_table_container_" + idstring);
    if (container) {

        const downloadelement = container.querySelector(SELECTORS.DOWNLOADELEMENT);

        if (downloadelement && downloadelement.dataset.applyfilter) {

            updateDownloadUrlWithFilterSearchSort(idstring, filterobjects, searchtext, tsort, tdir);
        }
    }

    // This is now the individual spinner from the wunderbyte table template.
    let spinner = document.querySelector('#a' + idstring + 'spinner .spinner-border');

    // If we replace the whole table, we show the spinner. If we only add rows in infinite scroll, we don't.
    if (scrollpages[idstring] == 0
        && !replacerow) {
        if (spinner) {
            spinner.classList.remove('hidden');
        }
    }

    // We also have the indidual load spinner.
    // Show the call spinner.
    let callspinner = document.querySelector(".wunderbyte_table_container_" + idstring + " .wb-table-call-spinner");
    if (callspinner) {
        callspinner.classList.remove('hidden');
    }

    // This is used to store information for reload etc.
    checkInTable(
        idstring,
        encodedtable,
        page,
        tsort,
        thide,
        tshow,
        tdir,
        treset,
        filterobjects,
        searchtext,
        replacerow
    );

    loadings[idstring] = true;

    Ajax.call([{
        methodname: "local_wunderbyte_table_load_data",
        args: {
            'encodedtable': encodedtable,
            'page': page,
            'tsort': tsort,
            'thide': thide,
            'tshow': tshow,
            'tdir': tdir,
            'treset': treset,
            'wbtfilter': filterobjects,
            'searchtext': searchtext,
            'purgecache': purgecache ? 1 : 0
        },
        done: async function(res) {
            if (requestcounters[idstring] !== requestid) {
                // A newer full reload was issued for this table while this request was in
                // flight. Its response owns the table now, so this stale one must not render.
                return;
            }
            // Hide the call spinner.
            let callspinner = document.querySelector(".wunderbyte_table_container_" + idstring + " .wb-table-call-spinner");
            if (callspinner) {
                callspinner.classList.add('hidden');
            }

            let jsonobject = '';
            try {
                jsonobject = JSON.parse(res.content);
            } catch (e) {

                const message = await getString('couldnotloaddata', 'local_wunderbyte_table');

                Notification.addNotification({
                    message,
                    type: "danger"
                });

                // We need say we are not loading anymore.
                loadings[idstring] = false;

                // eslint-disable-next-line no-console
                console.log(e);
                return;
            }

            let rendertemplate = res.template;

            // We can always expect a wunderbyte table container at this point.
            // The container will hold wunderbyteTableClass, wunderbyteTableFilter, wunderbyteTableSearch classes.
            let container = document.querySelector(".wunderbyte_table_container_" + idstring);

            if (!container) {
                return;
            }
            // reloadAllTables() only skips a table with an open modal at the moment the reload is
            // REQUESTED - a modal opened while this request was in flight (e.g. a booking prepage
            // modal) would be ripped out of the DOM by the re-render below, leaving Bootstrap's
            // backdrop behind (grey, unclickable page). Re-run this load once the modal is closed.
            const openmodal = container.querySelector('.modal.show');
            if (openmodal) {
                loadings[idstring] = false;
                if (!deferredloads[idstring]) {
                    openmodal.addEventListener('hidden.bs.modal', () => {
                        const rerun = deferredloads[idstring];
                        delete deferredloads[idstring];
                        rerun();
                    }, {once: true});
                }
                deferredloads[idstring] = () => callLoadData(idstring, encodedtable, page, tsort, thide, tshow,
                    tdir, treset, filterobjects, searchtext, replacerow, replacecomponentscontainer, scrolltotop);
                return;
            }

            let componentscontainer = container.querySelector(".wunderbyte_table_components");
            if (replacecomponentscontainer) {
                componentscontainer = null;
            }

            // If we only increase the scrollpage, we don't need to render everything again.
            if (replacerow
                || (scrollpages[idstring] > 0)) {

                // Also, we want to use the table instead of the container template.
                const rowtemplate = rendertemplate + '_row';

                if (!jsonobject.table.hasOwnProperty('rows')) {
                    // We set the scrollpage to -1 which means that we don't reload anymore.
                    scrollpages[idstring] = -1;
                    loadings[idstring] = false;
                    return;
                }
                let rows = jsonobject.table.rows;

                // We create an array of promises where every line is rendered individually.
                const promises = rows.map(row => {
                    Templates.renderForPromise(rowtemplate, row).then(({html, js}) => {

                        if (replacerow) {

                            // We need the id.
                            const filterobject = JSON.parse(filterobjects);
                            const rowid = filterobject.id;

                            Templates.replaceNode("#a" + idstring
                                + " .rows-container tr[data-id='" + rowid + "']", html, js);
                        } else {
                            // Here we add the rendered content to the table div.
                            Templates.appendNodeContents('#a' + idstring + " .rows-container", html, js);
                        }

                        return true;
                    }).catch(e => {
                        // eslint-disable-next-line no-console
                        console.log(e);
                    });
                    return true;
                });

                if (!tablejss.hasOwnProperty(idstring)) {

                    const promise = returnPromiseToSaveJS(rendertemplate, jsonobject, idstring);

                    promises.push(promise);
                }

                // Once all the promises are fullfilled, we set loading to false.
                Promise.all(promises).then(() => {

                    setTimeout(() => {
                        // We only added rows, but they might need some js from the table, so we add the table js again.
                        Templates.appendNodeContents('#a' + idstring, '', tablejss[idstring]);

                    }, 100);

                    loadings[idstring] = false;

                    return;
                }).catch(e => {
                    // eslint-disable-next-line no-console
                    console.log(e);
                });

                return;
            }

            const promises = [];
            if (!componentscontainer) {
                // If the componentscontainer is not yet rendered, we render the container. else, only the table.
                rendertemplate = rendertemplate + '_container';
            } else {
                const sortselector = '.wunderbyteTableSelect';
                promises.push(Templates.renderForPromise('local_wunderbyte_table/component_sort', jsonobject).then(({html, js}) => {
                    const element = container.querySelector(sortselector);
                    Templates.replaceNode(element, html, js);
                    // Make sure the element is working.
                    initializeComponents(idstring, encodedtable);
                    return true;
                }).catch(ex => {
                    // eslint-disable-next-line no-console
                    console.log(ex);
                }));
            }

            let frag = container.querySelector(".wunderbyteTableClass");

            // If we called a sorting and the result is an empty array, we don't need to render.
            let rows = jsonobject.table.rows;
            if (tsort && (!rows || rows.length < 1)) {

                if (spinner) {
                    spinner.classList.add('hidden');
                }
                if (table) {
                    table.classList.remove('hidden');
                }

                loadings[idstring] = false;

            } else {
                // We render the html with the right template.
                promises.push(Templates.renderForPromise(rendertemplate, jsonobject).then(({html, js}) => {

                    if (componentscontainer) {
                        // Now we clean the existing table.
                        while (frag.firstChild) {
                            frag.removeChild(frag.lastChild);
                        }

                        // Here we add the rendered content to the table div.
                        Templates.appendNodeContents('#a' + idstring, html, js);
                    } else {
                        // Here we try to render the whole.hro
                        const parent = container.parentElement;
                        container.remove();
                        Templates.appendNodeContents(parent, html, js);

                        container = document.querySelector(".wunderbyte_table_container_" + idstring);
                    }
                    if (container == undefined) {
                        return true;
                    }
                    addLinksToPagination(idstring, encodedtable, container);

                    // When everything is done, we loaded fine.
                    loadings[idstring] = false;

                    if (spinner) {
                        spinner.classList.add('hidden');
                    }
                    if (table) {
                        table.classList.remove('hidden');
                    }

                    // Make sure all elements are working.
                    initializeComponents(idstring, encodedtable);

                    if (!container) {
                        return true;
                    }
                    const element = container.querySelector('#a' + idstring);

                    // This is the place where we are after lazyloading. We check if we need to reinitialize scrolllistener:
                    addScrollFunctionality(idstring, encodedtable, element);
                    scrolltotop = scrolltotop && container && container.classList.contains('wunderbyte_table_scroll_on');
                    if (container && scrolltotop) {
                        const navbar = document.querySelector('.navbar');

                        if (navbar) {

                            const navbarHeight = navbar.offsetHeight;

                            const offsetPosition = container.getBoundingClientRect().top + window.pageYOffset - navbarHeight;

                            window.scrollTo({
                                top: offsetPosition,
                                behavior: 'smooth'
                            });
                        } else {
                            container.scrollIntoView({
                                behavior: 'smooth',
                                block: 'start'
                            });
                        }
                    }

                    return true;
                }).catch(ex => {
                    loadings[idstring] = false;
                    Notification.addNotification({
                        message: 'failed rendering ' + ex,
                        type: "danger"
                    });
                }));
            }

            // We excecute the promises from the array one after the other.
            // eslint-disable-next-line no-unused-vars
            const x = await promises[0];
            // eslint-disable-next-line no-unused-vars
            const y = await promises[1];
        },
        fail: function(err) {

            if (requestcounters[idstring] !== requestid) {
                // Superseded by a newer full reload — don't retry or render an error state.
                return;
            }
            // The request is over, a retry (below) has to pass the loadings guard again.
            loadings[idstring] = false;

            // The cached table object behind the embedded hash was purged on the server
            // (scheduled purge, instance edit, admin cache purge). Retrying with the same
            // hash cannot succeed — only a page render re-caches the table. Reload once;
            // the sessionStorage guard keeps a broken cache store from causing a loop.
            if (err.errorcode === 'tablecacheexpired' && expiredReloadAllowed()) {
                if (!hasOpenOverlay()) {
                    window.location.reload();
                    return;
                }
                // The user is in the middle of something in a modal or an open collapsible (e.g.
                // the pre booking pages of mod_booking, which open from a row of this table). A
                // reload now would tear that down - all the user sees is the backdrop going dark
                // and the list coming back. Reload as soon as the overlay is closed and show the
                // error in the table meanwhile (below).
                reloadOnceOverlaysAreClosed();
            }

            // If we have an error, resetting the table might be enough. we do that.
            // To avoid a loop, we only do this in special cases.
            if (treset != 1 && err.errorcode !== 'tablecacheexpired') {
                callLoadData(idstring, encodedtable, page, null, null, null, null, 1);
            } else {
                // The spinner (and with an unusual template even the table node) can be missing
                // from the markup; the error message must not raise a second error then.
                if (table) {
                    let node = document.createElement('DIV');
                    let textnode = document.createTextNode(err.message);
                    node.appendChild(textnode);
                    table.appendChild(node);
                    table.classList.remove('hidden');
                }
                if (spinner) {
                    spinner.classList.add('hidden');
                }

                // Hide the call spinner.
                let callspinner = document.querySelector(".wunderbyte_table_container_" + idstring + " .wb-table-call-spinner");
                if (callspinner) {
                    callspinner.classList.add('hidden');
                }
            }
        }
    }]);
};

/**
 * Add the scroll functionality to the right table.
 * @param {*} idstring
 * @param {*} encodedtable
 * @param {*} element
 * @returns {void}
 */
function addScrollFunctionality(idstring, encodedtable, element) {

    // First we check if scroll functioanlity is enabled.
    if (!infinitescrollEnabled(idstring)) {
        return;
    }

    if (element.dataset.scrollinitialized) {
        return;
    }

    element.dataset.scrollinitialized = true;

    const scrollableelement = getScrollParent(element);

    if (scrollableelement) {
        scrollableelement.addEventListener('scroll', () => {

            if (!scrollingelement.hasOwnProperty(idstring)) {
                scrollingelement[idstring] = 'scrollElement';
            } else {
                if (scrollingelement[idstring] === 'scrollElement') {
                    scrollListener(element, idstring, encodedtable);
                }
            }
        });
    }

    // It's not easy to decide which is the right, so we have to add both.
    window.addEventListener('scroll', () => {

        if (!scrollingelement.hasOwnProperty(idstring)) {
            scrollingelement[idstring] = 'window';
        } else {
            if (scrollingelement[idstring] === 'window') {
                scrollListener(element, idstring, encodedtable);
            }
        }
    });

}

/**
 * To be called in the scroll listener.
 * @param {node} element
 * @param {string} idstring
 * @param {string} encodedtable
 * @returns {void}
 */
function scrollListener(element, idstring, encodedtable) {
    // We only want to scroll, if the element is visible.
    // So, if we find a hidden element in the parent, we don't scroll.
    if (returnHiddenElement(element)) {
        return;
    }
    const elementtop = element.getBoundingClientRect().top;
    const screenheight = document.body.scrollHeight;

    let container = document.querySelector(".wunderbyte_table_container_" + idstring);
    const tableelement = container.querySelector('[class^="' + SELECTORS.WBTABLE + '"]');

    // If we can't find this table element, we abort.
    if (!tableelement) {
        return;
    }

    const tableelementheight = tableelement.getBoundingClientRect().height;

    if (!loadings[idstring] && scrollpages[idstring] >= 0) {
        if (elementtop + tableelementheight - screenheight < 0) {
            scrollpages[idstring] = scrollpages[idstring] + 1;
            callLoadData(idstring,
                encodedtable,
                scrollpages[idstring],
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        }
    }
}

/**
 * Whether an overlay the user may be interacting with is open: a shown Bootstrap modal anywhere on
 * the page, or an open collapsible inside a table container (inline pre booking pages of
 * mod_booking live there). Mirrors the guards of reloadAllTables.
 * @returns {boolean}
 */
function hasOpenOverlay() {
    const openmodal = document.querySelector('.modal.show');
    if (openmodal && !returnHiddenElement(openmodal)) {
        return true;
    }
    const opencollapses = document.querySelectorAll('[class*="wunderbyte_table_container_"] .collapse.show');
    return [...opencollapses].some(el => !returnHiddenElement(el));
}

/**
 * Reload the page once no modal and no open collapsible is left. Bootstrap's hidden events bubble
 * up to the document, so one pair of listeners covers every overlay on the page.
 * @returns {void}
 */
function reloadOnceOverlaysAreClosed() {
    const reloadWhenClosed = () => {
        if (hasOpenOverlay()) {
            return;
        }
        document.removeEventListener('hidden.bs.modal', reloadWhenClosed);
        document.removeEventListener('hidden.bs.collapse', reloadWhenClosed);
        window.location.reload();
    };
    document.addEventListener('hidden.bs.modal', reloadWhenClosed);
    document.addEventListener('hidden.bs.collapse', reloadWhenClosed);
}

/**
 * If the element or one of its parents is hidden, we return it. the hiddenn element.
 * Else we return null.
 * @param {node} element
 * @returns {null|node}
 */
export function returnHiddenElement(element) {
    // We look if we find a hidden parent. If not, we load right away.
    while (element !== null) {
        if (!isHidden(element)) {
            element = element.parentElement;
        } else {
            return element;
        }
    }
    return null;
}

/**
 * The rendered table has links we can't use. We replace them with eventlisteners and use the callLoadData function.
 * @param {string} idstring
 * @param {string} encodedtable
 * @param {DocumentFragment} frag
 */
function addLinksToPagination(idstring, encodedtable, frag) {
    if (!frag) {
        return;
    }

    var arrayOfPageItems = frag.querySelectorAll(".page-item");

    if (!arrayOfPageItems || arrayOfPageItems.length == 0) {
        return;
    }
    arrayOfPageItems.forEach(item => {

        let pageNumber = item.dataset.pagenumber;

        if (pageNumber) {
            --pageNumber;
            item.addEventListener('click', () => {
                callLoadData(idstring, encodedtable, pageNumber);
            });
        }
    });

    // Initialize go to page
    var selectbox = frag.querySelector("select.go-to-page-select");
    if (selectbox) {
        selectbox.addEventListener('change', (event) => {
            let target = event.target;
            // eslint-disable-next-line no-console
            console.log(target);
            let pagenumber = target.value - 1;
            callLoadData(idstring, encodedtable, pagenumber);

        });
    }
}

/**
 * Function to check if the talbe in question has infinitescroll enabled.
 * @param {string} idstring
 * @returns {bool}
 */
export function infinitescrollEnabled(idstring) {
    // If we don't find the infinitescrollelement, we don#t add the listener.
    const selector = ".wunderbyte_table_container_" + idstring;
    if (document.querySelector(selector + ' div.infinitescroll_enabled')) {
        return true;
    }
    return false;
}

/**
 * Initialize all the JS we need.
 * @param {string} idstring
 * @param {string} encodedtable
 */
function initializeComponents(idstring, encodedtable) {
    const selector = ".wunderbyte_table_container_" + idstring;

    initializeCheckboxes(selector, idstring, encodedtable);
    initializeFilterKeyboard(idstring);
    // The collapsible categories of the hierarchical filter are only wired up here, so they also
    // work after a lazy load (Bootstrap cannot open them on its own, there is no data-target).
    initHandleDropdown(idstring);
    initializeFilterStatus(selector, idstring);
    initializeSearchInputListener(selector, idstring, encodedtable);
    initializeSearch(selector, idstring, encodedtable);
    initializeSort(selector, idstring, encodedtable);
    initializeRowsSelect(selector, idstring, encodedtable);
    initializeFilterSearch(selector, idstring, encodedtable);
    initializeResetFilterButton(selector, idstring, encodedtable);
    initializeEditTableButton(selector, idstring, encodedtable);
    initializeReordering(selector, idstring, encodedtable);

    // A very strange error leads to a failed import from the reloadTable.js under some circumstances.
    // Reload has to be called with this precaution therefore.
    if (initializeReload) {
        initializeReload(selector, idstring, encodedtable);
    }
    initializeActionButton(selector, idstring, encodedtable);

}

/**
 * Function to return promise.
 * @param {*} rendertemplate
 * @param {*} jsonobject
 * @param {*} idstring
 * @returns {Promise}
 */
function returnPromiseToSaveJS(rendertemplate, jsonobject, idstring) {
    // eslint-disable-next-line no-unused-vars
    return Templates.renderForPromise(rendertemplate, jsonobject).then(({html, js}) => {

        tablejss[idstring] = js;

        return true;
    }).catch(e => {
        // eslint-disable-next-line no-console
        console.log(e);
    });
}

/**
 * Function to save queries. Has some logic which helps us to achieve the desired result.
 * @param {*} idstring
 * @param {*} encodedtable
 * @param {*} page
 * @param {*} tsort
 * @param {*} thide
 * @param {*} tshow
 * @param {*} tdir
 * @param {*} treset
 * @param {*} filterobjects
 * @param {*} searchtext
 * @param {*} replacerow
 */
function checkInTable(
    idstring,
    encodedtable,
    page = null,
    tsort = null,
    thide = null,
    tshow = null,
    tdir = null,
    treset = null,
    filterobjects = null,
    searchtext = null,
    replacerow = false) {

    // We don't want to save any queries that want to replace row.
    if (replacerow) {
        return;
    }

    queries[idstring] = {
        idstring,
        encodedtable,
        page,
        tsort,
        thide,
        tshow,
        tdir,
        treset,
        filterobjects,
        searchtext,
        replacerow: false // Replace row is always false.
    };
}