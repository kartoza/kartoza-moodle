<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade file.
 *
 * @package    mod_completionboard
 * @copyright  2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Upgrade steps for completionboard.
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_completionboard_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026100502) {
        $table = new xmldb_table("completionboard");
        $field = new xmldb_field(
            "completionmark",
            XMLDB_TYPE_INTEGER,
            "1",
            null,
            XMLDB_NOTNULL,
            null,
            "1",
            "introformat"
        );

        $dbman->change_field_default($table, $field);
        upgrade_mod_savepoint(true, 2026100502, "completionboard");
    }

    if ($oldversion < 2026100503) {
        $table = new xmldb_table("completionboard");
        $field = new xmldb_field(
            "completionmark",
            XMLDB_TYPE_INTEGER,
            "1",
            null,
            XMLDB_NOTNULL,
            null,
            "0",
            "introformat"
        );

        $dbman->change_field_default($table, $field);
        upgrade_mod_savepoint(true, 2026100503, "completionboard");
    }

    return true;
}
