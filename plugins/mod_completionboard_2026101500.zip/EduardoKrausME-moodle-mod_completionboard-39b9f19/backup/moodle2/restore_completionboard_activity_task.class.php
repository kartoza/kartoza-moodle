<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Restore task for Completion board.
 *
 * @package    mod_completionboard
 * @copyright  2026 Eduardo Kraus {@link https://eduardokraus.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once("{$CFG->dirroot}/mod/completionboard/backup/moodle2/restore_completionboard_stepslib.php");

/**
 * Completion board restore task.
 */
class restore_completionboard_activity_task extends restore_activity_task {
    /**
     * Defines activity-specific restore settings.
     *
     * @return void
     */
    protected function define_my_settings() {
    }

    /**
     * Defines activity-specific restore steps.
     *
     * @return void
     */
    protected function define_my_steps() {
        $this->add_step(new restore_completionboard_activity_structure_step(
            "completionboard_structure",
            "completionboard.xml"
        ));
    }

    /**
     * Defines content decoding rules.
     *
     * @return array
     */
    public static function define_decode_contents() {
        return [
            new restore_decode_content("completionboard", ["intro"], "completionboard"),
        ];
    }

    /**
     * Defines link decoding rules.
     *
     * @return array
     */
    public static function define_decode_rules() {
        return [
            new restore_decode_rule(
                "COMPLETIONBOARDVIEWBYID",
                "/mod/completionboard/view.php?id=$1",
                "course_module"
            ),
            new restore_decode_rule(
                "COMPLETIONBOARDINDEX",
                "/mod/completionboard/index.php?id=$1",
                "course"
            ),
        ];
    }
}
