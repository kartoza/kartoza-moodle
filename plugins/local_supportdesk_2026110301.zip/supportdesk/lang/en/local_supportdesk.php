<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English strings for local_supportdesk.
 *
 * @package    local_supportdesk
 * @copyright  2026 learn-ix support@learn-ix.com
 * Modified 2026-10-03 by 108design: Support Desk consolidation.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
$string['general'] = 'General';
$string['deletion_failed'] = 'The department could not be deleted. Check whether tickets are still assigned to it.';
$string['update_failed'] = 'The department could not be updated.';
$string['closed_tickets'] = 'Closed tickets';
$string['my_tickets'] = 'My tickets';
$string['open_tickets'] = 'Open tickets';
$string['total_tickets'] = 'Total tickets';
$string['reply'] = 'Reply';
$string['submit_reply'] = 'Send reply';
$string['writereply'] = 'Write a reply';

// Modified 2026-10-03 by 108design: complete native UI localisation.
$string['access_denied'] = 'You do not have permission to view this ticket.';
$string['action_needed_hint'] = 'Staff have replied. Please respond.';
$string['actions'] = 'Actions';
$string['add_department'] = 'Departments';
$string['add_new_department'] = 'Add New Department';
$string['add_reply_heading'] = 'Write Your Reply';
$string['add_ticket'] = 'New ticket';
$string['add_to_navbar'] = 'Add to Navigation Bar';
$string['add_to_navbar_desc'] = 'If enabled, a link to the ticket system will be added to the primary navigation menu.';
$string['admin_alert_body'] = '<p>Urgent support ticket from {$a->firstname}: {$a->title}</p><p>Department: {$a->category}</p><p><a href="{$a->url}">View ticket</a></p>';
$string['admin_alert_subject'] = 'Urgent ticket #{$a->id}: {$a->title}';
$string['admin_only_label'] = 'Administrative Controls';
$string['all_rights_reserved'] = 'Original author';
$string['all_tickets'] = 'Support tickets';
$string['all_tickets_stats'] = 'Global Tickets Overview';
$string['allowed_file_types'] = 'Up to 10 files, maximum 5 MB per file';
$string['assign_user'] = 'Assign Support Agent';
$string['assign_user_label'] = 'Assign to Support Agent';
$string['assignable_roles'] = 'Assignable roles';
$string['assignable_roles_desc'] = 'Select the roles that can be assigned to tickets. Users with these roles will appear in the assignee dropdown.';
$string['assigned_to'] = 'Assigned to';
$string['assigned_to_label'] = 'Assigned To';
$string['assigned_to_me'] = 'Assigned to me';
$string['assigned_user'] = 'Assigned To';
$string['attach_files_optional'] = 'Attachments (Optional)';
$string['attached_files'] = 'Attachments';
$string['attachments'] = 'Attachments';
$string['attachments_heading'] = 'Original Attachments';
$string['attention_required'] = 'Attention Required';
$string['audio_preview'] = 'Listen to recording';
$string['awaiting_me_label'] = 'Awaiting My Action';
$string['back_to_home'] = 'Back to Home';
$string['browser_no_audio'] = 'Your browser does not support the audio element.';
$string['cancel'] = 'Cancel';
$string['category'] = 'Category';
$string['category_title'] = 'Department';
$string['categoryinuse'] = 'Move the tickets to another department before deleting this department.';
$string['change_category_label'] = 'Change Department';
$string['change_status_label'] = 'Update Status';
$string['choose_rating'] = 'Choose a rating';
$string['click_to_download'] = 'Click to download';
$string['click_to_record'] = 'Click the microphone to start recording';
$string['click_to_upload'] = 'Click here to choose files from your device';
$string['close'] = 'Close';
$string['closed_label'] = 'Closed';
$string['conversation'] = 'Conversation';
$string['copyright_label'] = 'GNU GPL v3 or later';
$string['create_ticket'] = 'Create Ticket';
$string['created_at'] = 'Date Created';
$string['created_by'] = 'Created By';
$string['creation_failed'] = 'The support department could not be created.';
$string['current_year_label'] = 'Current year';
$string['customer'] = 'Customer';
$string['default_email_placeholder'] = 'noreply@yourmoodlesite.com';
$string['delete'] = 'Delete';
$string['delete_department'] = 'Delete support department';
$string['delete_department_confirm'] = 'Do you want to delete this support department? Departments containing tickets cannot be deleted.';
$string['deleteduser'] = 'Deleted customer';
$string['department'] = 'Department';
$string['department_created'] = 'Support department created.';
$string['department_deleted'] = 'Support department deleted.';
$string['department_updated'] = 'Support department updated.';
$string['description'] = 'Description';
$string['description_optional'] = 'Description (optional)';
$string['description_placeholder'] = 'Please explain the issue in detail...';
$string['disabled'] = 'Support Desk is disabled.';
$string['drag_drop_hint'] = 'Drag and drop files here or click to upload';
$string['edit_department'] = 'Edit support department';
$string['email_confirm_body'] = '<p>Hello {$a->firstname},</p><p>We received your ticket #{$a->id} regarding {$a->title}.</p><p>Department: {$a->category}<br>Status: {$a->status}<br>Date: {$a->date}</p><p><a href="{$a->url}">View ticket</a></p><p>Your support team at {$a->site}</p>';
$string['email_confirm_body_plain'] = 'Hello {$a->firstname},
We received your ticket #{$a->id} regarding {$a->title}.
Status: {$a->status}
{$a->url}
Your support team at {$a->site}';
$string['email_confirm_subject'] = 'Ticket #{$a->id} received: {$a->title}';
$string['enable'] = 'Enable System';
$string['enable_desc'] = 'If enabled, users can create and view tickets.';
$string['erasedticket'] = 'Erased customer ticket';
$string['error'] = 'Error!';
$string['existing_departments'] = 'Existing support departments';
$string['experience_question'] = 'How satisfied are you with the support?';
$string['feedback_comment_label'] = 'Comment (optional)';
$string['feedback_help'] = 'Your feedback helps us improve support.';
$string['feedback_placeholder'] = 'Additional comment (optional)';
$string['feedback_submitted'] = 'Your feedback';
$string['filesselected'] = '{$a} files selected';
$string['form_instruction'] = 'Describe your issue and choose the appropriate support department.';
$string['happy_to_help_hint'] = 'Your issue has been resolved.';
$string['header_subtitle'] = 'We are here to help with your request.';
$string['id'] = 'ID';
$string['internal_note_placeholder'] = 'Leave a note for colleagues...';
$string['internal_notes_heading'] = 'Internal Team Notes';
$string['ip_address'] = 'IP address';
$string['live_stats_heading'] = 'Ticket overview';
$string['log_assigned'] = 'Ticket assigned to: {$a}';
$string['log_category_changed'] = 'Support department changed to: {$a}';
$string['log_feedback_submitted'] = 'Feedback submitted: {$a} out of 5';
$string['log_internal_note_added'] = 'Internal note added';
$string['log_replied'] = 'Reply added';
$string['log_status_changed'] = '{$a->user} changed the status from {$a->old} to {$a->new}.';
$string['log_status_changed_from_to'] = '{$a->user} changed the status from {$a->old} to {$a->new}.';
$string['messageprovider:admin_urgent_alert'] = 'Urgent support tickets';
$string['messageprovider:ticket_confirmation'] = 'Ticket submission confirmation';
$string['mic_access_denied'] = 'Recording could not be started. Please check your microphone permission.';
$string['my_assignment'] = 'Assigned to';
$string['my_summary_heading'] = 'My ticket overview';
$string['my_tickets_desc'] = 'Your support requests are listed here.';
$string['my_tickets_label'] = 'My tickets';
$string['next'] = 'Next';
$string['no_departments'] = 'No support departments available.';
$string['no_internal_notes'] = 'No internal notes yet.';
$string['no_recent_tickets'] = 'No other tickets.';
$string['no_replies_hint'] = 'You can add a reply below.';
$string['no_replies_message'] = 'There are no replies yet.';
$string['no_search_results'] = 'No matching tickets on this page.';
$string['no_tickets'] = 'No tickets available.';
$string['no_tickets_desc'] = 'You have not created any tickets yet.';
$string['no_tickets_message'] = 'There are no tickets yet.';
$string['no_tickets_title'] = 'No tickets found';
$string['nopermission'] = 'Access denied';
$string['nopermission_desc'] = 'You do not have permission to view this ticket.';
$string['of'] = 'of';
$string['open_label'] = 'Open';
$string['pagination_label'] = 'Ticket pages';
$string['pluginname'] = 'Support Desk';
$string['previous'] = 'Previous';
$string['primary_color'] = 'Primary Color';
$string['primary_color_desc'] = 'The main color used for buttons, headers, and primary branding.';
$string['priority'] = 'Priority';
$string['priority_high'] = 'High';
$string['priority_low'] = 'Low';
$string['priority_medium'] = 'Medium';
$string['priority_urgent'] = 'Urgent';
$string['privacy:metadata:categories'] = 'Support Desk categories data.';
$string['privacy:metadata:comments'] = 'Support Desk comments data.';
$string['privacy:metadata:feedback'] = 'Support Desk feedback data.';
$string['privacy:metadata:field'] = 'Support ticket data associated with a user.';
$string['privacy:metadata:files'] = 'Ticket and reply attachments.';
$string['privacy:metadata:logs'] = 'Support Desk logs data.';
$string['privacy:metadata:replies'] = 'Support Desk replies data.';
$string['privacy:metadata:tickets'] = 'Support Desk tickets data.';
$string['privacy:metadata:tickets:content'] = 'Ticket content and description.';
$string['privacy:metadata:tickets:created_at'] = 'Time of ticket creation.';
$string['privacy:metadata:tickets:title'] = 'Ticket subject.';
$string['privacy:metadata:tickets:userid'] = 'The ID of the person who created the ticket.';
$string['quick_tip_label'] = 'Tip';
$string['rating_label'] = 'Rating';
$string['ready'] = 'Recording ready';
$string['recent_tickets_heading'] = 'Other tickets from this person';
$string['record_voice_note'] = 'Record a voice message';
$string['recording_finished'] = 'Voice note recorded successfully';
$string['recording_now'] = 'Recording... click stop when finished';
$string['recording_unsupported'] = 'Your browser does not support microphone recording. You can upload an audio file as an attachment.';
$string['remove_file'] = 'Remove';
$string['reopen_ticket_button'] = 'Reopen ticket';
$string['replies_heading'] = 'Conversation';
$string['required_fields'] = 'Fields marked * are required.';
$string['resolved_label'] = 'Resolved';
$string['return_home'] = 'Back to List';
$string['rolecollision'] = 'The role shortname supportdeskagent is already in use. Installation stopped without changing that role.';
$string['rolespecialist'] = 'Support';
$string['rolespecialistdescription'] = 'Handles department support tickets and support workflow.';
$string['save_department'] = 'Save support department';
$string['save_note'] = 'Save note';
$string['search_page_hint'] = 'Search filters the tickets displayed on this page.';
$string['search_placeholder'] = 'Search by ID or subject';
$string['search_user_placeholder'] = 'Search name, email or username';
$string['secondary_color'] = 'Secondary Color';
$string['secondary_color_desc'] = 'Used for gradients, accents, and secondary UI elements.';
$string['select_department_hint'] = '-- Select Department --';
$string['select_priority_hint'] = 'Select priority level';
$string['send_reply_button'] = 'Send reply';
$string['send_ticket'] = 'Send ticket';
$string['sending'] = 'Sending...';
$string['showing'] = 'Showing';
$string['sorry_no_ticket'] = 'No Tickets Found';
$string['start_new_ticket_btn'] = 'Create ticket';
$string['start_recording'] = 'Start voice recording';
$string['start_reply'] = 'You can reply below.';
$string['status'] = 'Ticket Status';
$string['status_admin_reply'] = 'Support replied';
$string['status_adminreply'] = 'Support replied';
$string['status_assigned'] = 'Assigned';
$string['status_closed'] = 'Closed';
$string['status_in_progress'] = 'In Progress';
$string['status_open'] = 'Open';
$string['status_pending'] = 'Pending';
$string['status_resolved'] = 'Resolved';
$string['status_student_reply'] = 'Customer replied';
$string['status_studentreply'] = 'Customer replied';
$string['status_urgent'] = 'Urgent';
$string['stop_before_sending'] = 'Please stop the recording before sending the ticket or reply.';
$string['stop_recording'] = 'Stop voice recording';
$string['student'] = 'Customer';
$string['student_dashboard_tip'] = 'Your requests are available in the ticket overview.';
$string['submit'] = 'Submit';
$string['submit_feedback'] = 'Submit feedback';
$string['success'] = 'Success!';
$string['support_departments'] = 'Support departments';
$string['support_email'] = 'Support Email';
$string['support_email_desc'] = 'Support notification order: department team → explicitly assigned person on the ticket → this fallback address. Unless additional copies are enabled, this address is used only as fallback. Defaults to the support contact configured in Moodle, or blank if none. Configuring a fallback address is recommended.';
$string['support_team'] = 'Support';
$string['supportdesk:addcategory'] = 'Permission to add new categories';
$string['supportdesk:addticket'] = 'Permission to create new tickets (Customer)';
$string['supportdesk:download'] = 'Permission to download ticket attachments';
$string['supportdesk:manageticket'] = 'Permission to manage/assign all tickets (Admin/Staff)';
$string['supportdesk:specialist'] = 'Receive urgent alerts as a specialist';
$string['supportdesk:viewownoverviews'] = 'View own activity dashboard';
$string['supportdesk:viewticket'] = 'Permission to view ticket details';
$string['system_name'] = 'First Department Name';
$string['system_name_desc'] = 'This is the default name for the first department. You can rename it or manage other departments later by clicking on the "Departments" section.';
$string['ticket_department_label'] = 'Department';
$string['ticket_description_label'] = 'Issue';
$string['ticket_details_heading'] = 'Ticket details';
$string['ticket_id_label'] = 'Ticket ID';
$string['ticket_information'] = 'Ticket information';
$string['ticket_log'] = 'History';
$string['ticket_management'] = 'Manage ticket';
$string['ticket_not_found'] = 'This ticket was not found.';
$string['ticket_priority_label'] = 'Ticket Priority';
$string['ticket_status_label'] = 'Current Status';
$string['ticket_title'] = 'Subject';
$string['ticket_title_help'] = 'Describe your request with a short subject.';
$string['ticket_title_label'] = 'Ticket Title';
$string['tickets_count'] = 'tickets';
$string['ticketsystem'] = 'Ticket system';
$string['title'] = 'Subject';
$string['title_placeholder'] = 'e.g., I cannot access my purchase...';
$string['to'] = 'to';
$string['tooltip_category_hint'] = 'Select the appropriate support department.';
$string['tooltip_desc_hint'] = 'Describe your issue and any error messages.';
$string['tooltip_priority_hint'] = 'Select the priority.';
$string['tooltip_title_hint'] = 'Enter a short subject.';
$string['tooltip_upload_hint'] = 'Files up to 5 MB or the lower site limit.';
$string['tooltip_voice_hint'] = 'Record your request using the microphone.';
$string['total'] = 'Total';
$string['total_tickets_label'] = 'Total tickets';
$string['unassigned'] = 'Not Assigned';
$string['under_review_label'] = 'In progress';
$string['unknown_user'] = 'Unknown user';
$string['update_category_button'] = 'Update department';
$string['update_status_button'] = 'Save Changes';
$string['urgentnotification'] = 'Urgent support ticket';
$string['user_name_label'] = 'Submitted by';
$string['view'] = 'Preview';
$string['view_profile'] = 'View profile';
$string['view_ticket'] = 'View Ticket';
$string['viewticket'] = 'View Ticket';
$string['visit_my_portfolio'] = 'View the licence';
$string['we_are_working_hint'] = 'We are reviewing your request.';
$string['welcome_message'] = 'Support Desk';
$string['write_your_reply'] = 'Your reply';

$string['badge_color'] = 'Badge colour';
$string['badge_color_help'] = 'This colour identifies the support department in lists and tickets.';
$string['invalidbadgecolor'] = 'Choose a valid colour in #RRGGBB format.';
$string['choose_files'] = 'Choose files';
$string['date_format'] = '%d %b %Y, %H:%M';

$string['stats_total_one'] = 'ticket in total';
$string['stats_total_many'] = 'tickets in total';
$string['stats_open_one'] = 'open ticket';
$string['stats_open_many'] = 'open tickets';
$string['stats_closed_one'] = 'closed ticket';
$string['stats_closed_many'] = 'closed tickets';

$string['department_column'] = 'Department';
$string['assignee_column'] = 'Assigned to';

$string['paste_image_hint'] = 'Paste screenshots here with Ctrl+V / ⌘V to attach them.';

// Visitor entry and department notification teams, 2026-10-03.
$string['visitoraccess'] = 'Visitor access through Magic Link';
$string['visitoraccess_desc'] = 'Off by default. Visitors verify their email before creating a ticket or opening their tickets. Requires the enabled, available 108design Magic Link plugin (auth_magiclink) and permitted account creation. Standard Moodle login remains available.';
$string['visitor_missing'] = 'Install the optional Magic Link Authentication plugin (auth_magiclink) to select email-verified visitor access.';
$string['visitor_authdisabled'] = 'Enable Magic Link in Moodle authentication.';
$string['visitor_activationrequired'] = 'Magic Link requires an active activation.';
$string['visitor_newaccountsdisabled'] = 'Allow account creation in Magic Link and Moodle authentication settings.';
$string['visitor_unavailable'] = 'Magic Link is currently unavailable. Visitor access is inactive.';
$string['visitor_heading'] = 'Contact support';
$string['visitor_intro'] = 'Verify your email address with Magic Link. Then create your ticket or open your existing tickets.';
$string['visitor_continue'] = 'Continue with email';
$string['visitor_account_hint'] = 'You do not need a password. If you do not have an account yet, Moodle creates one after email verification using your first and last name.';
$string['visitor_standardlogin'] = 'Sign in with your Moodle account';
$string['department_team'] = 'Support team';
$string['department_team_help'] = 'Selected active users with the system Support role receive notifications for this area. Without a department team, the explicitly assigned person on the ticket is notified, otherwise the configured support email is used as fallback. Membership does not change access permissions.';
$string['department_team_empty'] = 'No eligible people yet. Assign the Support role at system level to the people you want to select.';
$string['invalidteammember'] = 'The team contains a person without an active system-level Support role.';
$string['notify_new'] = 'New support ticket #{$a->id}: {$a->title}';
$string['notify_reply'] = 'New reply to ticket #{$a->id}: {$a->title}';
$string['notify_moved'] = 'Ticket #{$a->id} moved to your department: {$a->title}';
$string['notify_body'] = 'Ticket #{$a->id}: {$a->title}
Department: {$a->category}

Open ticket: {$a->url}';
$string['messageprovider:department_ticket'] = 'Support team: tickets in assigned departments';
$string['messageprovider:ticket_reply'] = 'Replies to your own support tickets';
$string['privacy:metadata:members'] = 'Assignment of support users to notification teams.';
$string['privacy:metadata:messages'] = 'Ticket notifications through Moodle messaging.';

$string['privacy:metadata:fallback_email'] = 'Ticket number, subject, area and ticket link are sent to the configured support contact when no staff recipient is assigned or additional copies are enabled.';

$string['image_gallery'] = 'Ticket images';
$string['image_previous'] = 'Previous image';
$string['image_next'] = 'Next image';
$string['image_zoom'] = 'Zoom image';
$string['image_error'] = 'The image could not be loaded.';
$string['image_thumbnail'] = 'Show image {$a}';

$string['allowvoicenotes'] = 'Allow voice messages';
$string['allowvoicenotes_desc'] = 'Allows microphone recordings in new tickets and replies. Disabled by default. Existing voice messages remain playable; ordinary file attachments remain available.';
$string['voicenotes_disabled'] = 'Voice messages are currently disabled.';

$string['copyallsupportemail'] = 'Send all tickets to this address as well';
$string['copyallsupportemail_desc'] = 'Disabled by default. When enabled, the support address above additionally receives all ticket notifications (new tickets, replies and area changes), even when a department team or assignee is configured. No copy is sent without a valid address. This does not grant ticket access. The additional copy is omitted when the same address is already selected for Moodle email delivery for this event. In-app notifications without email do not suppress the copy.';

$string['publiccreate'] = 'Allow ticket creation without login';
$string['publiccreate_desc'] = 'Explicit opt-in, disabled by default. Enables /local/supportdesk/public.php only with configured Turnstile. Visitors can create a ticket; history and attachments require Moodle login. Up to five submissions per IP in ten minutes.';
$string['turnstilesitekey'] = 'Turnstile: site key';
$string['turnstilesitekey_desc'] = 'Public Cloudflare Turnstile site key for this Moodle domain. Entering keys does not enable guest submissions.';
$string['turnstilesecret'] = 'Turnstile: secret key';
$string['turnstilesecret_desc'] = 'Used only on the server for verification. Public ticket creation remains unavailable without both keys.';
$string['public_heading'] = 'Create a ticket without login';
$string['public_help'] = 'Submit your issue without logging in. To continue, sign in afterwards in the same browser with a confirmed Moodle account using the same email address. No account is created automatically.';
$string['public_name'] = 'Your name';
$string['public_email'] = 'Your email address';
$string['public_login'] = 'Sign in with your Moodle account';
$string['public_origin'] = 'Submitted without login';
$string['public_unverified'] = 'Contact details are not yet linked to a logged-in account. The submitted email address is unverified.';
$string['public_received'] = 'Ticket created';
$string['public_receipt_help'] = 'Your issue has been passed to support. You will receive support replies by email. To view the conversation and reply in the ticket system, claim the ticket within 24 hours in the same browser with a confirmed account using the same email address.';
$string['public_continue'] = 'Sign in and claim ticket';
$string['public_claim'] = 'Link ticket to my account';
$string['public_claim_help'] = 'Link the ticket created in this browser to your logged-in account. Your account email must match the address provided when creating the ticket.';
$string['public_claim_failed'] = 'This ticket cannot be linked to this account. Use the same browser and a confirmed account with the submitted email address within 24 hours.';
$string['public_claim_retry'] = 'Check linking again';
$string['public_spam_protection'] = 'Spam protection by Cloudflare Turnstile';
$string['public_reply_body'] = 'Support has replied to your ticket #{$a->id} “{$a->title}”:

{$a->reply}

After signing in and linking the ticket to your account, you can open its history and any attachments:
{$a->url}

Within 24 hours of ticket creation, use the same browser and a confirmed account with this email address.

Replies to this email are currently not added to the ticket automatically.';
$string['public_invalid'] = 'Please check your details and attachments. Name, valid email, subject, area and issue are required.';
$string['public_rate_limit'] = 'Several tickets have already been submitted from this connection. Please try again in ten minutes or sign in.';
$string['public_verification_failed'] = 'Spam protection could not verify this request. Please try again. No ticket was created.';
$string['public_unavailable'] = 'Ticket creation without login is currently unavailable. Please sign in.';
$string['visitormode'] = 'Support Desk access';
$string['visitormode_login'] = 'Sign-in required';
$string['visitormode_anonymous'] = 'Guest ticket without sign-in (Turnstile)';
$string['visitormode_magiclink'] = 'Sign in through Magic Link';
$string['visitormode_desc'] = 'Sign-in is required by default. Alternatively, choose guest tickets with Turnstile or sign-in through the optional Magic Link Authentication plugin (auth_magiclink). Installed Magic Link is offered in this selector. Enable it in Moodle authentication and allow account creation in both Magic Link and Moodle to use visitor access. Guest tickets require both Turnstile keys.';
$string['public_entry_help'] = 'Submit your issue without signing in. You will receive support replies by email; viewing the conversation in the ticket system requires sign-in.';
$string['visitor_login_help'] = 'Already have a Moodle account? Use your usual sign-in method.';
$string['public_turnstile_notice'] = 'This form uses Cloudflare Turnstile for spam protection. Technical browser data is shared with Cloudflare; your ticket content is not sent for verification.';
$string['privacy:metadata:contacts'] = 'Public ticket contact details and subsequent association with a logged-in account.';
$string['privacy:metadata:turnstile'] = 'Cloudflare processes the verification response, website hostname and technical browser data for public ticket spam protection. Ticket content is not sent.';

// Contextual administration help.
$string['adminhelp'] = 'Administration help';
$string['adminhelpmore'] = 'More in the help panel';
$string['adminhelptopics'] = 'Help Topics';
$string['adminhelp_overview'] = 'Setting up support access';
$string['adminhelp_overview_article'] = '<p>Choose Support Desk access and check it while signed in and signed out. Sign-in is the default. Guest tickets require both Turnstile keys.</p><p>Magic Link Authentication (auth_magiclink) is an optional plugin for email-verified sign-in and account creation. Once installed, Sign in through Magic Link appears under Support Desk access. Enable Magic Link in Moodle authentication and permit account creation in Magic Link and Moodle. The page reports missing prerequisites. A saved unavailable mode falls back to normal sign-in.</p><p>The Marketplace distribution of Magic Link needs no activation. An older distribution may require its own activation. Magic Link keeps existing authentication methods and applies its account restrictions and Moodle MFA policy. It does not claim older guest tickets by email.</p><p>Voice recording is optional and requires browser microphone permission. Team and mailbox notifications are described under Team and notifications.</p>';
$string['adminhelp_delivery'] = 'Team and notifications';
$string['adminhelp_delivery_article'] = '<p>Select the roles available for support work and check the support email address. Team assignment and individual ticket handling take place in support administration.</p><p>An email copy is a notification. Replies sent from an external email application are not automatically imported as ticket replies.</p>';

$string['subjectissuerequired'] = 'Enter a subject of up to 255 characters and describe your issue.';

$string['replyrequired'] = 'Enter a reply before sending it.';

$string['invalidassignee'] = 'Select an available support staff member.';

$string['invalidfeedback'] = 'Select a rating from 1 to 5.';

$string['invalidstatus'] = 'Select a valid ticket status.';

$string['invalidpriority'] = 'Select a valid ticket priority.';

$string['invalidattachmentcount'] = 'Choose no more than 10 valid attachments.';

$string['invalidattachment'] = 'The attachment could not be uploaded. Check the file and try again. Each attachment must be within 5 MB and the site upload limit.';

$string['systemactor'] = 'System';

$string['website'] = 'Website';

$string['adminhelp_tickets'] = 'Creating and following tickets';

$string['adminhelp_tickets_help'] = 'Describe your issue, choose a support area and priority, and add any useful files. Open your ticket to read replies or continue the conversation.';

$string['adminhelp_tickets_article'] = '<p>Choose a support area, enter a short subject and describe your issue. Priority indicates urgency. You can attach up to ten files, each within 5 MB and the site upload limit. Pasted screenshots are uploaded when you submit the form.</p><p>Voice recording is available only when enabled by the administrator and allowed by your browser. Review a recording before sending it. Open a ticket from the overview to read and send replies. Closed tickets offer a one-time rating.</p>';

$string['adminhelp_handling'] = 'Support team: managing tickets';

$string['adminhelp_handling_help'] = 'Manage status, support area and assignment in the ticket panels. Internal notes are visible to support staff. Team membership routes alerts; it does not grant ticket access.';

$string['adminhelp_handling_article'] = '<p>Open a ticket to change its status, support area or assigned staff member. Use internal notes for staff-only information and the reply box for messages to the customer. The history records ticket changes.</p><p>Support-area teams determine notification recipients. Eligible team members with the specialist and ticket-management permissions receive on-screen alerts for recent open urgent or high-priority tickets. A notification opens the ticket; it does not change its status.</p>';

$string['adminhelp_overview_help'] = 'Choose support access and check the prerequisites of the selected mode.';
$string['adminhelp_delivery_help'] = 'Configure team roles and the support mailbox. Team membership controls notification routing.';

$string['tickethelp'] = 'Support Desk help';

$string['invalidaccessmode'] = 'Select an available Support Desk access method.';
